/* Mandali trade log: multi-leg positions (straddles, strangles, spreads, iron condors…)
   Buy/Sell is per leg and means only "did I buy or write this contract".
   The student's market view (bullish/bearish/…) is a separate question. */
(function () {
  const L = (side, type, hint) => ({ side, type, hint });
  const TPL = [
    ["Single option", [
      ["buy_ce", "Buy call (CE)", [L("buy", "CE")], "Bullish"],
      ["buy_pe", "Buy put (PE)", [L("buy", "PE")], "Bearish"],
      ["sell_ce", "Sell call (CE)", [L("sell", "CE")], "Bearish"],
      ["sell_pe", "Sell put (PE)", [L("sell", "PE")], "Bullish"]]],
    ["Straddle and strangle", [
      ["short_straddle", "Short straddle", [L("sell", "CE", "ATM"), L("sell", "PE", "same strike")], "Sideways"],
      ["long_straddle", "Long straddle", [L("buy", "CE", "ATM"), L("buy", "PE", "same strike")], "Big move"],
      ["short_strangle", "Short strangle", [L("sell", "CE", "OTM, above spot"), L("sell", "PE", "OTM, below spot")], "Sideways"],
      ["long_strangle", "Long strangle", [L("buy", "CE", "OTM, above spot"), L("buy", "PE", "OTM, below spot")], "Big move"]]],
    ["Spreads", [
      ["bull_call", "Bull call spread (debit)", [L("buy", "CE", "lower strike"), L("sell", "CE", "higher strike")], "Bullish"],
      ["bear_put", "Bear put spread (debit)", [L("buy", "PE", "higher strike"), L("sell", "PE", "lower strike")], "Bearish"],
      ["bull_put", "Bull put spread (credit)", [L("sell", "PE", "higher strike"), L("buy", "PE", "lower strike, hedge")], "Bullish"],
      ["bear_call", "Bear call spread (credit)", [L("sell", "CE", "lower strike"), L("buy", "CE", "higher strike, hedge")], "Bearish"],
      ["calendar", "Calendar spread", [L("sell", "CE", "near expiry"), L("buy", "CE", "far expiry, same strike")], "Sideways"]]],
    ["Four legs", [
      ["iron_condor", "Iron condor", [L("buy", "PE", "far OTM, hedge"), L("sell", "PE", "OTM"), L("sell", "CE", "OTM"), L("buy", "CE", "far OTM, hedge")], "Sideways"],
      ["iron_fly", "Iron butterfly", [L("buy", "PE", "OTM, hedge"), L("sell", "PE", "ATM"), L("sell", "CE", "ATM"), L("buy", "CE", "OTM, hedge")], "Sideways"]]],
    ["Futures and stocks", [
      ["fut_long", "Futures long", [L("buy", "FUT")], "Bullish"],
      ["fut_short", "Futures short", [L("sell", "FUT")], "Bearish"],
      ["eq_intraday", "Equity intraday", [L("buy", "EQ")], "Bullish"],
      ["eq_swing", "Equity swing", [L("buy", "EQ")], "Bullish"]]],
    ["Anything else", [["custom", "Custom (build your own legs)", [L("buy", "CE")], ""]]]
  ];
  const ALL = TPL.flatMap(g => g[1]);
  const byId = Object.fromEntries(ALL.map(x => [x[0], x]));
  const LEGACY = { "Option buying (CE)": "buy_ce", "Option buying (PE)": "buy_pe", "Short straddle": "short_straddle", "Short strangle": "short_strangle",
    "Iron condor": "iron_condor", "Credit spread": "bear_call", "Debit spread": "bull_call", "Expiry option selling": "sell_ce", "Futures": "fut_long",
    "Intraday equity": "eq_intraday", "Swing equity": "eq_swing", "Other": "custom" };
  const idFor = (name) => (ALL.find(x => x[1] === name) || [])[0] || LEGACY[name] || "custom";
  const VIEWS = ["Bullish", "Bearish", "Sideways", "Big move", "Not sure"];
  const UNDER = ["NIFTY", "BANKNIFTY", "SENSEX", "FINNIFTY", "MIDCPNIFTY"];

  const legQty = (t, l) => (+l.lots || 0) * (l.type === "EQ" ? 1 : (+t.lot_size || 1));
  window.legPnl = (t, l) => (l.entry == null || l.exit == null || l.entry === "" || l.exit === "") ? null
    : (l.side === "sell" ? (+l.entry - +l.exit) : (+l.exit - +l.entry)) * legQty(t, l);
  window.legLabel = (l) => `${l.side === "sell" ? "Sell" : "Buy"}${l.strike ? " " + Number(l.strike).toLocaleString("en-IN") : ""} ${l.type}${l.lots ? " ×" + l.lots : ""}`;

  /* P&L and R for both old single trades and new multi-leg trades */
  const oldPnl = window.tradePnl, oldR = window.tradeR;
  window.tradePnl = (t) => {
    if (Array.isArray(t.legs) && t.legs.length) {
      let sum = 0;
      for (const l of t.legs) { const p = legPnl(t, l); if (p == null) return null; sum += p; }
      return sum - (+t.fees || 0);
    }
    return oldPnl(t);
  };
  window.tradeR = (t) => {
    if (t.planned_risk) { const p = tradePnl(t); return p == null ? null : p / Math.abs(+t.planned_risk); }
    if (Array.isArray(t.legs) && t.legs.length) return null;
    return oldR(t);
  };

  /* -------- Form -------- */
  let legs = [], lotSize = "", tplId = "buy_ce", ctx = null;
  const fmt = (n) => (n < 0 ? "−₹" : "₹") + Math.abs(Math.round(n)).toLocaleString("en-IN");
  const lotKey = (u) => "m_lot_" + String(u || "").toUpperCase().replace(/\s+/g, "");
  const savedLot = (u) => { try { return localStorage.getItem(lotKey(u)) || ""; } catch (e) { return ""; } };

  function legHtml(l, i) {
    const opt = l.type === "CE" || l.type === "PE";
    return `<div class="tl-leg" data-i="${i}">
      <div class="tl-leg-top">
        <span class="tl-leg-n">Leg ${i + 1}</span>
        <div class="tl-side" role="radiogroup" aria-label="Buy or sell">
          <button type="button" data-side="buy" aria-checked="${l.side === "buy"}" class="${l.side === "buy" ? "on buy" : ""}">Buy</button>
          <button type="button" data-side="sell" aria-checked="${l.side === "sell"}" class="${l.side === "sell" ? "on sell" : ""}">Sell</button>
        </div>
        <select data-k="type" aria-label="Contract">${["CE", "PE", "FUT", "EQ"].map(x => `<option ${x === l.type ? "selected" : ""} value="${x}">${{ CE: "CE · call", PE: "PE · put", FUT: "Futures", EQ: "Stock" }[x]}</option>`).join("")}</select>
        ${legs.length > 1 ? `<button type="button" class="tl-x" data-del aria-label="Remove leg ${i + 1}">✕</button>` : ""}
      </div>
      <div class="tl-leg-grid">
        ${opt ? `<label><span>Strike</span><input data-k="strike" type="number" inputmode="decimal" step="any" placeholder="${esc(l.hint || "24000")}" value="${l.strike ?? ""}"></label>` : ""}
        <label><span>${l.type === "EQ" ? "Shares" : "Lots"}</span><input data-k="lots" type="number" inputmode="numeric" min="0" step="any" placeholder="1" value="${l.lots ?? ""}"></label>
        <label><span>${l.side === "sell" ? "Sold at" : "Bought at"}</span><input data-k="entry" type="number" inputmode="decimal" step="any" placeholder="${opt ? "Premium" : "Price"}" value="${l.entry ?? ""}"></label>
        <label><span>Exit at</span><input data-k="exit" type="number" inputmode="decimal" step="any" placeholder="Blank if open" value="${l.exit ?? ""}"></label>
      </div>
      <p class="tl-leg-pnl" data-pnl></p>
    </div>`;
  }
  function summary() {
    const t = { legs, lot_size: lotSize, fees: +($("#tlFees")?.value || 0) };
    let prem = 0, any = false;
    legs.forEach(l => { if ((l.type === "CE" || l.type === "PE") && l.entry !== "" && l.entry != null && l.lots) { any = true; prem += (l.side === "sell" ? 1 : -1) * +l.entry * legQty(t, l); } });
    const p = tradePnl(t), anyExit = legs.some(l => l.exit !== "" && l.exit != null);
    const partial = legs.reduce((s, l) => s + (legPnl(t, l) || 0), 0);
    $$(".tl-leg", ctx).forEach((el, i) => { const lp = legPnl(t, legs[i]); el.querySelector("[data-pnl]").innerHTML = lp == null ? "" : `<span class="${lp >= 0 ? "up" : "down"}">${fmt(lp)}</span> on this leg`; });
    const needLot = legs.some(l => l.type !== "EQ") && !lotSize;
    $("#tlSum", ctx).innerHTML = `
      ${any ? `<div><span>${prem >= 0 ? "Premium collected" : "Premium paid"}</span><strong>${fmt(Math.abs(prem))}</strong></div>` : ""}
      <div><span>${p == null ? (anyExit ? "Booked so far" : "P&L") : "Net P&L (after charges)"}</span><strong class="${p == null ? (anyExit ? (partial >= 0 ? "up" : "down") : "") : p >= 0 ? "up" : "down"}">${p == null ? (anyExit ? fmt(partial) : "Open") : fmt(p)}</strong></div>
      ${needLot ? `<p class="tl-warn">Add the lot size so P&amp;L is in rupees.</p>` : ""}`;
  }
  function drawLegs() {
    const box = $("#tlLegs", ctx);
    box.innerHTML = legs.map(legHtml).join("");
    $$(".tl-leg", box).forEach(el => {
      const i = +el.dataset.i;
      $$("[data-side]", el).forEach(b => b.onclick = () => { legs[i].side = b.dataset.side; drawLegs(); });
      $$("[data-k]", el).forEach(inp => {
        const ev = inp.tagName === "SELECT" ? "change" : "input";
        inp.addEventListener(ev, () => { const k = inp.dataset.k; legs[i][k] = inp.value === "" ? "" : (k === "type" ? inp.value : +inp.value); if (k === "type") drawLegs(); else summary(); });
      });
      const d = el.querySelector("[data-del]"); if (d) d.onclick = () => { legs.splice(i, 1); drawLegs(); };
    });
    summary();
  }
  const filled = () => legs.some(l => l.strike || l.entry || l.exit || l.lots);
  function applyTpl(id, keepView) {
    const t = byId[id] || byId.custom; tplId = t[0];
    legs = t[2].map(x => ({ side: x.side, type: x.type, hint: x.hint || "", strike: "", lots: legs[0]?.lots || "", entry: "", exit: "" }));
    if (!keepView && t[3]) { const v = $(`[data-view="${t[3]}"]`, ctx); if (v && !$(".tl-view .on", ctx)) v.click(); }
    drawLegs();
  }

  window.tradeFormHtml = (et) => {
    const curId = et ? idFor(et.strategy) : "buy_ce";
    const known = ALL.some(x => x[1] === et?.strategy);
    const under = et?.instrument && !Array.isArray(et?.legs) ? "" : (et?.underlying || "");
    return `
      <div class="tl-sec">
        <div class="tl-row2">
          <label class="field"><span>Date</span><input name="trade_date" type="date" required value="${esc(et?.trade_date || todayIST())}"></label>
          <label class="field"><span>Index or stock</span><input name="underlying" id="tlUnder" list="tlUnderList" autocapitalize="characters" placeholder="NIFTY" value="${esc(under || (et && !Array.isArray(et.legs) ? "" : "NIFTY"))}"><datalist id="tlUnderList">${UNDER.map(u => `<option value="${u}">`).join("")}</datalist></label>
        </div>
        ${et && !Array.isArray(et.legs) && et.instrument ? `<p class="muted small" style="margin:-6px 0 10px">Logged earlier as: <strong>${esc(et.instrument)}</strong>${et.direction ? ` (${et.direction === "short" ? "sold" : "bought"})` : ""}. Fill the legs below to update it.</p>` : ""}
      </div>
      <div class="tl-sec">
        <label class="field"><span>Strategy</span><select name="strategy" id="tlStrat">
          ${!et || known || LEGACY[et.strategy] ? "" : `<option value="__keep" selected>${esc(et.strategy)}</option>`}
          ${TPL.map(([g, list]) => `<optgroup label="${g}">${list.map(x => `<option value="${x[0]}" ${x[0] === curId && (!et || known || LEGACY[et.strategy]) ? "selected" : ""}>${x[1]}</option>`).join("")}</optgroup>`).join("")}
        </select></label>
        <div class="field"><span>What did you expect the market to do?</span>
          <div class="tl-view" role="radiogroup">${VIEWS.map(v => `<button type="button" data-view="${v}" class="${et?.market_view === v ? "on" : ""}" aria-checked="${et?.market_view === v}">${v}</button>`).join("")}</div>
          <p class="tl-help">This is your view of the market. Buy or Sell below is only about each contract: selling a put is still a bullish trade.</p>
        </div>
      </div>
      <div class="tl-sec">
        <div class="tl-legs-h"><strong>Positions</strong>
          <label class="tl-lot"><span>Lot size</span><input id="tlLot" type="number" inputmode="numeric" min="1" step="1" placeholder="e.g. 65" value="${esc(et?.lot_size ?? "")}"></label></div>
        <div id="tlLegs"></div>
        <button type="button" class="btn sm quiet" id="tlAdd">+ Add leg</button>
        <div class="tl-sum" id="tlSum"></div>
      </div>
      <details class="tl-sec tl-more" ${et && (et.planned_risk || et.planned_target || et.setup || et.notes || (et.mistake && et.mistake !== "None")) ? "open" : ""}>
        <summary>Plan, feelings and lessons <span class="muted small">(optional)</span></summary>
        <div class="tl-row2" style="margin-top:12px">
          <label class="field"><span>Max loss I planned (₹)</span><input name="planned_risk" type="number" inputmode="decimal" step="any" placeholder="2000" value="${et?.planned_risk ?? ""}"></label>
          <label class="field"><span>Target profit (₹)</span><input name="planned_target" type="number" inputmode="decimal" step="any" placeholder="4000" value="${et?.planned_target ?? ""}"></label>
          <label class="field"><span>Charges (₹)</span><input name="fees" id="tlFees" type="number" inputmode="decimal" step="any" value="${et?.fees ?? 0}"></label>
          <label class="field"><span>How I felt</span><select name="emotion">${J_EMOTIONS.map(x => `<option ${x === et?.emotion ? "selected" : ""}>${x}</option>`).join("")}</select></label>
          <label class="field" style="grid-column:1/-1"><span>Mistake</span><select name="mistake">${J_MISTAKES.map(x => `<option ${x === et?.mistake ? "selected" : ""}>${x}</option>`).join("")}</select></label>
        </div>
        <label class="field"><span>Why I took this trade</span><input name="setup" placeholder="FVG retest at 24,050 with put writing support" value="${esc(et?.setup || "")}"></label>
        <label class="field"><span>Notes / lesson</span><textarea name="notes" placeholder="What did I learn?">${esc(et?.notes || "")}</textarea></label>
      </details>
      <div class="actions">
        <button class="btn" type="submit">${et ? "Save changes" : "Save trade"}</button>
        <button class="btn quiet" type="button" id="cancelTrade">Cancel</button>
      </div>`;
  };

  window.bindTradeForm = (form, et, onSaved) => {
    ctx = form;
    tplId = et ? idFor(et.strategy) : "buy_ce";
    lotSize = et?.lot_size ?? "";
    if (et && Array.isArray(et.legs) && et.legs.length) legs = et.legs.map(l => ({ ...l, hint: "" }));
    else if (et && et.instrument) {
      const m = String(et.instrument).match(/(\d{3,6}(?:\.\d+)?)\s*(CE|PE)\b/i), fut = /FUT/i.test(et.instrument);
      legs = [{ side: et.direction === "short" ? "sell" : "buy", type: m ? m[2].toUpperCase() : fut ? "FUT" : /equity/i.test(et.strategy || "") ? "EQ" : "CE",
        strike: m ? +m[1] : "", lots: et.qty || "", entry: et.entry ?? "", exit: et.exit ?? "", hint: "" }];
      const u = String(et.instrument).match(/^[A-Z]+/i); if (u) form.underlying.value = u[0].toUpperCase();
      // old trades stored total quantity: convert to lots when we know the lot size
      const known = +savedLot(form.underlying.value);
      if (et.qty && known && et.qty % known === 0) { lotSize = known; legs[0].lots = et.qty / known; } else lotSize = et.qty ? 1 : "";
      $("#tlLot", form).value = lotSize;
      const L0 = legs[0], single = { "buy CE": "buy_ce", "buy PE": "buy_pe", "sell CE": "sell_ce", "sell PE": "sell_pe", "buy FUT": "fut_long", "sell FUT": "fut_short" }[L0.side + " " + L0.type];
      if (single && LEGACY[et.strategy] && ["buy_ce", "buy_pe", "sell_ce", "fut_long"].includes(LEGACY[et.strategy])) { tplId = single; $("#tlStrat", form).value = single; }
    } else legs = [];
    if (!legs.length) applyTpl(tplId, true); else drawLegs();
    if (!lotSize && !et) { lotSize = savedLot(form.underlying.value); $("#tlLot", form).value = lotSize; summary(); }

    $("#tlStrat", form).onchange = (e) => {
      if (e.target.value === "__keep") return;
      if (filled() && !confirm("Switch strategy? This resets the legs you entered.")) { e.target.value = tplId; return; }
      applyTpl(e.target.value);
    };
    $$("[data-view]", form).forEach(b => b.onclick = () => { const on = !b.classList.contains("on"); $$("[data-view]", form).forEach(x => { x.classList.remove("on"); x.setAttribute("aria-checked", "false"); }); if (on) { b.classList.add("on"); b.setAttribute("aria-checked", "true"); } });
    $("#tlAdd", form).onclick = () => { const last = legs[legs.length - 1] || { side: "buy", type: "CE" }; legs.push({ side: last.side, type: last.type, strike: "", lots: last.lots || "", entry: "", exit: "", hint: "" }); drawLegs(); };
    $("#tlLot", form).oninput = (e) => { lotSize = e.target.value === "" ? "" : +e.target.value; summary(); };
    $("#tlFees", form).oninput = summary;
    $("#tlUnder", form).onchange = (e) => { if (!$("#tlLot", form).value) { lotSize = savedLot(e.target.value); $("#tlLot", form).value = lotSize; summary(); } };

    form.onsubmit = async (e) => {
      e.preventDefault();
      const f = form, num = (k) => f[k].value === "" ? null : +f[k].value;
      const clean = legs.map(l => ({ side: l.side, type: l.type, strike: l.strike === "" ? null : l.strike, lots: l.lots === "" ? null : l.lots, entry: l.entry === "" ? null : l.entry, exit: l.exit === "" ? null : l.exit }))
        .filter(l => l.strike != null || l.entry != null || l.lots != null || legs.length === 1);
      if (!clean.length) return toast("Add at least one position");
      const under = f.underlying.value.trim().toUpperCase();
      const tpl = byId[tplId], stratName = f.strategy.value === "__keep" ? et.strategy : (tpl ? tpl[1] : "Custom");
      const view = $(".tl-view .on", f)?.dataset.view || null;
      const credit = clean.filter(l => l.type === "CE" || l.type === "PE").reduce((s, l) => s + (l.side === "sell" ? 1 : -1) * (+l.entry || 0) * (+l.lots || 0), 0);
      const row = {
        trade_date: f.trade_date.value, strategy: stratName, underlying: under || null,
        instrument: [under, clean.map(legLabel).join(" / ")].filter(Boolean).join(" · ").slice(0, 200),
        direction: clean.length === 1 ? (clean[0].side === "sell" ? "short" : "long") : (credit > 0 ? "short" : "long"),
        legs: clean, lot_size: lotSize === "" ? null : +lotSize, market_view: view,
        qty: null, entry: null, exit: null, stop: null, target: null,
        planned_risk: num("planned_risk"), planned_target: num("planned_target"), fees: num("fees") || 0,
        emotion: f.emotion.value, mistake: f.mistake.value, setup: f.setup.value.trim(), notes: f.notes.value.trim()
      };
      try { if (under && lotSize) localStorage.setItem(lotKey(under), String(lotSize)); } catch (e2) {}
      const btn = f.querySelector('[type="submit"]'); btn.disabled = true;
      const { error } = et ? await sb.from("trades").update(row).eq("id", et.id) : await sb.from("trades").insert(row);
      btn.disabled = false;
      if (error) return toast(/legs|market_view|lot_size|underlying|planned_/.test(error.message) ? "The trade log needs a quick update from Mandali. Please tell your mentor." : "Couldn't save: " + error.message);
      toast(et ? "Trade updated" : "Trade saved"); onSaved();
    };
  };

  /* Compact description for lists */
  window.tradeLegsHtml = (t) => Array.isArray(t.legs) && t.legs.length
    ? `<div class="tl-chips">${t.legs.map(l => `<span class="tl-chip ${l.side}">${esc(legLabel(l))}</span>`).join("")}</div>` : "";
})();
