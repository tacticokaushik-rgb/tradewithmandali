/* Mandali payments: pay by scanning a UPI QR (works with personal UPI IDs),
   then submit the UTR + screenshot. Mandali approves with one tap and the plan
   dates extend automatically. */
(function () {
  const QR_LIB = "qrcode.js?v=20261012b";
  let qrLoading = null;
  const loadQr = () => window.qrcode ? Promise.resolve() : (qrLoading = qrLoading || new Promise((res, rej) => {
    const s = document.createElement("script"); s.src = QR_LIB; s.onload = res; s.onerror = () => { qrLoading = null; rej(new Error("QR couldn't load")); }; document.head.appendChild(s);
  }));
  const upiUrl = (st, amount, note) => `upi://pay?pa=${String(st.upi_id).trim().replace(/[^\w.@-]/g, "")}&pn=${encodeURIComponent(st.payee_name || "Mandali")}&am=${amount}&cu=INR&tn=${encodeURIComponent(note)}`;

  /* Draws a branded payment card (QR + amount + name) on a canvas, so the saved
     image is clear and the student can check the amount in their gallery. */
  async function paymentCard(st, pl, note) {
    const W = 720, H = 1000, c = document.createElement("canvas"); c.width = W; c.height = H;
    const g = c.getContext("2d");
    g.fillStyle = "#ffffff"; g.fillRect(0, 0, W, H);
    g.fillStyle = "#0B1220"; g.fillRect(0, 0, W, 150);
    g.fillStyle = "#E0A82E"; g.font = "bold 46px Georgia, serif"; g.textAlign = "center"; g.fillText("Mandali", W / 2, 72);
    g.fillStyle = "#c9cfda"; g.font = "26px sans-serif"; g.fillText(pl.name, W / 2, 118);
    let img;
    if (st.upi_qr) { img = new Image(); img.src = st.upi_qr; await img.decode().catch(() => {}); }
    const box = 520, x = (W - box) / 2, y = 190;
    if (img && img.naturalWidth) {
      const s = Math.min(box / img.naturalWidth, box / img.naturalHeight), w = img.naturalWidth * s, h = img.naturalHeight * s;
      g.drawImage(img, (W - w) / 2, y + (box - h) / 2, w, h);
    } else {
      await loadQr();
      const q = qrcode(0, "M"); q.addData(upiUrl(st, pl.price, note)); q.make();
      const n = q.getModuleCount(), cell = Math.floor(box / (n + 8)), size = cell * n, ox = (W - size) / 2, oy = y + (box - size) / 2;
      g.fillStyle = "#000";
      for (let r = 0; r < n; r++) for (let k = 0; k < n; k++) if (q.isDark(r, k)) g.fillRect(ox + k * cell, oy + r * cell, cell, cell);
    }
    g.fillStyle = "#0B1220"; g.font = "bold 64px sans-serif"; g.fillText("₹" + Number(pl.price).toLocaleString("en-IN"), W / 2, 800);
    g.fillStyle = "#5C6678"; g.font = "26px sans-serif";
    g.fillText("Pay to " + (st.payee_name || "Mandali"), W / 2, 850);
    if (st.upi_id) g.fillText(st.upi_id, W / 2, 888);
    g.font = "22px sans-serif"; g.fillText("Scan with any UPI app · Scan → Gallery → choose this image", W / 2, 950);
    return c;
  }

  const compress = (file, max = 1400) => new Promise((res) => {
    if (!/^image\//.test(file.type)) return res(file);
    const img = new Image(), url = URL.createObjectURL(file);
    img.onload = () => {
      const s = Math.min(1, max / Math.max(img.width, img.height)), c = document.createElement("canvas");
      c.width = Math.round(img.width * s); c.height = Math.round(img.height * s);
      c.getContext("2d").drawImage(img, 0, 0, c.width, c.height); URL.revokeObjectURL(url);
      c.toBlob(b => res(b || file), "image/jpeg", 0.82);
    };
    img.onerror = () => { URL.revokeObjectURL(url); res(file); };
    img.src = url;
  });
  window.mpCompress = compress;

  /* ---------- Student: pay sheet ---------- */
  window.openPaySheet = async (pl, st, p, onDone) => {
    const note = `Mandali ${pl.name} ${(p.full_name || "").split(" ")[0]}`.slice(0, 40);
    const num = String(st.upi_number || "").replace(/\D/g, "");
    const canQr = !!(st.upi_qr || st.upi_id);
    const sh = openSheet(`Pay ${inr(pl.price)}`, `
      ${canQr ? `
      <div class="pay-step"><span class="step-num">1</span><div style="flex:1;min-width:0">
        <p style="margin:0"><strong>Save the QR</strong> to your gallery</p>
        <div class="pay-qr" id="payQr"><p class="muted small">Making your QR…</p></div>
        <button class="btn block" id="paySave">Save QR to gallery</button>
        <p class="muted small" style="margin:6px 0 0">On a laptop? Just scan the QR on screen with your phone.</p></div></div>
      <div class="pay-step"><span class="step-num">2</span><div>
        <p style="margin:0"><strong>Scan it from your gallery</strong></p>
        <p class="muted small" style="margin:4px 0 0">Open GPay, PhonePe or Paytm → tap <strong>Scan</strong> → tap the <strong>gallery / photo icon</strong> → pick the saved QR. Check the name shows as <strong>${esc(st.payee_name || "Mandali")}</strong> and the amount is <strong>${inr(pl.price)}</strong>, then pay.</p>
        <p class="muted small" style="margin:6px 0 0">Scanning works even where a "Pay" link says risky.</p></div></div>`
      : num ? `<div class="pay-step"><span class="step-num">1</span><div><p style="margin:0">Pay <strong>${inr(pl.price)}</strong> to this UPI number from GPay, PhonePe or Paytm (choose "Pay phone number")</p>
        <div class="copy-row"><strong>${esc(num)}</strong><button class="btn sm" data-copy="${esc(num)}">Copy</button></div></div></div>`
      : `<p class="sh-empty">Payment details aren't set up yet. Please message Mandali.</p>`}
      ${canQr && num ? `<details class="pay-alt"><summary>QR not working? Pay to phone number</summary>
        <div class="copy-row"><strong>${esc(num)}</strong><button class="btn sm" data-copy="${esc(num)}">Copy</button></div>
        <p class="muted small" style="margin:4px 0 0">In your UPI app choose "Pay phone number", paste it and enter ${inr(pl.price)}.</p></details>` : ""}
      <div class="pay-step"><span class="step-num">${canQr ? 3 : 2}</span><div style="flex:1;min-width:0">
        <p style="margin:0"><strong>Confirm your payment here</strong></p>
        <form id="payProof" style="margin-top:8px">
          <label class="field"><span>UTR / UPI reference number (12 digits)</span><input name="utr" inputmode="numeric" autocomplete="off" maxlength="22" placeholder="e.g. 428193746512" required></label>
          <p class="muted small" style="margin:-8px 0 12px">Find it in your UPI app: open the payment → "UPI transaction ID" or "UTR".</p>
          <label class="field"><span>Payment screenshot</span><input name="shot" type="file" accept="image/*" required></label>
          <div id="payNote"></div>
          <button class="btn block" type="submit">Submit for approval</button>
        </form></div></div>`, { sub: `${pl.name}, ${pl.period}` });
    $$("[data-copy]", sh.body).forEach(b => b.onclick = async () => {
      try { await navigator.clipboard.writeText(b.dataset.copy); b.textContent = "Copied ✓"; } catch (e) { b.textContent = "Long-press to copy"; }
      setTimeout(() => b.textContent = "Copy", 2000);
    });
    let canvas = null;
    if (canQr) {
      try {
        canvas = await paymentCard(st, pl, note);
        const box = $("#payQr", sh.body); if (box) { box.innerHTML = ""; const im = new Image(); im.src = canvas.toDataURL("image/png"); im.alt = `UPI QR to pay ${inr(pl.price)}`; box.appendChild(im); }
      } catch (e) { const box = $("#payQr", sh.body); if (box) box.innerHTML = `<p class="muted small">QR couldn't load. Use "Pay to phone number" below, or check your internet and reopen.</p>`; }
      $("#paySave", sh.body).onclick = async () => {
        if (!canvas) return;
        const blob = await new Promise(r => canvas.toBlob(r, "image/png"));
        const file = new File([blob], `mandali-pay-${pl.price}.png`, { type: "image/png" });
        try {
          if (navigator.canShare && navigator.canShare({ files: [file] }) && /Android|iPhone|iPad/i.test(navigator.userAgent)) {
            await navigator.share({ files: [file], title: "Mandali payment QR" });
            toast("Choose 'Save image' or 'Save to Photos'"); return;
          }
        } catch (e) { if (e.name === "AbortError") return; }
        const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = file.name; document.body.appendChild(a); a.click(); a.remove();
        setTimeout(() => URL.revokeObjectURL(a.href), 4000);
        toast("QR saved. Check your Downloads / Gallery");
      };
    }
    const f = $("#payProof", sh.body);
    f.onsubmit = async (e) => {
      e.preventDefault();
      const utr = f.utr.value.replace(/\s+/g, "");
      if (!/^[A-Za-z0-9]{10,22}$/.test(utr)) { $("#payNote", sh.body).innerHTML = msg("err", "That doesn't look like a UTR. It's usually 12 digits."); return; }
      const file = f.shot.files[0]; if (!file) return;
      const btn = f.querySelector('[type="submit"]'); btn.disabled = true; btn.textContent = "Uploading…";
      const blob = await compress(file);
      const path = `${p.id}/${Date.now()}.jpg`;
      const up = await sb.storage.from("pay-proofs").upload(path, blob, { contentType: "image/jpeg" });
      if (up.error) { btn.disabled = false; btn.textContent = "Submit for approval"; $("#payNote", sh.body).innerHTML = msg("err", /bucket/i.test(up.error.message) ? "Payments aren't fully set up yet. Please send the screenshot to Mandali on WhatsApp." : "Upload failed: " + up.error.message); return; }
      const { error } = await sb.from("payment_requests").insert({ user_id: p.id, plan: pl.name, amount: pl.price, months: pl.months, utr, proof_path: path });
      if (error) {
        btn.disabled = false; btn.textContent = "Submit for approval";
        $("#payNote", sh.body).innerHTML = msg("err", /duplicate|unique/i.test(error.message) ? "This UTR has already been submitted. If that wasn't you, message Mandali." : "Couldn't submit: " + error.message);
        return;
      }
      sh.close(); toast("Submitted ✓ Mandali will confirm soon"); onDone && onDone();
    };
  };

  /* ---------- Admin: approval queue ---------- */
  window.mpPendingHtml = (reqs, studentsById) => !reqs.length ? "" : `
    <h3 class="sec-title">Waiting for approval <span class="ov-sub warn">${reqs.length}</span></h3>
    <div class="rows">${reqs.map(r => { const s = studentsById(r.user_id); return `
      <div class="card mp-req" data-req="${r.id}">
        <div class="mp-top">${r._url ? `<a href="${esc(r._url)}" target="_blank" rel="noopener" class="mp-shot"><img src="${esc(r._url)}" alt="Payment screenshot from ${esc(s.full_name || "student")}" loading="lazy"></a>` : `<div class="mp-shot mp-none">No image</div>`}
          <div style="min-width:0;flex:1"><strong>${esc(s.full_name || s.email || "Student")}</strong>
            <div class="muted small">${esc(r.plan)} · <strong style="color:var(--gold)">${inr(r.amount)}</strong></div>
            <div class="muted small">UTR <span class="mono">${esc(r.utr)}</span></div>
            <div class="muted small">Sent ${esc(stamp(r.created_at))}</div></div></div>
        <label class="field" style="margin:10px 0 8px"><span>Access valid till</span><input type="date" data-until value="${esc(r._until)}"></label>
        <p class="muted small" style="margin:-4px 0 10px">Match the UTR and amount with your bank or UPI app before approving.</p>
        <div class="actions"><button class="btn sm" data-ok>Approve</button><button class="btn sm danger" data-no>Reject</button></div>
      </div>`; }).join("")}</div>`;

  window.mpLoadPending = async () => {
    const r = await sb.from("payment_requests").select("*").eq("status", "pending").order("created_at");
    if (r.error) return { error: r.error, data: [] };
    const reqs = r.data || [];
    const paths = reqs.map(x => x.proof_path).filter(Boolean);
    if (paths.length) {
      const su = await sb.storage.from("pay-proofs").createSignedUrls(paths, 3600);
      const m = {}; (su.data || []).forEach(x => { if (x.signedUrl) m[x.path] = x.signedUrl; });
      reqs.forEach(x => x._url = m[x.proof_path]);
    }
    return { data: reqs };
  };

  window.mpBindPending = (root, reqs, after) => {
    $$("[data-req]", root).forEach(el => {
      const r = reqs.find(x => String(x.id) === el.dataset.req);
      el.querySelector("[data-ok]").onclick = async (e) => {
        const until = el.querySelector("[data-until]").value; if (!until) return toast("Pick the valid-till date");
        e.target.disabled = true;
        const { error } = await sb.rpc("approve_payment", { p_id: r.id, p_valid_until: until });
        if (error) { e.target.disabled = false; return toast("Couldn't approve: " + error.message); }
        toast(`Approved. Access till ${fmtDay(until)}`); after();
      };
      el.querySelector("[data-no]").onclick = async (e) => {
        const why = prompt("Reason (the student will see this):", "Payment not received with this UTR");
        if (why === null) return;
        e.target.disabled = true;
        const { error } = await sb.rpc("reject_payment", { p_id: r.id, p_note: why.trim() });
        if (error) { e.target.disabled = false; return toast("Couldn't reject: " + error.message); }
        toast("Rejected"); after();
      };
    });
  };
})();
