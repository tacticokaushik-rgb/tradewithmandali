/* Mandali Formulas: options-chain & index calculations, from basics. */
(function () {
  // ---------- maths helpers ----------
  const erf = (x) => { // Abramowitz-Stegun 7.1.26
    const s = Math.sign(x); x = Math.abs(x);
    const t = 1 / (1 + 0.3275911 * x);
    const y = 1 - (((((1.061405429 * t - 1.453152027) * t) + 1.421413741) * t - 0.284496736) * t + 0.254829592) * t * Math.exp(-x * x);
    return s * y;
  };
  const N = (x) => 0.5 * (1 + erf(x / Math.SQRT2));
  const phi = (x) => Math.exp(-x * x / 2) / Math.sqrt(2 * Math.PI);

  function blackScholes(S, K, days, ivPct, rPct, qPct) {
    const T = Math.max(days, 0.0001) / 365, sig = ivPct / 100, r = rPct / 100, q = qPct / 100;
    const sqT = Math.sqrt(T);
    const d1 = (Math.log(S / K) + (r - q + sig * sig / 2) * T) / (sig * sqT), d2 = d1 - sig * sqT;
    const dq = Math.exp(-q * T), dr = Math.exp(-r * T);
    const call = S * dq * N(d1) - K * dr * N(d2);
    const put = K * dr * N(-d2) - S * dq * N(-d1);
    const gamma = dq * phi(d1) / (S * sig * sqT);
    const vega = S * dq * phi(d1) * sqT / 100;
    const thetaC = (-S * dq * phi(d1) * sig / (2 * sqT) - r * K * dr * N(d2) + q * S * dq * N(d1)) / 365;
    const thetaP = (-S * dq * phi(d1) * sig / (2 * sqT) + r * K * dr * N(-d2) - q * S * dq * N(-d1)) / 365;
    return { d1, d2, call, put, deltaC: dq * N(d1), deltaP: dq * (N(d1) - 1), gamma, vega, thetaC, thetaP, probITMc: N(d2), probITMp: N(-d2) };
  }
  window.MFORMULA = { N, blackScholes };

  // ---------- formula library ----------
  window.FORMULAS = [
    { group: "Statistics basics", items: [
      { name: "Mean (average)", what: "The typical value of a set of numbers.",
        formula: "Mean = (x₁ + x₂ + … + xₙ) ÷ n",
        example: "Closes 24,120, 24,310, 23,980, 24,205, 24,050 → sum 120,665 ÷ 5 = 24,133" },
      { name: "Median", what: "The middle value once the numbers are sorted. Unlike the mean, one extreme day can't drag it.",
        formula: "Sort the values.\nIf n is odd: Median = value at position (n + 1) ÷ 2\nIf n is even: Median = average of the values at positions n ÷ 2 and n ÷ 2 + 1",
        example: "Odd: 23,980, 24,050, 24,120, 24,205, 24,310 → middle (3rd) = 24,120\nEven: add 24,400 → (24,120 + 24,205) ÷ 2 = 24,162.5",
        tip: "Use the median for seasonality and returns: a single crash month (like Mar 2020) distorts the mean." },
      { name: "Standard deviation (σ)", what: "How spread out values are around the mean. The core of all volatility maths.",
        formula: "σ = √[ Σ (x − mean)² ÷ (n − 1) ]",
        example: "Daily returns +1%, −1.5%, +1.3%, +1.2%, −0.8% → σ ≈ 1.29% per day" },
      { name: "Log return", what: "The return measure used in volatility and option models.",
        formula: "rₜ = ln(Pₜ ÷ Pₜ₋₁)",
        example: "Nifty 24,000 → 24,240: ln(24,240 ÷ 24,000) = 0.00995 ≈ 0.995%" },
      { name: "Historical volatility (HV)", what: "Annualised standard deviation of daily log returns: how much the index actually moved.",
        formula: "HV = σ(daily log returns) × √252",
        example: "Daily σ = 1.29% → HV = 1.29% × 15.87 ≈ 20.5% a year",
        tip: "Some traders use √250 for Indian trading days. Compare HV with IV: IV well above HV means options are expensive." }
    ]},
    { group: "Option value basics", items: [
      { name: "Intrinsic value", what: "What an option is worth if exercised right now.",
        formula: "Call = max(0, S − K)\nPut = max(0, K − S)\nS = spot/underlying, K = strike",
        example: "Nifty 24,150: 24,000 CE intrinsic = 150; 24,200 PE intrinsic = 50; 24,300 CE intrinsic = 0" },
      { name: "Time (extrinsic) value", what: "The part of the premium paid for time and volatility. It decays to zero at expiry.",
        formula: "Time value = Premium − Intrinsic value",
        example: "24,000 CE at ₹230 with Nifty 24,150 → 230 − 150 = ₹80 time value" },
      { name: "Moneyness", what: "Where the strike sits versus spot.",
        formula: "Call: ITM if S > K, ATM if S ≈ K, OTM if S < K\nPut: ITM if S < K, ATM if S ≈ K, OTM if S > K\nATM strike = strike nearest to spot (or to the implied forward)",
        example: "Nifty 24,130 with 50-point strikes → ATM = 24,150" },
      { name: "Breakeven at expiry", what: "The index level where the trade neither makes nor loses money at expiry.",
        formula: "Long call: K + premium\nLong put: K − premium\nLong straddle: K ± (call + put premium)\nLong strangle: call K + total premium, put K − total premium",
        example: "24,000 straddle for ₹371 → breakevens 23,629 and 24,371" },
      { name: "P&L per lot", what: "Money made or lost on an option or futures position.",
        formula: "P&L = (Exit price − Entry price) × Lot size × Number of lots\n(Reverse the sign for short positions)",
        example: "Bought at 120, sold at 165, lot size 65, 2 lots → (165 − 120) × 65 × 2 = ₹5,850",
        tip: "Always use the current NSE lot size; exchanges revise it periodically." }
    ]},
    { group: "Forward, futures and parity", items: [
      { name: "Futures fair value (cost of carry)", what: "Where index futures should trade given interest and dividends.",
        formula: "F = S × e^((r − q) × T)\nr = risk-free rate, q = dividend yield, T = days ÷ 365",
        example: "S 24,000, r 5.5%, q 1.2%, 30 days → F = 24,000 × e^(0.043 × 0.0822) ≈ 24,085" },
      { name: "Basis and implied carry", what: "The premium of futures over spot and the annual rate it implies.",
        formula: "Basis = F − S\nImplied carry (annual) = ln(F ÷ S) ÷ T",
        example: "F 24,085, S 24,000, 30 days → basis 85 points; carry = ln(1.00354) ÷ 0.0822 ≈ 4.3% a year" },
      { name: "Put–call parity", what: "Links call and put prices of the same strike and expiry. Nifty options are European, so it holds closely.",
        formula: "C − P = (F − K) × e^(−r × T)\nEquivalently: C − P = S × e^(−q × T) − K × e^(−r × T)",
        example: "If parity breaks by more than costs, an arbitrage exists. In practice it shows where the market prices the forward." },
      { name: "Implied forward", what: "The forward level the option chain itself is pricing. Find the strike where call and put premiums are closest.",
        formula: "F(implied) = K + (C − P) × e^(r × T)\nUse the strike where |C − P| is smallest",
        example: "24,000 CE ₹210, PE ₹180, r 5.5%, 30 days → 24,000 + 30 × 1.0045 ≈ 24,030",
        tip: "Use the implied forward, not spot, as your true ATM. It already includes carry and dividends." },
      { name: "Synthetic futures", what: "Recreate a futures position with options.",
        formula: "Synthetic long = Buy call + Sell put (same K)\nSynthetic price ≈ K + C − P",
        example: "K 24,000, C 210, P 180 → synthetic ≈ 24,030" }
    ]},
    { group: "Volatility and ranges", items: [
      { name: "Expected move (volatility range)", what: "The 1-standard-deviation range implied by IV. About 68% of the time, price stays inside it.",
        formula: "1σ move = S × IV × √(days ÷ 365)\nRange = S ± 1σ (≈68%), S ± 2σ (≈95%)",
        example: "Nifty 24,000, IV 14%, 7 days → 24,000 × 0.14 × √(7/365) ≈ 465 points → range 23,535 to 24,465" },
      { name: "Straddle-implied move", what: "A quick way to read the expected move straight from the option chain.",
        formula: "ATM straddle ≈ 0.8 × 1σ move\n1σ move ≈ ATM straddle ÷ 0.8 (≈ 1.25 × straddle)",
        example: "ATM straddle ₹371 → 1σ ≈ 371 ÷ 0.8 ≈ 464 points",
        tip: "0.8 comes from √(2/π): the average absolute move of a normal distribution is 0.8σ." },
      { name: "Rule of 16 (daily move from VIX)", what: "Convert India VIX or annual IV into an expected daily % move.",
        formula: "Daily move % ≈ Annual IV ÷ 16   (because √256 = 16 trading days)",
        example: "India VIX 16 → about 1% a day → Nifty 24,000 ≈ ±240 points on a normal day" },
      { name: "IV Rank", what: "Where today's IV sits within its 52-week range.",
        formula: "IV Rank = (IV now − 52-week low) ÷ (52-week high − 52-week low) × 100",
        example: "IV 15, low 10, high 25 → (5 ÷ 15) × 100 = 33" },
      { name: "IV Percentile", what: "The % of days in the past year when IV was lower than today.",
        formula: "IV Percentile = (days with IV below today ÷ total days) × 100",
        example: "IV was lower on 200 of 250 days → 80th percentile: options are relatively expensive" },
      { name: "Volatility skew", what: "How much more the market pays for downside protection.",
        formula: "Skew = IV(OTM put) − IV(equidistant OTM call)",
        example: "24,000 spot: 23,500 PE IV 16%, 24,500 CE IV 12.5% → skew 3.5 points (put skew)" }
    ]},
    { group: "Greeks (Black–Scholes)", items: [
      { name: "d1 and d2", what: "The two building blocks of every Black–Scholes number.",
        formula: "d1 = [ln(S ÷ K) + (r − q + σ² ÷ 2) × T] ÷ (σ × √T)\nd2 = d1 − σ × √T\nN(x) = standard normal cumulative probability",
        example: "S = K = 24,000, 7 days, IV 14%, r 5.5%, q 1.2% → d1 ≈ 0.052, d2 ≈ 0.033" },
      { name: "Option price", what: "Theoretical fair value of a European option.",
        formula: "Call = S·e^(−qT)·N(d1) − K·e^(−rT)·N(d2)\nPut = K·e^(−rT)·N(−d2) − S·e^(−qT)·N(−d1)",
        example: "Same inputs → Call ≈ ₹195.6, Put ≈ ₹175.8" },
      { name: "Delta", what: "Change in option price for a 1-point move in the index. Also a rough probability of finishing ITM.",
        formula: "Call Δ = e^(−qT) × N(d1)\nPut Δ = e^(−qT) × [N(d1) − 1]",
        example: "ATM call Δ ≈ 0.52, put Δ ≈ −0.48 → Nifty +100 points ≈ call +52",
        tip: "Exact risk-neutral probability of expiring ITM is N(d2) for calls and N(−d2) for puts." },
      { name: "Gamma", what: "How fast delta changes. Highest at the money near expiry: why expiry days are wild.",
        formula: "Γ = e^(−qT) × φ(d1) ÷ (S × σ × √T)\nφ(x) = e^(−x²/2) ÷ √(2π)",
        example: "ATM, 7 days → Γ ≈ 0.00086 → delta rises ≈ 0.086 per 100 points" },
      { name: "Theta (per day)", what: "Premium lost each day from time decay, all else equal.",
        formula: "Call Θ = [−S·e^(−qT)·φ(d1)·σ ÷ (2√T) − r·K·e^(−rT)·N(d2) + q·S·e^(−qT)·N(d1)] ÷ 365",
        example: "ATM call, 7 days → Θ ≈ −₹14.7 per day" },
      { name: "Vega (per 1% IV)", what: "Change in premium for a 1-point change in IV.",
        formula: "Vega = S × e^(−qT) × φ(d1) × √T ÷ 100",
        example: "ATM, 7 days → Vega ≈ ₹13.2: IV 14% → 15% adds ≈ ₹13 to each option" },
      { name: "Position Greeks and delta hedge", what: "Total exposure of a position and how many futures neutralise it.",
        formula: "Position Δ = Σ (Δ × lot size × lots)   (negative for shorts)\nFutures lots to hedge = −Position Δ ÷ lot size",
        example: "Short 4 lots of 0.30Δ calls, lot 65 → Δ = −0.30 × 65 × 4 = −78 → buy 78 ÷ 65 ≈ 1.2 lots of futures" }
    ]},
    { group: "Option chain analytics", items: [
      { name: "Put-Call Ratio (PCR)", what: "Balance between put and call positions.",
        formula: "PCR (OI) = Total put OI ÷ Total call OI\nPCR (volume) = Put volume ÷ Call volume",
        example: "Put OI 1.2 crore, call OI 1.0 crore → PCR 1.2",
        tip: "Read it with price: very high PCR can mean heavy put writing (support) or crowded hedging. Watch the change, not just the level." },
      { name: "Max Pain", what: "The expiry level where option buyers collectively lose the most (writers pay the least).",
        formula: "For each strike X as a possible expiry price:\nPain(X) = Σ Call OI(K) × max(0, X − K) + Σ Put OI(K) × max(0, K − X)\nMax Pain = the X with the smallest Pain(X)",
        example: "Compute Pain for every strike in the chain and pick the minimum. It is a magnet idea, not a forecast." },
      { name: "OI change: price + OI matrix", what: "What fresh positions are telling you.",
        formula: "Price ↑ + OI ↑ = Long build-up\nPrice ↓ + OI ↑ = Short build-up\nPrice ↑ + OI ↓ = Short covering\nPrice ↓ + OI ↓ = Long unwinding",
        example: "Nifty futures +0.8% with OI +6% → long build-up" },
      { name: "OI-based support and resistance", what: "Where option writers have the most at stake.",
        formula: "Resistance ≈ strike with highest call OI (and rising call writing)\nSupport ≈ strike with highest put OI (and rising put writing)",
        example: "Max call OI at 24,500, max put OI at 23,800 → expected range 23,800 to 24,500",
        tip: "Combine with the straddle-implied move: if both agree, the range is stronger." }
    ]},
    { group: "Index calculations", items: [
      { name: "Index value (free-float market cap)", what: "How Nifty 50 itself is calculated.",
        formula: "Index = (Current free-float market cap ÷ Base market cap) × Base value\nNifty 50 base value = 1,000 (base date 3 Nov 1995)",
        example: "If free-float market cap rises 1%, Nifty rises 1%" },
      { name: "Stock contribution to index", what: "How many Nifty points one stock added or removed.",
        formula: "Points = Index level × Stock weight × Stock % change",
        example: "Nifty 24,000, stock weight 12%, stock +2% → 24,000 × 0.12 × 0.02 ≈ +58 points" },
      { name: "Beta", what: "How much a stock or portfolio moves for a 1% index move.",
        formula: "β = Covariance(stock returns, index returns) ÷ Variance(index returns)",
        example: "β 1.3 → stock tends to move 1.3% when Nifty moves 1%" },
      { name: "Portfolio hedge with index futures", what: "Futures lots needed to hedge a stock portfolio.",
        formula: "Lots = (Portfolio value × β) ÷ (Futures price × Lot size)",
        example: "₹30 lakh portfolio, β 1.1, futures 24,085, lot 65 → 33,00,000 ÷ 15,65,525 ≈ 2.1 lots" },
      { name: "CAGR", what: "Compounded yearly growth rate.",
        formula: "CAGR = (End value ÷ Start value)^(1 ÷ years) − 1",
        example: "Index doubles in 5 years → 2^(0.2) − 1 ≈ 14.9% a year" },
      { name: "Drawdown", what: "Fall from a peak.",
        formula: "Drawdown % = (Peak − Current) ÷ Peak × 100",
        example: "Peak 26,000, now 23,000 → 11.5% drawdown" }
    ]},
    { group: "Risk management", items: [
      { name: "Position size", what: "How many units so one trade can only lose your chosen % of capital.",
        formula: "Quantity = (Capital × Risk %) ÷ (Entry − Stop-loss)\nLots = Quantity ÷ Lot size (round down)",
        example: "₹5,00,000 capital, 1% risk, entry 150, stop 120 → 5,000 ÷ 30 ≈ 166 units → 2 lots of 65" },
      { name: "Risk–reward ratio", what: "Potential gain per rupee risked.",
        formula: "R:R = (Target − Entry) ÷ (Entry − Stop-loss)",
        example: "Entry 150, stop 120, target 210 → 60 ÷ 30 = 2 : 1" },
      { name: "Breakeven win rate", what: "Minimum win % needed for a given risk–reward.",
        formula: "Win rate needed = 1 ÷ (1 + R:R)",
        example: "R:R 2 → you need to win only 33% of trades to break even (before costs)" },
      { name: "Expectancy", what: "Average profit per trade over many trades.",
        formula: "Expectancy = (Win % × Average win) − (Loss % × Average loss)",
        example: "40% wins of ₹3,000, 60% losses of ₹1,500 → 1,200 − 900 = ₹300 per trade" }
    ]}
  ];
})();
