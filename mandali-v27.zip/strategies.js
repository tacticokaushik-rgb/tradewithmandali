/* Mandali "Option strategies": every common strategy explained from zero, with a live payoff chart
   (computed from the legs with Black–Scholes), where it works, where it fails, and real Nifty episodes. */
(function () {
  const V = "20261012b";
  const load = () => window.STRATS ? Promise.resolve() : (window._stLoading = window._stLoading || new Promise((res) => {
    const s = document.createElement("script"); s.src = "strategies-data.js?v=" + V; s.onload = res; s.onerror = () => { window._stLoading = null; res(); }; document.head.appendChild(s);
  }));
  const FREE = new Set(["long-call", "long-put", "bull-call", "bear-put", "protective-put"]);
  const locked = (id) => typeof isPro === "function" && !isPro() && !FREE.has(id);
  const CAT = { bullish: ["Bullish", "📈", "up"], bearish: ["Bearish", "📉", "down"], neutral: ["Range-bound", "↔️", "flat"], volatile: ["Big move", "⚡", "warn"], hedge: ["Hedging", "🛡️", "flat"] };
  const LVL = ["", "Beginner", "Intermediate", "Advanced"];
  const S0 = 24000, IV = 0.14, R = 0.065, NEAR = 7, FAR = 35;
  const lot = () => { try { return (window.MKT && MKT.contracts && MKT.contracts[0].lot) || 65; } catch (e) { return 65; } };

  /* ---------- Pricing ---------- */
  const ncdf = (x) => { const t = 1 / (1 + 0.2316419 * Math.abs(x)), d = 0.3989423 * Math.exp(-x * x / 2);
    const p = d * t * (0.3193815 + t * (-0.3565638 + t * (1.781478 + t * (-1.821256 + t * 1.330274)))); return x > 0 ? 1 - p : p; };
  const bs = (type, S, K, T) => {
    if (type === "F") return S;
    if (T <= 1e-6) return Math.max(0, type === "C" ? S - K : K - S);
    const v = IV, d1 = (Math.log(S / K) + (R + v * v / 2) * T) / (v * Math.sqrt(T)), d2 = d1 - v * Math.sqrt(T);
    return type === "C" ? S * ncdf(d1) - K * Math.exp(-R * T) * ncdf(d2) : K * Math.exp(-R * T) * ncdf(-d2) - S * ncdf(-d1);
  };
  const legsOf = (st) => st.legs.map(([t, s, k, q, e]) => ({ t, s, K: S0 + (k || 0), q: q == null ? 1 : Math.abs(q), sideQ: s * (q == null ? 1 : Math.abs(q)), e: e === "f" ? "f" : "n" }));
  function model(st) {
    const near = st.days || NEAR, legs = legsOf(st);
    const T0 = (l) => (l.e === "f" ? FAR : near) / 365;
    legs.forEach(l => { l.entry = bs(l.t, S0, l.K, T0(l)); });
    const atExp = (S) => legs.reduce((a, l) => a + l.sideQ * (bs(l.t, S, l.K, l.e === "f" ? (FAR - near) / 365 : 0) - l.entry), 0);
    const now = (S) => legs.reduce((a, l) => a + l.sideQ * (bs(l.t, S, l.K, T0(l)) - l.entry), 0);
    const net = legs.filter(l => l.t !== "F").reduce((a, l) => a + l.sideQ * l.entry, 0); // + paid (debit), − received (credit)
    const lo = S0 * 0.94, hi = S0 * 1.06, N = 241, xs = [];
    for (let i = 0; i < N; i++) xs.push(lo + (hi - lo) * i / (N - 1));
    const ys = xs.map(atExp), yn = xs.map(now);
    // extremes over a much wider band, plus open-ended checks
    let mx = -Infinity, mn = Infinity; for (let S = S0 * 0.5; S <= S0 * 1.6; S += S0 * 0.0025) { const v = atExp(S); if (v > mx) mx = v; if (v < mn) mn = v; }
    const upSlope = atExp(S0 * 1.6) - atExp(S0 * 1.55), dnSlope = atExp(S0 * 0.5) - atExp(S0 * 0.55);
    const unlimUp = upSlope > S0 * 0.01, unlimLossUp = upSlope < -S0 * 0.01, bigDn = dnSlope > S0 * 0.01, bigLossDn = dnSlope < -S0 * 0.01;
    const be = []; for (let i = 1; i < N; i++) { const a = ys[i - 1], b = ys[i]; if ((a < 0 && b >= 0) || (a > 0 && b <= 0)) be.push(xs[i - 1] + (xs[i] - xs[i - 1]) * (-a) / (b - a)); }
    return { xs, ys, yn, net, mx, mn, unlimUp, unlimLossUp, bigDn, bigLossDn, be, legs, near };
  }

  /* ---------- Charts ---------- */
  function payoffSvg(m, big = true) {
    const W = big ? 340 : 64, H = big ? 180 : 26, P = big ? { l: 6, r: 6, t: 12, b: 22 } : { l: 1, r: 1, t: 2, b: 2 };
    const all = big ? [...m.ys, ...m.yn] : m.ys, ymax = Math.max(...all, 1), ymin = Math.min(...all, -1), pad = (ymax - ymin) * 0.08;
    const y0 = ymax + pad, y1 = ymin - pad;
    const X = (i) => P.l + (W - P.l - P.r) * i / (m.xs.length - 1), Y = (v) => P.t + (H - P.t - P.b) * (y0 - v) / (y0 - y1), XS = (S) => P.l + (W - P.l - P.r) * (S - m.xs[0]) / (m.xs[m.xs.length - 1] - m.xs[0]);
    const line = (arr) => arr.map((v, i) => (i ? "L" : "M") + X(i).toFixed(1) + " " + Y(v).toFixed(1)).join(" ");
    const zy = Y(0).toFixed(1), id = "s" + Math.random().toString(36).slice(2, 7);
    const area = `${line(m.ys)} L${X(m.xs.length - 1).toFixed(1)} ${zy} L${X(0).toFixed(1)} ${zy} Z`;
    if (!big) return `<svg class="st-mini" viewBox="0 0 ${W} ${H}" preserveAspectRatio="none" aria-hidden="true"><defs><clipPath id="${id}u"><rect x="0" y="0" width="${W}" height="${zy}"/></clipPath><clipPath id="${id}d"><rect x="0" y="${zy}" width="${W}" height="${H}"/></clipPath></defs>
      <path d="${area}" class="pf-up" clip-path="url(#${id}u)"/><path d="${area}" class="pf-dn" clip-path="url(#${id}d)"/><line x1="0" x2="${W}" y1="${zy}" y2="${zy}" class="pf-zero"/><path d="${line(m.ys)}" class="pf-line" vector-effect="non-scaling-stroke"/></svg>`;
    const sx = XS(S0).toFixed(1);
    const ticks = [m.xs[0], S0, m.xs[m.xs.length - 1]].map(S => `<text x="${XS(S).toFixed(1)}" y="${H - 6}" class="pf-tx" text-anchor="${S === S0 ? "middle" : S < S0 ? "start" : "end"}">${nfNum(S, 0)}</text>`).join("");
    const bes = m.be.filter(b => b > m.xs[0] && b < m.xs[m.xs.length - 1]).map(b => `<circle cx="${XS(b).toFixed(1)}" cy="${zy}" r="3.2" class="pf-be"/>`).join("");
    return `<svg class="st-pf" viewBox="0 0 ${W} ${H}" role="img" aria-label="Payoff chart">
      <defs><clipPath id="${id}u"><rect x="0" y="0" width="${W}" height="${zy}"/></clipPath><clipPath id="${id}d"><rect x="0" y="${zy}" width="${W}" height="${H}"/></clipPath></defs>
      <path d="${area}" class="pf-up" clip-path="url(#${id}u)"/><path d="${area}" class="pf-dn" clip-path="url(#${id}d)"/>
      <line x1="${P.l}" x2="${W - P.r}" y1="${zy}" y2="${zy}" class="pf-zero"/>
      <line x1="${sx}" x2="${sx}" y1="${P.t - 4}" y2="${H - P.b}" class="pf-spot"/>
      <path d="${line(m.yn)}" class="pf-now"/>
      <path d="${line(m.ys)}" class="pf-line"/>${bes}${ticks}
      <text x="${W - P.r}" y="${P.t}" class="pf-tx up" text-anchor="end">Profit</text><text x="${W - P.r}" y="${H - P.b - 4}" class="pf-tx dn" text-anchor="end">Loss</text></svg>`;
  }

  const legText = (l, near) => {
    if (l.t === "F") return `${l.s > 0 ? "Buy" : "Sell"} Nifty futures (or hold shares) at about ${nfNum(S0, 0)}`;
    const off = l.K - S0, typ = l.t === "C" ? "call" : "put", tag = off === 0 ? "ATM" : (l.t === "C" ? off > 0 : off < 0) ? "OTM" : "ITM";
    return `${l.s > 0 ? "Buy" : "Sell"} ${l.q} ${tag} ${typ} at ${nfNum(l.K, 0)} (${nfNum(l.K, 0)} ${l.t === "C" ? "CE" : "PE"})${l.e === "f" ? ", later expiry" : ""}, premium about ${nfNum(l.entry, 0)}`;
  };
  const rupee = (pts) => "₹" + nfNum(Math.abs(pts) * lot(), 0);

  /* ---------- Strategy page (bottom sheet) ---------- */
  window.openStrategy = (id, list) => {
    const all = window.STRATS || []; let st = all.find(x => x.id === id); if (!st) return;
    const sh = openSheet(st.name, "", { sub: "" });
    const draw = () => {
      const m = model(st), seen = new Set(), c = CAT[st.cat], lk = locked(st.id);
      sh.el.querySelector(".sheet-head h2").textContent = st.name;
      const sub = sh.el.querySelector(".sheet-sub"); if (sub) sub.innerHTML = `${c[1]} ${c[0]} · ${LVL[st.lvl]}${st.aka ? ` · also called <em>${esc(st.aka)}</em>` : ""}`;
      const seq = (list && list.length ? list : all).map(x => x.id), i = seq.indexOf(st.id);
      const prev = i > 0 ? all.find(x => x.id === seq[i - 1]) : null, next = i >= 0 && i < seq.length - 1 ? all.find(x => x.id === seq[i + 1]) : null;
      const mt = (s) => markTerms(s, seen);
      const maxP = m.unlimUp ? "Unlimited" : m.bigDn ? "Very large (grows as Nifty falls)" : `${nfNum(m.mx, 0)} pts · ${rupee(m.mx)}`;
      const maxL = m.unlimLossUp ? "Unlimited" : m.bigLossDn ? "Very large (grows as Nifty falls)" : `${nfNum(Math.abs(m.mn), 0)} pts · ${rupee(m.mn)}`;
      const simpleHtml = mt(st.simple), introHtml = mt(st.view);
      const ev = (arr, ok) => arr.map(([k, note]) => { const e = (window.STRAT_EVENTS || {})[k]; if (!e) return "";
        return `<li class="st-ev ${ok ? "ok" : "bad"}"><span class="st-ev-ic">${ok ? "✓" : "✗"}</span><div><strong>${esc(e[1])}</strong> <span class="muted small">${esc(e[0])}</span><p class="muted small" style="margin:2px 0 4px">${esc(e[2])}</p><p style="margin:0">${mt(note)}</p></div></li>`; }).join("");
      const deep = `
        <p class="sh-sec">The payoff</p>
        <div class="st-chart">${payoffSvg(m)}<div class="st-leg"><span><i class="pf-k exp"></i>At expiry</span><span><i class="pf-k now"></i>Today</span><span><i class="pf-k be"></i>Breakeven</span></div></div>
        <div class="st-stats">
          <div><span>${m.net >= 0 ? "You pay (debit)" : "You receive (credit)"}</span><strong>${nfNum(Math.abs(m.net), 0)} pts</strong><em>${rupee(m.net)} per lot</em></div>
          <div><span>Max profit</span><strong class="up">${maxP.split(" · ")[0]}</strong><em>${maxP.split(" · ")[1] ? maxP.split(" · ")[1] + " per lot" : ""}</em></div>
          <div><span>Max loss</span><strong class="down">${maxL.split(" · ")[0]}</strong><em>${maxL.split(" · ")[1] ? maxL.split(" · ")[1] + " per lot" : ""}</em></div>
          <div><span>Breakeven${m.be.length === 1 ? "" : "s"}</span><strong>${m.be.length ? m.be.map(b => nfNum(b, 0)).join(" / ") : "—"}</strong><em>at expiry</em></div>
        </div>
        <p class="muted small" style="margin:6px 0 0">Example: Nifty at ${nfNum(S0, 0)}, ${m.near} day${m.near > 1 ? "s" : ""} to expiry, IV ${Math.round(IV * 100)}%, lot of ${lot()}. Real premiums will differ; the shape is what matters.</p>
        <p class="sh-sec">How to build it</p>
        <ol class="st-legs">${m.legs.map(l => `<li class="${l.s > 0 ? "buy" : "sell"}">${mt(legText(l, m.near))}</li>`).join("")}</ol>
        <p class="sh-sec">Where it works</p><ul class="st-ul ok">${st.works.map(w => `<li>${mt(w)}</li>`).join("")}</ul>
        <p class="sh-sec">Where it fails</p><ul class="st-ul bad">${st.fails.map(w => `<li>${mt(w)}</li>`).join("")}</ul>
        ${st.won.length || st.lost.length ? `<p class="sh-sec">In the real market</p><ul class="st-evs">${ev(st.won, true)}${ev(st.lost, false)}</ul>
          <p class="muted small" style="margin:4px 0 0">Illustrations of how the structure would have behaved; actual results depend on strikes, timing and exits.</p>` : ""}
        <p class="sh-sec">The Greeks in one line</p><p style="margin:0;line-height:1.6">${mt(st.greeks)}</p>
        <div class="st-tip"><span>Mandali tip</span><p>${mt(st.tip)}</p></div>`;
      sh.body.innerHTML = `
        <div class="st-view ${c[2]}"><span>Your view</span><strong>${introHtml}</strong></div>
        <p class="sh-sec">In plain words</p><p style="margin:0;line-height:1.65">${simpleHtml}</p>
        ${lk ? `<div style="margin-top:14px">${Lock.wrap(deep, "Option strategies", { title: "Unlock the full strategy", sub: "Payoff chart, how to build it, where it works and fails, and real market examples" })}</div>` : deep}
        <p class="muted small" style="margin:14px 0 0">${t("Tap underlined words for their meaning.")} For education only, not a recommendation.</p>
        <div class="tm-nav">${prev ? `<button class="btn sm quiet" data-sgo="${prev.id}">‹ ${esc(prev.name)}</button>` : "<span></span>"}${next ? `<button class="btn sm quiet" data-sgo="${next.id}">${esc(next.name)} ›</button>` : ""}</div>`;
      sh.body.scrollTop = 0;
      $$("[data-sgo]", sh.body).forEach(b => b.onclick = () => { st = all.find(x => x.id === b.dataset.sgo); draw(); });
    };
    draw();
  };

  /* ---------- Strategy list ---------- */
  let fView = "all", fIv = "all";
  const VIEWS = [["all", "Any view"], ["bullish", "📈 Up"], ["bearish", "📉 Down"], ["neutral", "↔️ Sideways"], ["volatile", "⚡ Big move"], ["hedge", "🛡️ Protect"]];
  const IVS = [["all", "Any"], ["high", "High: sell premium"], ["low", "Low: buy options"]];
  window.viewStrategies = function () {
    section = "strategies";
    app.innerHTML = `<div class="wrap">${tabsHtml()}
      <h2 class="sec-title" style="margin:8px 0 4px">${t("Option strategies")}</h2>
      <p class="muted small" style="margin:0 0 12px">Every common strategy, explained from zero: how it's built, where it works, where it fails, and what it would have done in real Nifty moments. Tap any strategy.</p>
      <details class="card st-intro"><summary><strong>New to options? Start here</strong><span class="muted small">2-minute read</span></summary>
        <div class="st-intro-b" id="stIntro"></div></details>
      <div class="card st-finder">
        <p class="st-q">I think Nifty will…</p><div class="chips" id="stV">${VIEWS.map(([k, l]) => `<button class="chip" data-v="${k}" aria-pressed="${fView === k}">${l}</button>`).join("")}</div>
        <p class="st-q">Option prices (IV) right now are…</p><div class="chips" id="stI">${IVS.map(([k, l]) => `<button class="chip" data-i="${k}" aria-pressed="${fIv === k}">${l}</button>`).join("")}</div>
      </div>
      <input id="stQ" type="search" placeholder="Search: straddle, iron condor, hedge…" autocomplete="off" style="width:100%;margin-top:12px">
      <p class="gl-count" id="stCount"></p>
      <div id="stList"><p class="muted">Loading strategies…</p></div></div>`;
    bindTabs();
    { const at = $(".tab[aria-selected=true]") || $(".tab.active"); if (at && at.scrollIntoView) at.scrollIntoView({ block: "nearest", inline: "center" }); }
    const intro = "An option is a contract on Nifty. A call option gains when Nifty rises; a put option gains when Nifty falls. The buyer pays a price called the premium and can lose only that. The seller receives the premium but takes the risk. Every option has a strike (its price level) and an expiry date. Options lose value every day as expiry comes closer (time decay), and they get more expensive when the market is nervous (high IV). Every strategy below is just a mix of buying and selling calls and puts to shape where you make or lose money.";
    $("#stIntro").innerHTML = `<p style="margin:10px 0 0;line-height:1.65">${markTerms(intro, new Set())}</p>`;
    load().then(() => {
      if (section !== "strategies") return;
      const all = window.STRATS || [];
      if (!all.length) { $("#stList").innerHTML = msg("err", "Strategies couldn't load. Check your internet and tap Refresh on Home."); return; }
      const minis = new Map(all.map(s => [s.id, payoffSvg(model(s), false)]));
      let shown = [];
      const draw = () => {
        const q = $("#stQ").value.trim().toLowerCase();
        let rows = all.filter(s => (fView === "all" || s.cat === fView) && (fIv === "all" || s.iv === fIv || s.iv === "any"));
        if (q) rows = rows.filter(s => (s.name + " " + s.aka + " " + s.view + " " + s.simple).toLowerCase().includes(q));
        const order = ["bullish", "bearish", "neutral", "volatile", "hedge"];
        rows = rows.slice().sort((a, b) => order.indexOf(a.cat) - order.indexOf(b.cat) || a.lvl - b.lvl);
        shown = rows;
        $("#stCount").innerHTML = `${rows.length} strateg${rows.length === 1 ? "y" : "ies"}` + (isPro() ? "" : ` · <button class="linkbtn" data-lock="Option strategies">${FREE.size} free, subscribe to unlock all</button>`);
        let last = "";
        $("#stList").innerHTML = rows.length ? `<div class="card tm-list">${rows.map(s => {
          const c = CAT[s.cat], head = s.cat !== last ? `<div class="gl-letter">${c[1]} ${c[0]}</div>` : ""; last = s.cat;
          const lk = locked(s.id);
          return `${head}<button class="tm-row st-row" data-sopen="${s.id}"><span class="st-mini-w">${minis.get(s.id)}</span><span class="tm-row-t"><strong>${esc(s.name)}${lk ? ` <span class="lk-chip">🔒</span>` : ""}</strong><span>${esc(s.view)}</span><span class="st-tags"><em class="st-lv l${s.lvl}">${LVL[s.lvl]}</em></span></span><span class="sh-chev">›</span></button>`;
        }).join("")}</div>` : `<div class="card empty">No strategy matches. Try another view or clear the search.</div>`;
        $$("[data-sopen]", app).forEach(b => b.onclick = () => openStrategy(b.dataset.sopen, shown));
      };
      $$("#stV [data-v]").forEach(b => b.onclick = () => { fView = b.dataset.v; $$("#stV [data-v]").forEach(x => x.setAttribute("aria-pressed", x === b)); draw(); });
      $$("#stI [data-i]").forEach(b => b.onclick = () => { fIv = b.dataset.i; $$("#stI [data-i]").forEach(x => x.setAttribute("aria-pressed", x === b)); draw(); });
      let tm; $("#stQ").oninput = () => { clearTimeout(tm); tm = setTimeout(draw, 90); };
      draw();
    });
  };
  window._stModel = model; // for tests
})();
