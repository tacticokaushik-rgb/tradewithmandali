/* Mandali service worker: instant loads + offline fallback + push reminders */
const CACHE = "mandali-v27";
const SHELL = ["./", "index.html", "admin.html", ...["styles.css", "common.js", "config.js", "i18n.js", "nifty.js", "panch.js", "formulas.js", "features.js",
  "market-data.js", "insights-data.js", "quiz-starter.js", "glossary-data.js", "tradelog.js", "payments.js", "qrcode.js", "terms.js", "terms-data.js", "strategies.js", "strategies-data.js", "archive.js", "news-pulse.js", "media.js", "essentials.js", "lock.js"].map(f => f + "?v=20261012b"), "glossary-data.js", "manifest.webmanifest", "icon-192.png", "logo-mark.png"];
const CDN = /^(https:\/\/cdn\.jsdelivr\.net\/npm\/@supabase|https:\/\/fonts\.(googleapis|gstatic)\.com)/;

self.addEventListener("install", (e) => {
  e.waitUntil(caches.open(CACHE).then(c => c.addAll(SHELL)).catch(() => {}).then(() => self.skipWaiting()));
});
self.addEventListener("activate", (e) => {
  e.waitUntil(caches.keys().then(ks => Promise.all(ks.filter(k => k !== CACHE).map(k => caches.delete(k)))).then(() => self.clients.claim()));
});

const put = (req, res) => { if (res && (res.ok || res.type === "opaque")) { const copy = res.clone(); caches.open(CACHE).then(c => c.put(req, copy)); } return res; };
self.addEventListener("fetch", (e) => {
  const req = e.request; if (req.method !== "GET") return;
  const url = new URL(req.url), same = url.origin === self.location.origin;
  if (!same && !CDN.test(req.url)) return;
  // Pages: try the network for up to 2.5s (new deploys show up), else use the saved copy instantly.
  if (req.mode === "navigate") {
    e.respondWith(new Promise((resolve) => {
      let done = false;
      const fallback = () => caches.match(req, { ignoreSearch: true }).then(r => r || caches.match("index.html"));
      const t = setTimeout(() => fallback().then(r => { if (r && !done) { done = true; resolve(r); } }), 2500);
      fetch(req).then(res => { put(req, res); if (!done) { done = true; clearTimeout(t); resolve(res); } })
        .catch(() => fallback().then(r => { if (!done) { done = true; clearTimeout(t); resolve(r || Response.error()); } }));
    }));
    return;
  }
  // Scripts, styles, images, fonts: serve the saved copy instantly, refresh it in the background.
  e.respondWith(caches.match(req).then(hit => {
    const net = fetch(req).then(res => put(req, res)).catch(() => hit);
    return hit || net;
  }));
});

/* Show every reminder, even when the app is closed. Same-type reminders replace each other
   (tag) instead of piling up, and still buzz (renotify). */
self.addEventListener("push", (e) => {
  let d = {};
  try { d = e.data ? e.data.json() : {}; } catch (err) { d = { title: "Mandali", body: e.data && e.data.text() }; }
  const group = d.group || (d.tag && String(d.tag).split(":")[1]) || "general";
  e.waitUntil(self.registration.showNotification(d.title || "Mandali", {
    body: d.body || "", icon: "icon-192.png", badge: "icon-192.png",
    tag: "mandali-" + group, renotify: true, timestamp: Date.now(),
    vibrate: [120, 60, 120], requireInteraction: group === "class",
    data: { url: d.url || "./" }
  }));
});

/* The phone replaced our push address: tell any open app to re-register right away */
self.addEventListener("pushsubscriptionchange", (e) => {
  e.waitUntil(clients.matchAll({ type: "window", includeUncontrolled: true }).then(list => list.forEach(c => c.postMessage({ type: "push-changed" }))));
});

self.addEventListener("notificationclick", (e) => {
  e.notification.close();
  const url = (e.notification.data && e.notification.data.url) || "./";
  const internal = url.startsWith(self.location.origin) || !/^https?:/.test(url);
  e.waitUntil(clients.matchAll({ type: "window", includeUncontrolled: true }).then(list => {
    if (internal) {
      const w = list.find(c => c.url.startsWith(self.location.origin));
      if (w) return w.navigate(url).then(c => (c || w).focus()).catch(() => w.focus());
    }
    return clients.openWindow(url);
  }));
});
