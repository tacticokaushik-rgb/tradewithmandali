/* Mandali freemium: who is subscribed, blurred previews of premium sections, and the subscribe sheet.
   Locked previews never contain real premium data: preview text is scrambled sample content. */
(function () {
  /* Subscribed = admin, or an approved student whose plan hasn't expired. */
  const P = () => (typeof profile !== "undefined" ? profile : null);
  window.isPro = () => !!(P() && (profile.is_admin || (profile.status === "approved" && memberState(profile) !== "expired")));

  /* Turn readable text into same-shaped gibberish so the blur can't be "read through". */
  const scr = (s) => { let h = 7; return String(s).replace(/[A-Za-z]/g, (c) => { h = (h * 31 + c.charCodeAt(0)) % 9973; const a = c < "a" ? 65 : 97; return String.fromCharCode(a + h % 26); }).replace(/\d/g, (d) => String((+d * 7 + 3) % 10)); };
  const scrHtml = (html) => html.replace(/>([^<]+)</g, (m, t) => ">" + scr(t) + "<").replace(/\sdata-[\w-]+="[^"]*"/g, "").replace(/\shref="[^"]*"/g, "");
  window.Lock = {
    scr,
    /* Wrap any HTML as a locked, blurred block; tapping it opens the subscribe sheet. */
    wrap(html, feat, opts = {}) {
      return `<div class="lk-wrap${opts.short ? " short" : ""}" data-lock="${esc(feat)}" role="button" tabindex="0" aria-label="${esc(feat)} is for subscribers. Tap to subscribe">
        <div class="lk-blur" aria-hidden="true">${scrHtml(html)}</div>
        <div class="lk-over"><span class="lk-ic">🔒</span><strong>${esc(opts.title || "Subscribe to unlock")}</strong>${opts.sub !== false ? `<span>${esc(opts.sub || feat + " is part of the Mandali subscription")}</span>` : ""}<span class="btn sm">${P() ? "Subscribe" : "Join free, then subscribe"}</span></div>
      </div>`;
    },
    /* A small inline lock chip for list rows */
    chip: (feat) => `<span class="lk-chip" data-lock="${esc(feat)}">🔒 Subscribers</span>`
  };
  document.addEventListener("click", (e) => { const l = e.target.closest("[data-lock]"); if (!l || isPro()) return; e.preventDefault(); e.stopPropagation(); openSubscribe(l.dataset.lock); }, true);
  document.addEventListener("keydown", (e) => { if ((e.key === "Enter" || e.key === " ") && e.target.matches && e.target.matches(".lk-wrap")) { e.preventDefault(); openSubscribe(e.target.dataset.lock); } });

  window.PLAN_PERKS = {
    panch: ["Live Panch class, Monday to Friday", "Private Panch section with exclusive videos", "Everything in the Mandali app"],
    course: ["Complete Mandali course over 3 months", "Daily Nifty analysis, classes and quizzes", "Journal with mentor replies, trade log"],
    yearly: ["12 months of everything", "Best value for committed learners", "All classes, analysis and app tools"]
  };
  const UNLOCKS = ["Daily Nifty analysis with levels and OI", "What's coming before every expiry", "Full Dictionary and 246 explained Terms", "Classes, quizzes and the resource library",
    "Journal, trade log and mentor replies", "Expiry, timing and lot-size deep-dives"];

  /* ---------- Subscribe sheet ---------- */
  window.openSubscribe = (feat) => {
    const p = P(), WA = (window.MANDALI_CONFIG || {}).WHATSAPP;
    if (!p) {
      const sh0 = openSheet("Subscribe to unlock", `
        <div class="lk-login"><span class="lk-ic">🔒</span>
          <p class="lk-lede">${feat ? `<strong>${esc(feat)}</strong> is` : "This is"} for Mandali subscribers. Create a free account first (it takes a minute and needs no approval), then subscribe from inside the app.</p></div>
        <button class="btn block" data-subgo="signup">Create a free account</button>
        <button class="btn quiet block" data-subgo="login" style="margin-top:10px">I already have an account</button>
        <details class="fold" style="margin-top:16px"><summary><span>What you get with a subscription</span></summary>
          <ul class="lk-list" style="margin-top:8px">${UNLOCKS.map(u => `<li>${esc(u)}</li>`).join("")}</ul>
          <p class="muted small" style="margin:6px 0 0">${PLANS.map(pl => `${esc(pl.name)} ${inr(pl.price)} ${esc(pl.period)}`).join(" · ")}</p></details>
        ${WA ? `<a class="btn ghost block" style="margin-top:12px" target="_blank" rel="noopener" href="${waLink(WA, "Hi Mandali, I'd like to know more about joining.")}">Ask on WhatsApp</a>` : ""}`,
        { sub: "Saath Seekho. Saath Bado. Saath Rahenge." });
      $$("[data-subgo]", sh0.body).forEach(b => b.onclick = () => { sh0.close(); setTimeout(() => go(b.dataset.subgo), 230); });
      return;
    }
    const sh = openSheet(feat ? `Unlock ${feat}` : "Subscribe to Mandali", `
      <p class="lk-lede">Subscribe to avail ${feat ? `<strong>${esc(feat)}</strong> and ` : ""}everything premium in the app:</p>
      <ul class="lk-list">${UNLOCKS.map(u => `<li>${esc(u)}</li>`).join("")}</ul>
      <p class="sh-sec">Choose a plan</p>
      <div class="pay-plans">${PLANS.map(pl => `<button class="card pay-plan${pl.id === "panch" ? " cur" : ""}" data-subplan="${pl.id}">
        <span class="pf-t"><strong>${esc(pl.name)}</strong><span>${(PLAN_PERKS[pl.id] || [pl.note]).slice(0, 2).map(esc).join(" · ")}</span></span>
        <span class="pay-price"><strong>${inr(pl.price)}</strong><span>${esc(pl.period)}</span></span></button>`).join("")}</div>
      ${p ? `<p class="muted small" style="margin:8px 2px 0">Pay by scanning the UPI QR. Your access opens as soon as Mandali confirms the payment.</p>`
        : `<p class="muted small" style="margin:8px 2px 0">First create a free account (takes a minute), then pay by UPI QR inside the app.</p>
           <div class="sh-acts"><button class="btn" data-subgo="signup">Create account</button><button class="btn quiet" data-subgo="login">I already have an account</button></div>`}
      ${WA ? `<a class="btn ghost block" style="margin-top:12px" target="_blank" rel="noopener" href="${waLink(WA, `Hi Mandali, I'd like to subscribe${feat ? " (saw " + feat + " in the app)" : ""}.`)}">Ask on WhatsApp</a>` : ""}`,
      { sub: "Saath Seekho. Saath Bado. Saath Rahenge." });
    $$("[data-subplan]", sh.body).forEach(b => b.onclick = () => {
      const pl = PLANS.find(x => x.id === b.dataset.subplan);
      if (!P()) { sh.close(); setTimeout(() => go("signup"), 230); return; }
      sh.close(); setTimeout(() => openPaySheet(pl, (typeof settings !== "undefined" ? settings : {}), profile, () => go("p-plan")), 230);
    });
    $$("[data-subgo]", sh.body).forEach(b => b.onclick = () => { sh.close(); setTimeout(() => go(b.dataset.subgo), 230); });
  };

  /* ---------- Locked section pages ---------- */
  const lad = (k, cls, label, vals) => `<div class="lad ${cls}"><p class="lad-h">${label}</p>${vals.map((v, i) => `<div class="lad-row"><span>${k}${i + 1}</span><strong>${v}</strong></div>`).join("")}</div>`;
  const rows = (arr) => `<div class="card"><ul class="feed">${arr.map(([h, d]) => `<li><strong>${h}</strong><br><span class="muted small">${d}</span></li>`).join("")}</ul></div>`;
  const TEASE = {
    market: ["Daily Nifty analysis", "Support and resistance ladders, OI and options data, and the full written view, posted before the market opens.",
      () => `<article class="post card"><div class="post-head"><div><p class="post-date">Today</p><h2 class="post-title">Nifty holds the put wall as IV cools</h2></div><span class="bias bullish">Bullish</span></div>
        <div class="ladders">${lad("R", "res", "Resistance", ["25,180", "25,320"])}${lad("S", "sup", "Support", ["24,940", "24,810"])}</div>
        <p>Max Call OI sits at the round strike above while put writers defend the zone below. A close above the first resistance opens room for short covering.</p></article>`],
    insights: ["Market insights", "Seasonality, FII and DII flows, inflation, rates and event studies, charted.", () => rows([["Nifty monthly seasonality", "Average returns by month over ten years"], ["FII vs DII flows", "Who is buying the dips this month"], ["Budget-day moves", "How Nifty reacted on budget days"]])],
    classes: ["Your batch's classes", "Every class video in order, with progress, notes and doubts under each class.", () => `<ol class="lessons">${["Trading vs Investing", "How the market works", "Candlesticks that matter", "Support and resistance", "Option chain basics"].map((t, i) => `<li><span class="lesson"><span class="lesson-num">${i + 1}</span><span><span class="lesson-title">Day ${i + 1} - ${t}</span></span><span>▶</span></span></li>`).join("")}</ol>`],
    quizzes: ["Weekly quizzes", "Short weekly tests on market structure with a leaderboard.", () => rows([["Macro quiz: inflation and rates", "10 questions · closes Sunday"], ["Micro quiz: option chain reading", "10 questions · closes Sunday"]])],
    library: ["Resource library", "Class decks, notes and cheat-sheets for your batch.", () => rows([["Fibonacci cheat-sheet", "Cheat sheet · PDF"], ["Options Greeks deck", "Deck · PDF"], ["Chart pattern encyclopedia", "Notes · PDF"]])],
    start: ["Start here", "A guided path for your first weeks at Mandali.", () => rows([["Step 1: Set up your trading day", "Pre-market routine and checklist"], ["Step 2: Learn to read the option chain", "OI, PCR and max pain"]])],
    journal: ["Journal and mentor", "Write your plan before 9:15 and your review after 3:30. Mandali reads and replies.", () => rows([["Today · Plan & review", "Expecting a range between the OI walls, will sell above…"], ["💬 Mentor replied", "Good plan. Where was your stop-loss?"]])],
    patterns: ["My patterns", "What your journal reveals about your habits and accuracy.", () => rows([["Your best setup", "Opening range breakouts · 64% accuracy"], ["Costliest mistake", "Moving the stop-loss"]])],
    formulas: ["Formulas and calculators", "42 options and index formulas with live calculators: Greeks, expected move, position sizing and more.", () => rows([["Option price and Greeks", "Black-Scholes calculator"], ["Expected move", "Range from IV and days to expiry"], ["Position size", "Lots from capital and risk"]])],
    costs: ["Costs and tax", "F&O charges calculator and tax basics for traders.", () => rows([["Charges calculator", "STT, exchange fees, GST and breakeven"], ["Tax basics", "Business income, losses and audit"]])],
    archive: ["Saved analysis", "Every trading day's final advanced Nifty read, saved after the close, with what happened next and a scorecard.", () => rows([["Fri, 9 Oct · 22,520 +1.30%", "Leaning bullish · Next day +0.42% ✓"], ["Thu, 8 Oct · 22,232 −0.61%", "Bearish, moderate · Next day +1.30% ✗"], ["Wed, 7 Oct · 22,368 +0.18%", "Mixed · Next day −0.61%"]])],
    ai: ["Ask AI", "Ask any trading doubt.", () => rows([["Ask anything", "Explained simply"]])],
    "p-path": ["Learning path", "Your level and what unlocks next.", () => rows([["Beginner → Intermediate", "Classes, quizzes and journal entries"]])],
    lounge: ["Panch", "The elite Panch section: live class, exclusive videos, polls and members.", () => rows([["Live Panch class", "Monday to Friday, 2:00 PM"], ["Vault", "Exclusive Panch videos"]])]
  };
  ["vault", "live", "members"].forEach(k => TEASE[k] = TEASE.lounge);
  window.isLockedSection = (sec) => !!TEASE[sec];
  window.viewLocked = function (sec) {
    section = sec;
    const [title, desc, body] = TEASE[sec] || ["Premium", "", () => ""];
    app.innerHTML = `<div class="wrap">${tabsHtml()}
      <div class="lk-head"><span class="lk-badge">🔒 Subscribers</span><h2 class="sec-title" style="margin:8px 0 4px">${esc(title)}</h2><p class="muted" style="margin:0">${esc(desc)}</p></div>
      ${Lock.wrap(body(), title)}
      <button class="btn block" data-lock="${esc(title)}" style="margin-top:14px">${P() ? "Subscribe to unlock " + esc(title) : "Log in to open " + esc(title)}</button>
    </div>`;
    bindTabs();
  };

  /* ---------- Free Home ---------- */
  window.viewFreeHome = function () {
    section = "home";
    const p = P(), h = istNow().getHours();
    const greet = h < 12 ? "Good morning" : h < 17 ? "Good afternoon" : "Good evening";
    const first = p && p.full_name ? p.full_name.split(" ")[0] : "";
    const pending = p && p.status === "pending", expired = p && p.status === "approved" && memberState(p) === "expired";
    app.innerHTML = `<div class="wrap home">${tabsHtml()}
      <div class="mkt-strip" id="mktStrip">${mktStatusHtml()}</div>
      <div class="tick-strip" id="tickStrip" aria-label="Indices"></div>
      <div class="greet-row"><p class="greet">${greet}${first ? ", " + esc(first) : ""}</p></div>
      ${newsPulseHtml()}
      <button class="card lk-banner" data-lock="Mandali">
        <span class="lk-ic">🔓</span>
        <span class="pf-t"><strong>${expired ? "Your plan has ended" : pending ? "You're on the free plan" : p ? "You're using Mandali free" : "Welcome to Mandali"}</strong>
          <span>${expired ? "Renew to unlock analysis, classes, Terms and everything premium again." : pending ? "Subscribe to unlock the daily analysis, classes, Dictionary, Terms and more. Your plan starts as soon as Mandali confirms your payment." : p ? "Subscribe to unlock the daily analysis, classes, Dictionary, Terms and more." : "Have a look around. Create a free account in a minute, and subscribe whenever you want the full analysis, classes and more."}</span></span>
        <span class="btn sm">${expired ? "Renew" : p ? "Subscribe" : "Sign up free"}</span></button>
      ${Lock.wrap(`<div class="card"><p class="muted small" style="margin:0">Weekly goal · Week 41</p><h3 style="margin:6px 0">Be 10% better than last week</h3>
          <p style="font-family:var(--mono);font-size:1.6rem;margin:4px 0">2d 08h 15m 40s</p><p class="muted small" style="margin:0">This week's 3 steps · 1/3</p></div>`, "Weekly goals", { short: true, title: "Your weekly goal", sub: "Three steps to be 10% better every week" })}
      <div style="height:12px"></div>
      ${niftyCardHtml()}
      ${globalTroikaHtml()}
      <div style="height:12px"></div>
      ${Lock.wrap(`<div class="card"><p class="muted small" style="margin:0">Call the day</p><p style="margin:6px 0">Where will Nifty close today? Decide before 9:15.</p>
          <p><span class="pill">Bullish</span> <span class="pill">Bearish</span> <span class="pill">Sideways</span></p></div>`, "Call the day", { short: true, title: "Call the day", sub: "Make your daily call and climb the leaderboard" })}
      <p class="sec-title" style="margin:18px 0 8px">Today's Nifty analysis</p>
      ${Lock.wrap(TEASE.market[2](), "Daily Nifty analysis", { sub: "Levels, OI and the full view, every trading morning" })}
      ${marketBoardHtml()}
      <div class="home-grid" style="margin-top:14px">
        <div class="card" id="nseBox">${nseInner()}</div>
        <div class="card" id="expBox">${expiryInner()}</div>
      </div>
      ${scheduleHtml()}
      <div class="card" style="margin-top:14px">
        <p class="muted small" style="margin:0 0 6px">Upcoming</p>
        <ul class="feed">${upcomingEvents(3).map(([d, i, l]) => `<li><span aria-hidden="true">${i}</span> <strong>${esc(l)}</strong><br><span class="muted small">${shortDay(new Date(d + "T00:00:00"))}</span></li>`).join("")}</ul>
      </div>
      ${!p ? `<div class="card" style="margin-top:14px;text-align:center"><p style="margin:0 0 10px">Already a Mandali student?</p><button class="btn quiet" data-sec="login">Log in</button></div>` : ""}
      <p class="muted small disclaimer">For education only. Mandali does not give buy or sell recommendations.</p>
    </div>`;
    bindTabs();
    try { mountNifty(); } catch (e) {}
    try { mountGlobalTroika(); } catch (e) {}
    try { mountNewsPulse(); } catch (e) {}
    try { mountMarketBoard(); } catch (e) {}
  };

  /* ---------- Top bar for non-subscribers ---------- */
  window.freeTop = function () {
    const p = P();
    topActions.innerHTML = `<button class="tb-btn tb-lang" id="langBtn" aria-label="${t("Language")}">${LANG === "hi" ? "EN" : "हिं"}</button>
      ${p ? `<button class="tb-admin" id="topSub">${p.status === "approved" ? "Renew" : "Subscribe"}</button>` : `<button class="tb-admin" id="topLogin">Log in</button>`}`;
    $("#langBtn").onclick = () => { setLang(LANG === "hi" ? "en" : "hi"); freeTop(); go(section || "home", "replace"); };
    const a = $("#topLogin"); if (a) a.onclick = () => go("login");
    const b = $("#topSub"); if (b) b.onclick = () => openSubscribe();
  };
})();
