// Indian market reference data. Update and re-upload when NSE/SEBI change rules.
window.MKT = {
  asOf: "8 Oct 2026",
  // NSE equity & equity-derivatives trading holidays 2026 (weekdays)
  holidays: [
    ["2026-01-15", "Municipal Corporation Election (Maharashtra)"],
    ["2026-01-26", "Republic Day"],
    ["2026-03-03", "Holi"],
    ["2026-03-26", "Shri Ram Navami"],
    ["2026-03-31", "Shri Mahavir Jayanti"],
    ["2026-04-03", "Good Friday"],
    ["2026-04-14", "Dr. Baba Saheb Ambedkar Jayanti"],
    ["2026-05-01", "Maharashtra Day"],
    ["2026-05-28", "Bakri Id"],
    ["2026-06-26", "Muharram"],
    ["2026-09-14", "Ganesh Chaturthi"],
    ["2026-10-02", "Mahatma Gandhi Jayanti"],
    ["2026-10-20", "Dussehra"],
    ["2026-11-10", "Diwali Balipratipada"],
    ["2026-11-24", "Guru Nanak Jayanti"],
    ["2026-12-25", "Christmas"]
  ],
  muhurat: ["2026-11-08", "Diwali Muhurat trading (Sunday, timings announced by NSE)"],
  contracts: [
    { name: "Nifty 50", ex: "NSE", lot: 65, weekly: "Every Tuesday", monthly: "Last Tuesday" },
    { name: "Bank Nifty", ex: "NSE", lot: 30, weekly: "None", monthly: "Last Tuesday" },
    { name: "Fin Nifty", ex: "NSE", lot: 60, weekly: "None", monthly: "Last Tuesday" },
    { name: "Midcap Select", ex: "NSE", lot: 120, weekly: "None", monthly: "Last Tuesday" },
    { name: "Nifty Next 50", ex: "NSE", lot: 25, weekly: "None", monthly: "Last Tuesday" },
    { name: "Sensex", ex: "BSE", lot: 20, weekly: "Every Thursday", monthly: "Last Thursday" }
  ],
  // Dated market-moving events beyond MKT.events: [date, flag, label, impact (H/M), why it matters]
  watch: [
    ["2026-10-14", "🇮🇳", "WPI inflation for September (around mid-month)", "M", "Wholesale prices hint at company margins and future retail inflation."],
    ["2026-10-28", "🇺🇸", "US Fed decision (FOMC, 27–28 Oct; ~11:30 PM IST)", "H", "A cut or a hawkish surprise moves the dollar, FII flows and the next morning's gap."],
    ["2026-11-01", "🇮🇳", "GST collections and October auto sales", "M", "Read on consumption; auto stocks react on the next trading day."],
    ["2026-11-03", "🇺🇸", "US midterm elections", "M", "Global risk mood can swing; watch GIFT Nifty and US futures."],
    ["2026-11-06", "🇺🇸", "US jobs report (usually first Friday, ~6–7 PM IST)", "M", "Strong jobs data can lift US yields and the dollar, pressuring emerging markets."],
    ["2026-12-01", "🇮🇳", "GST collections and November auto sales", "M", "Consumption read for the festive month."],
    ["2026-12-04", "🇺🇸", "US jobs report (usually first Friday, ~6–7 PM IST)", "M", "Shapes expectations for the Fed's December meeting."],
    ["2026-12-09", "🇺🇸", "US Fed decision (FOMC, 8–9 Dec; ~12:30 AM IST on the 10th)", "H", "Last Fed meeting of the year, with new projections (dot plot)."]
  ],
  events: [
    ["2026-10-07", "RBI policy decision (MPC)"],
    ["2026-10-12", "CPI inflation for September"],
    ["2026-10-15", "Q2 results season in full swing (till mid-Nov)"],
    ["2026-11-12", "CPI inflation for October"],
    ["2026-11-30", "GDP data, Jul to Sep quarter (expected)"],
    ["2026-12-04", "RBI policy decision (MPC)"],
    ["2027-01-12", "CPI inflation for December"],
    ["2027-02-01", "Union Budget 2027-28 (expected)"],
    ["2027-02-05", "RBI policy decision (MPC)"]
  ],
  // Approximate charges for index F&O on NSE (check your broker's contract note)
  rates: {
    options: { stt: 0.0015, txn: 0.0003503, stamp: 0.00003, sttOn: "sell premium" },
    futures: { stt: 0.0005, txn: 0.0000173, stamp: 0.00002, sttOn: "sell value" },
    sebi: 0.000001, gst: 0.18
  }
};
