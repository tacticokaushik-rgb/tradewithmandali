// Mandali Insights data. Update these numbers and re-upload to refresh the charts.
window.INSIGHTS = {
  asOf: "5 Oct 2026",
  seasonality: {
    note: "Nifty 50 monthly returns, Jan 2017 to Sep 2026 (10 years; Oct to Dec use 9 years).",
    source: "Monthly returns: Forecaster.biz NIFTY 50 seasonality table",
    months: ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"],
    avg:    [-0.14,-1.11,-1.54,3.80,0.76,1.58,2.87,1.14,-0.68,0.97,2.65,1.77],
    median: [-0.43,-0.99,1.34,2.74,0.73,1.12,3.43,0.14,-0.24,3.51,1.87,0.93],
    upPct:  [20,30,60,80,50,60,80,50,50,67,67,56]
  },
  nifty2026: {
    months: ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep"],
    ret:    [-3.10,-0.56,-11.31,7.46,-1.87,1.35,2.17,-1.24,-6.06]
  },
  flows: {
    note: "Cash market, provisional (NSE), ₹ crore. FII = foreign, DII = domestic institutions.",
    source: "Jan to Aug: NiftyTrader monthly aggregates. Sep: Moneycontrol.",
    months: ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep"],
    fii: [-41435,-6641,-122540,-70135,-55963,-49029,-5779,-7532,-44013],
    dii: [69221,38423,142960,51064,82669,85800,35099,58268,76030]
  },
  cpi: {
    note: "Yearly average CPI inflation (%). RBI target 4% (band 2% to 6%).",
    source: "IndiaInflation.com (MoSPI data)",
    years: ["2014","2015","2016","2017","2018","2019","2020","2021","2022","2023","2024","2025"],
    rate:  [6.7,4.9,5.0,3.3,4.0,3.7,6.6,5.1,6.7,5.7,5.0,2.2],
    latest: [["Jan 2026", 2.74], ["Jun 2026", 4.38], ["Jul 2026", 4.45], ["Aug 2026", 4.82]]
  },
  repo: {
    source: "RBI monetary policy statements, via IndiaInflation.com",
    dates: ["Jan 14","Jan 15","Mar 15","Jun 15","Sep 15","Apr 16","Oct 16","Aug 17","Jun 18","Aug 18","Feb 19","Apr 19","Jun 19","Aug 19","Oct 19","Mar 20","May 20","May 22","Jun 22","Aug 22","Sep 22","Dec 22","Feb 23","Feb 25","Apr 25","Jun 25","Dec 25","Oct 26"],
    rate:  [8.00,7.75,7.50,7.25,6.75,6.50,6.25,6.00,6.25,6.50,6.25,6.00,5.75,5.40,5.15,4.40,4.00,4.40,4.90,5.40,5.90,6.25,6.50,6.25,6.00,5.50,5.25,5.25]
  },
  gdp: { latest: "7.8%", label: "Real GDP growth, Q1 FY27 (Apr to Jun 2026)", prev: "6.9% a year earlier", source: "MoSPI, Aug 2026 (new series, base 2022-23)" },
  muhurat: {
    source: "HDFC Sky, Business Standard, PTI",
    years: ["2016","2017","2018","2019","2020","2021","2022","2023","2024","2025"],
    ret:   [-0.14,-0.63,0.65,0.37,0.47,0.49,0.88,0.52,0.40,0.10]
  },
  budget: {
    source: "Moneycontrol via PL India; 2026: HSBC MF market flash",
    years: ["2016","2017","2018","2019","2020","2021","2022","2023","2024","2025","2026"],
    ret:   [-0.6,1.8,-0.2,-1.1,-2.5,4.7,1.4,-0.26,-0.13,-0.11,-1.96]
  },
  calendar: [
    ["7 Oct 2026", "RBI policy decision (MPC)", "Repo rate now 5.25%"],
    ["12 Oct 2026", "CPI inflation for September", "August was 4.82%"],
    ["Mid Oct to mid Nov", "Q2 results season", "Banks, IT and FMCG report July to September earnings"],
    ["8 Nov 2026", "Diwali Muhurat trading (Sunday)", "Nifty rose in 8 of the last 10 sessions"],
    ["4 Dec 2026", "RBI policy decision (MPC)", ""],
    ["Jan to Feb 2027", "Q3 results season", ""],
    ["1 Feb 2027 (expected)", "Union Budget 2027-28", "Budget day 2026: Nifty fell 1.96%"],
    ["5 Feb 2027", "RBI policy decision (MPC)", ""]
  ]
};
