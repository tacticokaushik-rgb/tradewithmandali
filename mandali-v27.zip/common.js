(function () {
  const cfg = window.MANDALI_CONFIG || {};
  window.CFG = cfg;

  const configured = cfg.SUPABASE_URL && !cfg.SUPABASE_URL.includes("YOUR-PROJECT")
    && cfg.SUPABASE_ANON_KEY && !cfg.SUPABASE_ANON_KEY.includes("YOUR-");
  window.sb = configured && window.supabase
    ? window.supabase.createClient(cfg.SUPABASE_URL, cfg.SUPABASE_ANON_KEY)
    : null;

  window.$ = (s, r = document) => r.querySelector(s);
  window.$$ = (s, r = document) => Array.from(r.querySelectorAll(s));

  window.esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) =>
    ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

  window.msg = (kind, text) => `<div class="msg ${kind}" role="status">${esc(text)}</div>`;

  window.friendly = (err) => {
    const m = (err && err.message) || String(err || "Something went wrong.");
    if (/invalid login credentials/i.test(m)) return "Email or password is incorrect.";
    if (/email not confirmed/i.test(m)) return "Confirm your email first. Check your inbox for the link.";
    if (/already registered/i.test(m)) return "This email already has an account. Log in instead.";
    if (/rate limit/i.test(m)) return "Too many attempts. Wait a few minutes and try again.";
    return m;
  };

  // Turn any YouTube / Vimeo / Bunny / Google Drive link into an embeddable player URL
  window.toEmbed = (raw) => {
    const url = String(raw || "").trim();
    let m;
    if (/player\.vimeo\.com|iframe\.mediadelivery\.net\/embed/.test(url)) return url;
    if ((m = url.match(/(?:youtube\.com\/(?:watch\?(?:.*&)?v=|embed\/|shorts\/|live\/)|youtu\.be\/)([\w-]{11})/)))
      return `https://www.youtube-nocookie.com/embed/${m[1]}?rel=0&modestbranding=1`;
    if ((m = url.match(/vimeo\.com\/(?:video\/)?(\d+)(?:\/([\da-f]+))?/)))
      return `https://player.vimeo.com/video/${m[1]}${m[2] ? `?h=${m[2]}` : ""}`;
    if ((m = url.match(/drive\.google\.com\/(?:file\/d\/|open\?id=)([\w-]+)/)))
      return `https://drive.google.com/file/d/${m[1]}/preview`;
    if ((m = url.match(/(?:iframe|video)\.mediadelivery\.net\/(?:embed|play)\/(\d+)\/([\w-]+)/)))
      return `https://iframe.mediadelivery.net/embed/${m[1]}/${m[2]}`;
    return url;
  };

  window.fmtDate = (d) => d
    ? new Date(d).toLocaleString("en-IN", { day: "numeric", month: "short", hour: "numeric", minute: "2-digit" })
    : "Never";

  window.batchMark = (name) => {
    const m = String(name || "").match(/\d+/);
    return m ? m[0] : (String(name || "?").trim()[0] || "?").toUpperCase();
  };

  window.normPhone = (p) => {
    let d = String(p || "").replace(/\D/g, "");
    if (d.length === 11 && d.startsWith("0")) d = d.slice(1);
    if (d.length === 10) d = "91" + d;
    return d;
  };
  window.welcomeText = (name, batchLabel, portalUrl) =>
    `Hi ${name || "there"} 👋\n\nYou're approved! Welcome to Mandali 🎉` +
    (batchLabel ? `\nYou've been added to ${batchLabel}.` : "") +
    `\n\nOpen your classes here: ${portalUrl}\n\nBe the best trader you can be.\n- Team Mandali`;

  window.PLANS = [
    { id: "panch", name: "Panch batch", price: 4999, months: 1, period: "per month", note: "Monthly Panch batch access" },
    { id: "course", name: "Mandali complete course", price: 14999, months: 3, period: "for 3 months", note: "Full 3-month course" },
    { id: "yearly", name: "Yearly subscription", price: 25000, months: 12, period: "per year", note: "12 months of everything" }
  ];
  window.planFor = (name) => PLANS.find(p => p.name === name) || null;

  window.memberState = (p) => {
    if (!p || !p.paid_until) return "none";
    const t = todayIST();
    if (p.paid_until < t) return "expired";
    const days = (new Date(p.paid_until) - new Date(t)) / 86400000;
    return days <= 7 ? "soon" : "active";
  };
  window.memberLabel = (st) => ({ active: "Active", soon: "Renew soon", expired: "Expired", none: "Not started" }[st]);
  window.memberClass = (st) => ({ active: "bullish", soon: "sideways", expired: "bearish", none: "neutral" }[st]);
  window.inr = (n) => "₹" + Number(n || 0).toLocaleString("en-IN");
  window.reminderText = (p, portalUrl) => {
    const st = memberState(p);
    const when = p.paid_until ? (st === "expired" ? `ended on ${fmtDay(p.paid_until)}` : `ends on ${fmtDay(p.paid_until)}`) : "is due";
    return `Hi ${p.full_name || "there"} 👋\n\nA quick reminder: your Mandali membership ${when}.` +
      (p.fee_amount ? ` Renewal amount: ${inr(p.fee_amount)}.` : "") +
      `\n\nPay from the app: ${portalUrl} → Profile → Current plan → choose your plan\n\nBe the best trader you can be.\n- Team Mandali`;
  };

  // ---- Trade journal maths ----
  window.tradePnl = (t) => {
    if (t.exit == null || t.entry == null || !t.qty) return null;
    const move = t.direction === "short" ? t.entry - t.exit : t.exit - t.entry;
    return move * t.qty - (+t.fees || 0);
  };
  window.tradeR = (t) => {
    if (t.stop == null || t.exit == null || t.entry == null) return null;
    const risk = Math.abs(t.entry - t.stop);
    if (!risk) return null;
    return (t.direction === "short" ? t.entry - t.exit : t.exit - t.entry) / risk;
  };
  window.journalStats = (list) => {
    const closed = list.filter(t => tradePnl(t) != null);
    const pnls = closed.map(tradePnl);
    const wins = pnls.filter(p => p > 0), losses = pnls.filter(p => p < 0);
    const sum = (a) => a.reduce((x, y) => x + y, 0);
    const rs = closed.map(tradeR).filter(r => r != null);
    const by = (key) => {
      const m = {};
      closed.forEach(t => { const k = t[key] || "Other"; m[k] = m[k] || { pnl: 0, n: 0, wins: 0 }; m[k].pnl += tradePnl(t); m[k].n++; if (tradePnl(t) > 0) m[k].wins++; });
      return m;
    };
    const mistakes = {};
    closed.forEach(t => { if (t.mistake && t.mistake !== "None") { mistakes[t.mistake] = mistakes[t.mistake] || { n: 0, cost: 0 }; mistakes[t.mistake].n++; const p = tradePnl(t); if (p < 0) mistakes[t.mistake].cost += p; } });
    const worstMistake = Object.entries(mistakes).sort((a, b) => a[1].cost - b[1].cost)[0];
    const strategies = by("strategy");
    const bestStrategy = Object.entries(strategies).sort((a, b) => b[1].pnl - a[1].pnl)[0];
    return {
      total: list.length, closed: closed.length, open: list.length - closed.length,
      net: sum(pnls), winRate: closed.length ? wins.length / closed.length * 100 : 0,
      avgWin: wins.length ? sum(wins) / wins.length : 0, avgLoss: losses.length ? sum(losses) / losses.length : 0,
      profitFactor: losses.length ? sum(wins) / Math.abs(sum(losses)) : (wins.length ? Infinity : 0),
      avgR: rs.length ? sum(rs) / rs.length : null,
      best: pnls.length ? Math.max(...pnls) : 0, worst: pnls.length ? Math.min(...pnls) : 0,
      strategies, emotions: by("emotion"), mistakes, worstMistake, bestStrategy
    };
  };

  window.waLink = (number, text) =>
    `https://wa.me/${String(number || "").replace(/\D/g, "")}?text=${encodeURIComponent(text || "")}`;

  // Count one visit per browser tab session
  window.recordLoginOnce = async () => {
    try {
      if (sessionStorage.getItem("m_login")) return;
      sessionStorage.setItem("m_login", "1");
      await sb.rpc("record_login");
    } catch (e) { /* non-critical */ }
  };

  window.todayIST = () => new Date().toLocaleDateString("en-CA", { timeZone: "Asia/Kolkata" });
  window.fmtDay = (d) => d ? new Date(d + "T00:00:00").toLocaleDateString("en-IN", { weekday: "short", day: "numeric", month: "short", year: "numeric" }) : "";
  window.biasLabel = (b) => ({ bullish: "Bullish", bearish: "Bearish", sideways: "Sideways", neutral: "Neutral", long_unwinding: "Long unwinding", short_unwinding: "Short unwinding" }[b] || "Neutral");
  window.biasHint = (b) => ({ long_unwinding: "Price falling while open interest falls: buyers are exiting their long positions. Weakness from profit-taking, not fresh selling.",
    short_unwinding: "Price rising while open interest falls: sellers are buying back (short covering). Strength from shorts exiting, not fresh buying." }[b] || "");
  /* Key-term marking: first mention = bold + underline + short meaning; Nifty-style levels in bold. */
  const TERMS = [
    ["range-bound", "moving sideways between two levels"], ["basis points", "hundredths of a percent: 25 bps = 0.25%"], ["SIPs", "fixed monthly investments into mutual funds"], ["CRR", "cash banks must park with the RBI"], ["fiscal deficit", "how much more the government spends than it earns"], ["call option", "right to profit if the price goes up; the buyer pays a premium"], ["put option", "right to profit if the price goes down; the buyer pays a premium"],
    ["IV crush", "sharp fall in option prices after an event, as fear drains out"], ["time decay", "options lose a little value every day as expiry nears"],
    ["intrinsic value", "what the option is worth if it expired right now"], ["time value", "the part of the premium paid for time and uncertainty"],
    ["breakevens", "the prices where the trade neither makes nor loses money"], ["breakeven", "the price where the trade neither makes nor loses money"],
    ["strikes", "the fixed price levels written into options"], ["strike", "the fixed price level written into an option"],
    ["OTM", "out of the money: the strike has no value yet"], ["ITM", "in the money: the strike already has value"],
    ["naked", "sold without a protective option, so the risk is open-ended"], ["credit", "money you receive when you open the trade"], ["debit", "money you pay when you open the trade"],
    ["vega", "how much an option gains when IV rises by 1%"], ["gamma", "how fast delta changes when the price moves"], ["Greeks", "numbers that show how an option reacts to price, time and fear"],
    ["futures", "a contract to buy or sell Nifty at a fixed price on expiry"], ["lot size", "the minimum quantity you can trade (Nifty: 65)"], ["hedge", "a position that limits the loss on another"],
    ["margin", "money your broker blocks when you sell options or futures"], ["put-call parity", "the fixed price link between calls, puts and futures"],
    ["skew", "puts usually cost more than calls at the same distance, because traders pay for crash protection"],
    ["PCR", "put-call ratio"], ["Max Call OI", "biggest call wall, acts as resistance"], ["Max Put OI", "biggest put wall, acts as support"],
    ["Max Pain", "strike where option buyers lose most"], ["OI", "open interest, open contracts"], ["DTE", "days to expiry"],
    ["IV", "implied volatility"], ["India VIX", "fear gauge"], ["VIX", "fear gauge"], ["ATR", "average daily range, 14 days"],
    ["advance-decline ratio", "stocks up ÷ stocks down"], ["breadth", "how many stocks joined the move"], ["divergence", "index and stocks disagree"],
    ["DEMA", "double EMA, reacts faster with less lag"], ["VWMA", "volume-weighted average, heavy-volume days count more"],
    ["EMA", "exponential average, recent days weigh more"], ["SMA", "simple average of closing prices"],
    ["RSI", "momentum score 0–100; above 70 stretched up, below 30 stretched down"], ["confluence", "several levels stacked together, stronger"],
    ["golden cross", "50-day average crosses above 200-day, long-term bullish"], ["death cross", "50-day average crosses below 200-day, long-term bearish"],
    ["relative strength", "how a sector did versus Nifty"], ["risk-on", "money moving to aggressive sectors"], ["risk-off", "money hiding in defensive sectors"],
    ["defensive", "steady sectors like FMCG and pharma"],
    ["CPR", "Central Pivot Range: band between (H+L)/2 and the pivot"], ["opening range", "high and low of the first 15 minutes"],
    ["trend day", "opens at one end of the range, closes at the other"], ["reversal day", "early move fully rejected by the close"],
    ["realized volatility", "how much Nifty actually moved, annualized"], ["percentile", "share of past readings below today's"],
    ["breakevens", "where an option trade starts making money at expiry"], ["Long buildup", "price up + OI up: fresh buying"],
    ["Short buildup", "price down + OI up: fresh selling"],
    ["carry", "normal futures premium from interest cost"], ["FIIs", "foreign institutional investors"], ["DIIs", "domestic institutions: mutual funds, insurers"], ["expected move", "1-day range implied by India VIX (about 68% odds)"],
    ["put writing", "sellers expect price to hold above"], ["call writing", "sellers expect price to stay below"],
    ["short covering", "sellers buying back, pushes price up"], ["long unwinding", "buyers exiting, pushes price down"],
    ["usual daily move", "20-day average % change"], ["range", "high minus low"], ["battle lines", "key levels to watch"],
    ["Range expansion", "bigger day than normal"], ["Range contraction", "smaller day than normal"],
    ["unfilled", "price never returned to yesterday's close"], ["was filled", "price came back to yesterday's close"],
    ["20-day average", "short-term trend line"], ["50-day average", "medium-term trend line"],
    ["trapped", "stuck in losing positions"], ["institutional participation", "big funds involved"],
    ["support", "level where buyers step in"], ["resistance", "level where sellers step in"], ["option premiums", "option prices"],
    ["gap", "open far from yesterday's close"], ["expiry", "contract end date"],
    ["Pivot", "(High + Low + Close) ÷ 3, the day's balance point"], ["theta", "daily loss of an option's time value"],
    ["delta", "how much an option moves per 1-point move in Nifty"], ["straddle", "buying or selling both ATM call and put"],
    ["ATM", "at-the-money, strike nearest to spot"], ["premium", "the price of an option"]
  ];
  window.GLOSSARY = TERMS;
  const reEsc = (x) => x.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  window.markTerms = (text, seen = new Set()) => {
    let h = esc(text);
    const toks = [];
    const keep = (html) => { toks.push(html); return "\u0000" + (toks.length - 1) + "\u0000"; };
    for (const [term, gloss] of TERMS) {
      const ci = term !== term.toUpperCase();
      const re = new RegExp(`(^|[^A-Za-z])(${reEsc(term)})(?![A-Za-z])`, ci ? "i" : "");
      const m = h.match(re); if (!m) continue;
      const key = term.toLowerCase(); if (seen.has(key)) continue;
      seen.add(key);
      h = h.replace(re, (all, pre, w) => pre + keep(`<button type="button" class="kt" data-tip="${esc(gloss)}">${w}</button>`));
    }
    h = h.replace(/(^|[^\w,.])([+−-]?\d{1,3}(?:,\d{2,3})+(?:\.\d+)?|[+−-]?\d+(?:\.\d+)?%|[+−-]?\d+(?:\.\d+)?\s?(?:Cr|cr|lakh|L)\b|\d+(?:\.\d+)?x|\d+(?:\.\d+)?\s(?:points|pts|bps))(?![\w])/g, (a, pre, n) => pre + keep(`<strong>${n}</strong>`));
    return h.replace(/\u0000(\d+)\u0000/g, (_, i) => toks[+i]);
  };

  const lvlList = (txt) => String(txt || "").split(/\s*(?:\/|\||;|\n)\s*/).map(x => x.trim()).filter(Boolean);
  window.postCard = (p, big) => {
    const seen = new Set(), sup = lvlList(p.support), res = lvlList(p.resistance);
    const ladder = (arr, k, cls, label) => arr.length ? `<div class="lad ${cls}"><p class="lad-h">${label}</p>${arr.map((v, i) => `<div class="lad-row"><span>${k}${i + 1}</span><strong>${esc(v)}</strong></div>`).join("")}</div>` : "";
    const paras = (txt) => String(txt).split(/\n{2,}|\n(?=[-•*]\s)/).map(x => x.trim()).filter(Boolean)
      .map(x => /^[-•*]\s/.test(x) ? `<li>${markTerms(x.replace(/^[-•*]\s+/, ""), seen)}</li>` : `<p>${markTerms(x, seen).replace(/\n/g, "<br>")}</p>`).join("")
      .replace(/(<li>.*?<\/li>)+/gs, m => `<ul>${m}</ul>`);
    return `
    <article class="post${big ? " card" : ""}">
      <div class="post-head">
        <div>
          <p class="post-date">${fmtDay(p.post_date)}${p.post_date === todayIST() ? " · today" : ""}</p>
          <h2 class="post-title">${esc(p.title || "Nifty analysis")}</h2>
        </div>
        <span class="bias ${esc(p.bias)}"${biasHint(p.bias) ? ` title="${esc(biasHint(p.bias))}"` : ""}>${biasLabel(p.bias)}</span>
      </div>
      ${biasHint(p.bias) ? `<p class="bias-hint ${esc(p.bias)}">${esc(biasHint(p.bias))}</p>` : ""}
      ${(sup.length || res.length) ? `<div class="ladders">${ladder(res, "R", "res", "Resistance")}${ladder(sup, "S", "sup", "Support")}</div>` : ""}
      ${p.oi_notes || p.body ? `<details class="fold"><summary><span>${t("Read full analysis")}</span></summary>
        ${p.oi_notes ? `<p class="post-lbl">OI and options data</p><div class="post-body">${paras(p.oi_notes)}</div>` : ""}
        ${p.body ? `<p class="post-lbl">Analysis</p><div class="post-body">${paras(p.body)}</div>` : ""}
        <p class="muted small disclaimer">${t("Tap underlined words for their meaning.")} ${t("For education only, not investment advice.")}</p>
      </details>` : ""}
    </article>`;
  };

  /* Tap-to-explain popover for .kt terms */
  let tipEl = null;
  const closeTip = () => { if (tipEl) { tipEl.remove(); tipEl = null; } document.querySelectorAll(".kt[aria-expanded='true']").forEach(b => b.setAttribute("aria-expanded", "false")); };
  document.addEventListener("click", (e) => {
    const k = e.target.closest && e.target.closest(".kt[data-tip]");
    if (!k) { if (tipEl && !e.target.closest(".kt-tip")) closeTip(); return; }
    e.preventDefault(); e.stopPropagation();
    const same = k.getAttribute("aria-expanded") === "true"; closeTip(); if (same) return;
    tipEl = document.createElement("div"); tipEl.className = "kt-tip"; tipEl.setAttribute("role", "tooltip");
    tipEl.innerHTML = `<strong>${esc(k.textContent)}</strong><span>${esc(k.dataset.tip)}</span>`;
    document.body.appendChild(tipEl); k.setAttribute("aria-expanded", "true");
    const r = k.getBoundingClientRect(), w = Math.min(280, window.innerWidth - 24);
    tipEl.style.width = w + "px";
    tipEl.style.left = Math.max(12, Math.min(r.left + r.width / 2 - w / 2, window.innerWidth - w - 12)) + "px";
    const below = r.bottom + 8 + tipEl.offsetHeight < window.innerHeight;
    tipEl.style.top = (below ? r.bottom + 8 : r.top - tipEl.offsetHeight - 8) + window.scrollY + "px";
  });
  document.addEventListener("keydown", (e) => { if (e.key === "Escape") closeTip(); });
  window.addEventListener("scroll", closeTip, { passive: true });

  let toastTimer;
  window.toast = (text) => {
    let el = $("#toast");
    if (!el) { el = document.createElement("div"); el.id = "toast"; el.className = "toast"; el.setAttribute("role", "status"); document.body.appendChild(el); }
    el.textContent = text; el.classList.remove("hidden");
    clearTimeout(toastTimer); toastTimer = setTimeout(() => el.classList.add("hidden"), 2800);
  };

  window.notConfigured = () => {
    document.getElementById("app").innerHTML =
      `<div class="wrap narrow" style="padding-top:48px">${msg("err",
        "The portal isn't connected yet. Open config.js and paste your Supabase URL and anon key (see SETUP.md).")}</div>`;
  };
})();

/* ---------- Shared: exact timestamps, bottom sheets, back/forward navigation ---------- */
(function () {
  const TZ = "Asia/Kolkata";
  const ymdIST = (d) => new Date(d).toLocaleDateString("en-CA", { timeZone: TZ });
  const timeIST = (d) => new Date(d).toLocaleTimeString("en-IN", { timeZone: TZ, hour: "numeric", minute: "2-digit", hour12: true }).replace(/\s?([ap])\.?m\.?/i, (m, x) => " " + x.toUpperCase() + "M");
  /* "Today, 9:12 AM" · "Yesterday, 8:47 PM" · "Tue 6 Oct, 7:05 PM" (always IST) */
  window.stamp = (iso) => {
    if (!iso) return "";
    const d = new Date(iso); if (isNaN(d)) return "";
    const day = ymdIST(d), today = ymdIST(Date.now()), yest = ymdIST(Date.now() - 86400e3);
    const lbl = day === today ? "Today" : day === yest ? "Yesterday"
      : d.toLocaleDateString("en-IN", { timeZone: TZ, weekday: "short", day: "numeric", month: "short", ...(day.slice(0, 4) !== today.slice(0, 4) ? { year: "numeric" } : {}) });
    return `${lbl}, ${timeIST(d)}`;
  };
  window.timeOnly = (iso) => iso ? timeIST(iso) : "";
  window.ymdIST = ymdIST;
  /* relative age for "how long ago" hints */
  window.agoShort = (iso) => {
    const m = Math.round((Date.now() - new Date(iso).getTime()) / 60000);
    if (m < 1) return "just now"; if (m < 60) return m + " min ago";
    const h = Math.round(m / 60); if (h < 24) return h + " hr ago";
    const dd = Math.round(h / 24); return dd + " day" + (dd === 1 ? "" : "s") + " ago";
  };

  /* Bottom sheet. Returns { el, body, close }. Back button / swipe-back closes it. */
  window.openSheet = (title, html = "", opts = {}) => {
    const el = document.createElement("div");
    el.className = "sheet-ov";
    el.innerHTML = `<div class="sheet" role="dialog" aria-modal="true" aria-label="${esc(title)}">
      <div class="sheet-grab" aria-hidden="true"></div>
      <div class="sheet-head"><h2>${esc(title)}</h2><button class="sheet-x" aria-label="Close">✕</button></div>
      ${opts.sub ? `<p class="sheet-sub">${opts.sub}</p>` : ""}
      <div class="sheet-body">${html}</div></div>`;
    document.body.appendChild(el);
    document.body.classList.add("sheet-open");
    requestAnimationFrame(() => el.classList.add("on"));
    const close = () => {
      if (el.dataset.closing) return;
      el.dataset.closing = "1"; el.classList.remove("on");
      setTimeout(() => { el.remove(); if (!$(".sheet-ov")) document.body.classList.remove("sheet-open"); }, 220);
    };
    el.addEventListener("click", (e) => { if (e.target === el) close(); });
    el.querySelector(".sheet-x").onclick = close;
    el._close = close;
    return { el, body: el.querySelector(".sheet-body"), close };
  };

  /* Navigation: every screen and every popup gets a history entry, so the phone's back
     gesture and the ‹ › buttons move between screens instead of leaving the app. */
  const OV = ".sheet-ov, .welcome-overlay, #why, .md-view";
  let depth = 0, ignore = 0, onRoute = null;
  const live = () => $$(OV).filter(x => !x.dataset.closing);
  const sync = () => {
    const n = live().length;
    while (n > depth) { history.pushState({ ...(history.state || {}), ov: depth + 1 }, ""); depth++; }
    if (n < depth) { const k = depth - n; depth = n; ignore += k; history.go(-k); }
    updateBtns();
  };
  const closeTop = () => {
    const all = live(); const top = all[all.length - 1]; if (!top) return false;
    depth = Math.max(0, depth - 1);
    if (top._close) top._close();
    else if (top.id === "why") { const b = $("#whyClose", top); top.dataset.closing = "1"; b ? b.click() : top.remove(); }
    else { const b = top.querySelector("#cj, [data-close], .btn.quiet.block"); top.dataset.closing = "1"; if (b && b.closest(OV) === top) b.click(); else top.remove(); setTimeout(() => top.isConnected && top.remove(), 400); }
    return true;
  };
  function updateBtns() {
    const bk = $("#navBack"), fw = $("#navFwd"); if (!bk) return;
    const nav = window.navigation;
    if (nav && "canGoBack" in nav) { bk.disabled = !nav.canGoBack; fw.disabled = !nav.canGoForward; }
  }
  window.MNav = {
    /* route(state, {fromPop}) renders the screen for a history state */
    init(route) {
      if (onRoute) { onRoute = route; return; }
      onRoute = route;
      try { history.scrollRestoration = "manual"; } catch (e) {}
      new MutationObserver(() => sync()).observe(document.body, { childList: true });
      window.addEventListener("popstate", (e) => {
        if (ignore > 0) { ignore--; updateBtns(); return; }
        if (closeTop()) { updateBtns(); return; }
        const st = e.state || {};
        if (st.ov) { history.back(); return; } // stale popup entry: skip past it
        onRoute && onRoute(st, true);
        MNav.restoreScroll(st.y || 0);
        updateBtns();
      });
      const bar = $(".topbar");
      if (bar && !$("#navBtns")) {
        const d = document.createElement("div");
        d.id = "navBtns"; d.className = "navbtns";
        d.innerHTML = `<button id="navBack" aria-label="Back"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M15 18l-6-6 6-6"/></svg></button><button id="navFwd" aria-label="Forward"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 18l6-6-6-6"/></svg></button>`;
        bar.insertBefore(d, bar.querySelector(".actions"));
        $("#navBack").onclick = () => history.back();
        $("#navFwd").onclick = () => history.forward();
      }
      updateBtns();
    },
    /* push a new screen (or replace when it's the same screen being refreshed) */
    push(state, hash, replace) {
      const cur = history.state || {};
      try { history.replaceState({ ...cur, y: window.scrollY }, ""); } catch (e) {}
      const same = !replace && Object.keys(state).every(k => cur[k] === state[k]) && !cur.ov;
      const url = hash ? "#" + hash : location.pathname + location.search;
      if (replace || same) history.replaceState(state, "", url); else history.pushState(state, "", url);
      updateBtns();
    },
    restoreScroll(y) {
      if (!y) { window.scrollTo(0, 0); return; }
      let n = 0; const t = () => { window.scrollTo(0, y); if (Math.abs(window.scrollY - y) > 4 && n++ < 12) setTimeout(t, 80); };
      requestAnimationFrame(t);
    },
    /* smooth cross-fade between screens where the browser supports it */
    transition(fn, dir) {
      const rm = window.matchMedia && matchMedia("(prefers-reduced-motion: reduce)").matches;
      if (!document.startViewTransition || rm) return fn();
      document.documentElement.dataset.navDir = dir || "fwd";
      try { document.startViewTransition(() => { fn(); }); } catch (e) { fn(); }
    }
  };
  /* Faster taps: tell the browser we won't double-tap zoom on controls */
  document.addEventListener("touchstart", () => {}, { passive: true });
})();

/* ---------- Appearance: theme (system / light / dark), font, text size ---------- */
(function () {
  const FONTS = {
    modern: { name: "Modern", stack: '"IBM Plex Sans", "Segoe UI", Roboto, system-ui, sans-serif', css: null },
    clean: { name: "Clean", stack: '"Inter", "Segoe UI", Roboto, system-ui, sans-serif', css: "Inter:wght@400;500;600;700" },
    rounded: { name: "Rounded", stack: '"Nunito", "Segoe UI", Roboto, system-ui, sans-serif', css: "Nunito:wght@400;600;700" },
    classic: { name: "Classic", stack: '"Lora", Georgia, serif', css: "Lora:wght@400;500;600;700" },
    hindi: { name: "Hindi-friendly", stack: '"Noto Sans", "Noto Sans Devanagari", "Segoe UI", Roboto, sans-serif', css: "Noto+Sans:wght@400;600;700&family=Noto+Sans+Devanagari:wght@400;600;700" }
  };
  const SIZES = { s: 14.5, m: 16, l: 17.5, xl: 19 };
  const get = (k, d) => { try { return localStorage.getItem(k) || d; } catch (e) { return d; } };
  const set = (k, v) => { try { localStorage.setItem(k, v); } catch (e) {} };
  const mq = window.matchMedia ? matchMedia("(prefers-color-scheme: light)") : null;
  const loaded = new Set();
  function loadFont(key) {
    const f = FONTS[key]; if (!f || !f.css || loaded.has(key)) return; loaded.add(key);
    const l = document.createElement("link"); l.rel = "stylesheet";
    l.href = "https://fonts.googleapis.com/css2?family=" + f.css + "&display=swap";
    document.head.appendChild(l);
  }
  function apply() {
    const pref = get("m_theme", "dark"), font = get("m_font", "modern"), size = get("m_size", "m");
    const real = pref === "system" ? (mq && mq.matches ? "light" : "dark") : pref;
    const root = document.documentElement;
    root.dataset.theme = real;
    root.style.colorScheme = real;
    const f = FONTS[font] || FONTS.modern; loadFont(font);
    root.style.setProperty("--sans", f.stack);
    root.style.setProperty("--fs", (SIZES[size] || 16) + "px");
    const mc = document.querySelector('meta[name="theme-color"]'); if (mc) mc.content = real === "light" ? "#F2EBDF" : "#0A0D12";
    document.dispatchEvent(new CustomEvent("mandali-theme", { detail: real }));
  }
  if (mq) (mq.addEventListener ? mq.addEventListener("change", () => get("m_theme", "dark") === "system" && apply()) : mq.addListener(apply));
  window.MTheme = {
    FONTS, SIZES, apply,
    get theme() { return get("m_theme", "dark"); }, get font() { return get("m_font", "modern"); }, get size() { return get("m_size", "m"); },
    isLight: () => document.documentElement.dataset.theme === "light",
    set(k, v) { set({ theme: "m_theme", font: "m_font", size: "m_size" }[k], v); apply(); }
  };
  apply();
})();

/* ---------- Pull to refresh, offline banner, light haptics ---------- */
(function () {
  window.haptic = (ms = 8) => { try { navigator.vibrate && navigator.vibrate(ms); } catch (e) {} };
  window.MPull = {
    init(onRefresh) {
      if (window._pullOn) { window._pullFn = onRefresh; return; }
      window._pullOn = true; window._pullFn = onRefresh;
      const ind = document.createElement("div"); ind.className = "ptr"; ind.setAttribute("aria-hidden", "true");
      ind.innerHTML = `<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 11a8 8 0 10-2.3 5.7"/><path d="M20 4v7h-7"/></svg>`;
      document.body.appendChild(ind);
      let y0 = null, x0 = 0, d = 0, busy = false, armed = false;
      const blocked = (t) => document.body.classList.contains("sheet-open") || $(".welcome-overlay, .md-view") || (t && t.closest && t.closest("input, textarea, select, .chips, .tick-strip, .tl-leg, [data-noptr]"));
      window.addEventListener("touchstart", (e) => { if (busy || window.scrollY > 0 || blocked(e.target) || e.touches.length > 1) { y0 = null; return; } y0 = e.touches[0].clientY; x0 = e.touches[0].clientX; d = 0; armed = false; }, { passive: true });
      window.addEventListener("touchmove", (e) => {
        if (y0 == null) return;
        const dy = e.touches[0].clientY - y0, dx = Math.abs(e.touches[0].clientX - x0);
        if (dy <= 0 || dx > dy || window.scrollY > 0) { d = 0; ind.style.transform = ""; ind.classList.remove("show"); return; }
        d = Math.min(110, dy * 0.5);
        ind.classList.add("show"); ind.style.transform = `translate(-50%, ${d}px) rotate(${d * 3}deg)`;
        const now = d > 64; if (now && !armed) haptic(10); armed = now; ind.classList.toggle("armed", armed);
      }, { passive: true });
      window.addEventListener("touchend", async () => {
        if (y0 == null) return; y0 = null;
        if (!armed) { ind.style.transform = ""; ind.classList.remove("show"); return; }
        busy = true; ind.classList.add("spin"); ind.style.transform = "translate(-50%, 56px)";
        try { await (window._pullFn && window._pullFn()); } catch (e) {}
        busy = false; ind.classList.remove("spin", "armed", "show"); ind.style.transform = "";
      });
    }
  };
  const net = () => {
    let b = $("#offlineBar");
    if (navigator.onLine) { if (b) { b.classList.add("ok"); b.textContent = "Back online ✓"; setTimeout(() => b && b.remove(), 1500); } return; }
    if (!b) { b = document.createElement("div"); b.id = "offlineBar"; b.setAttribute("role", "status"); document.body.appendChild(b); }
    b.className = ""; b.textContent = "You're offline. Showing what's saved on this phone.";
  };
  window.addEventListener("online", net); window.addEventListener("offline", net);
  if (!navigator.onLine) document.addEventListener("DOMContentLoaded", net);
  document.addEventListener("click", (e) => { if (e.target.closest(".bottom-nav button, .btn:not(.quiet), [data-payplan], .tl-side button")) haptic(6); }, { passive: true });
})();
