/* Mandali "Saved analysis": the app's own end-of-day Nifty read, saved once per trading day
   (the most complete version wins), with what happened the next day and a running scorecard. */
(function () {
  let rows = null, filt = "all";

  /* Saved HTML is rebuilt from our own fields, but strip anything active before showing it. */
  const clean = (html) => {
    if (!html) return "";
    const doc = new DOMParser().parseFromString(`<div>${html}</div>`, "text/html"), root = doc.body.firstChild;
    root.querySelectorAll("script,style,iframe,object,embed,link,meta,form,input,button").forEach(n => n.remove());
    root.querySelectorAll("*").forEach(el => [...el.attributes].forEach(a => {
      const n = a.name.toLowerCase(), v = String(a.value || "").trim().toLowerCase();
      if (n.startsWith("on") || ((n === "href" || n === "src" || n === "xlink:href") && !/^(https?:|#)/.test(v))) el.removeAttribute(a.name);
      if (n === "href") { el.setAttribute("target", "_blank"); el.setAttribute("rel", "noopener"); }
    }));
    return root.innerHTML;
  };
  const dfmt = (d, o) => new Date(d + "T00:00:00").toLocaleDateString("en-IN", o || { weekday: "short", day: "numeric", month: "short", year: "numeric" });
  const sp = (v, k = 2) => (v >= 0 ? "+" : "−") + nfNum(Math.abs(v), k);

  /* ---------- Saving (called by the Home analysis after the close) ---------- */
  let lastSaved = "";
  window.nfMaybeSave = async (r) => {
    try {
      if (!r || r.live || typeof isPro !== "function" || !isPro() || !nfData || !nfData.daily || !nfData.daily.length) return;
      const last = nfData.daily[nfData.daily.length - 1], d = NF_DKEY(last[0]);
      const now = istNow(), today = ymd(now), mins = now.getHours() * 60 + now.getMinutes();
      if (d > today || (d === today && mins < 935)) return;                 // only after 3:35 PM on the day itself
      const extReady = nfExt && (nfExt.brAt > 0 || (nfExt.firstAt && Date.now() - nfExt.firstAt > 30000));
      if (!extReady) return;                                                // wait for breadth/sector data (or 30 s)
      const score = r.items.length + (r.bottom ? 5 : 0);
      const key = d + ":" + score; if (key === lastSaved) return; lastSaved = key;
      const data = { v: 1, d, close: r.close, chg: r.chg, pct: r.pct, range: r.range, atr: r.atr, bottom: r.bottom, levels: r.levels,
        groups: r.groups.map(g => ({ h: g.h, note: g.note || "", items: g.items.map(i => ({ t: i.t, tag: i.tag || "", tone: i.tone || "flat", x: i.x, html: i.html || "" })) })),
        source: nfExt.br && nfExt.br.source || "", savedAt: new Date().toISOString() };
      const { data: res } = await sb.rpc("save_day_analysis", { p_d: d, p_data: data, p_score: score });
      if ((res === "saved" || res === "updated") && rows) rows = null;      // archive list refreshes next time
    } catch (e) { /* saving is best-effort */ }
  };

  /* ---------- Next-day outcome ---------- */
  const candleMap = () => { const m = new Map(); ((typeof nfData !== "undefined" && nfData && nfData.daily) || []).forEach(c => m.set(NF_DKEY(c[0]), c)); return m; };
  function nextDay(d, list) {
    const cm = candleMap(), keys = [...cm.keys()].sort(), i = keys.indexOf(d);
    if (i >= 0 && i < keys.length - 1) { const c = cm.get(keys[i]), n = cm.get(keys[i + 1]); return { d: keys[i + 1], o: n[1], h: n[2], l: n[3], c: n[4], pct: (n[4] - c[4]) / c[4] * 100 }; }
    const later = (list || []).filter(x => x.d > d).sort((a, b) => a.d.localeCompare(b.d))[0];
    return later && later.data ? { d: later.d, c: later.data.close, pct: later.data.pct } : null;
  }
  const verdict = (b, nx) => { if (!b || !nx || b.lean[2] === "flat") return null; const up = b.lean[2] === "up"; return (up && nx.pct > 0) || (!up && nx.pct < 0); };

  /* ---------- One saved day ---------- */
  window.openSavedDay = (d) => {
    const row = (rows || []).find(x => x.d === d); if (!row) return;
    const a = row.data, nx = nextDay(d, rows), ok = verdict(a.bottom, nx), seen = new Set();
    const sh = openSheet(dfmt(d, { weekday: "long", day: "numeric", month: "long", year: "numeric" }), "", { sub: "Saved end-of-day analysis" });
    let k = 0;
    const point = (i) => `<li class="nf-point"><div class="rd-head"><span class="rd-n">${++k}</span><strong>${esc(i.t)}</strong>${i.tag ? `<span class="rd-chip ${esc(i.tone)}">${esc(i.tag)}</span>` : ""}</div><p>${markTerms(i.x, seen)}</p>${clean(i.html)}</li>`;
    const lvTest = nx && nx.h != null ? (v) => (v > a.close ? (nx.h >= v ? "hit" : "") : (nx.l <= v ? "hit" : "")) : () => "";
    sh.body.innerHTML = `
      <div class="ar-top"><div><span>Nifty close</span><strong>${nfNum(a.close, 2)}</strong><em class="${a.chg >= 0 ? "up" : "down"}">${sp(a.chg, 0)} (${sp(a.pct)}%)</em></div>
        ${nx ? `<div><span>Next session · ${dfmt(nx.d, { day: "numeric", month: "short" })}</span><strong class="${nx.pct >= 0 ? "up" : "down"}">${sp(nx.pct)}%</strong><em>${ok == null ? "No lean to check" : ok ? "✓ Bottom line was right" : "✗ Bottom line was wrong"}</em></div>` : `<div><span>Next session</span><strong>—</strong><em>Not traded yet</em></div>`}</div>
      ${a.bottom ? bottomHtml(a.bottom) : ""}
      ${nx && nx.h != null ? `<div class="ar-next"><p class="rd-lbl" style="margin-top:0">What happened next</p><p style="margin:0">Next session: open ${nfNum(nx.o, 0)}, high ${nfNum(nx.h, 0)}, low ${nfNum(nx.l, 0)}, close ${nfNum(nx.c, 0)}. Levels marked ✓ below were reached.</p></div>` : ""}
      ${(a.groups || []).map(g => `<p class="rd-lbl">${esc(g.h)}</p><ol class="nf-points">${(g.items || []).map(point).join("")}</ol>${g.note ? `<p class="muted small" style="margin:6px 0 0">${esc(g.note)}</p>` : ""}`).join("")}
      <p class="rd-lbl">Levels that were set for the next session</p>
      <div class="nf-levels">${(a.levels || []).map(([kk, v]) => `<div class="${lvTest(v)}"><span>${esc(kk)}${lvTest(v) ? " ✓" : ""}</span><strong>${nfNum(v, 0)}</strong></div>`).join("")}</div>
      <p class="muted small" style="margin:12px 0 0">Saved ${a.savedAt ? new Date(a.savedAt).toLocaleString("en-IN", { timeZone: "Asia/Kolkata", day: "numeric", month: "short", hour: "numeric", minute: "2-digit" }) : ""} from the app's own calculations${a.source ? ` (breadth: ${a.source === "NSE" ? "NSE" : "Yahoo, approx."})` : ""}. For education only, not a trade call.</p>`;
    sh.body.scrollTop = 0;
  };

  /* ---------- The archive ---------- */
  window.viewArchive = async function () {
    section = "archive";
    app.innerHTML = `<div class="wrap">${tabsHtml()}
      <h2 class="sec-title" style="margin:8px 0 4px">${t("Saved analysis")}</h2>
      <p class="muted small" style="margin:0 0 12px">Every trading day's final advanced read of Nifty, saved automatically after the close. Open any day to see what the data said, and what Nifty actually did next.</p>
      <div id="arScore"></div>
      <div class="chips" id="arF">${[["all", "All days"], ["up", "Leaned bullish"], ["down", "Leaned bearish"], ["big", "Big moves (1%+)"], ["miss", "Bottom line wrong"]].map(([k, l]) => `<button class="chip" data-f="${k}" aria-pressed="${filt === k}">${l}</button>`).join("")}</div>
      <div id="arList" style="margin-top:12px"><p class="muted">Loading saved days…</p></div></div>`;
    bindTabs();
    { const at = $(".tab[aria-selected=true]") || $(".tab.active"); if (at && at.scrollIntoView) at.scrollIntoView({ block: "nearest", inline: "center" }); }
    if (!rows) {
      const { data, error } = await sb.from("day_analysis").select("d,data,score,saved_at").order("d", { ascending: false }).limit(400);
      if (section !== "archive") return;
      if (error) { $("#arList").innerHTML = `<div class="card empty">${/relation|does not exist|schema cache/i.test(error.message) ? "The saved-analysis table isn't set up yet. Mandali needs to run the update-analysis-archive.sql once in Supabase." : "Saved analysis couldn't load. Pull down to refresh."}</div>`; return; }
      rows = data || [];
    }
    const draw = () => {
      const withNx = rows.map(r => ({ r, nx: nextDay(r.d, rows) })).map(o => ({ ...o, ok: verdict(o.r.data.bottom, o.nx) }));
      const judged = withNx.filter(o => o.ok != null), hits = judged.filter(o => o.ok).length;
      $("#arScore").innerHTML = rows.length ? `<div class="card ar-score">
          <div><span>Days saved</span><strong>${rows.length}</strong></div>
          <div><span>Bottom line right next day</span><strong>${judged.length ? Math.round(hits / judged.length * 100) + "%" : "—"}</strong><em>${judged.length ? `${hits} of ${judged.length} calls` : "Needs a few days"}</em></div>
          <div><span>Since</span><strong>${dfmt(rows[rows.length - 1].d, { day: "numeric", month: "short" })}</strong></div></div>` : "";
      let list = withNx;
      if (filt === "up") list = list.filter(o => o.r.data.bottom && o.r.data.bottom.lean[2] === "up");
      if (filt === "down") list = list.filter(o => o.r.data.bottom && o.r.data.bottom.lean[2] === "down");
      if (filt === "big") list = list.filter(o => Math.abs(o.r.data.pct) >= 1);
      if (filt === "miss") list = list.filter(o => o.ok === false);
      if (!rows.length) { $("#arList").innerHTML = `<div class="card empty">Nothing saved yet. The first day is saved automatically after 3:35 PM on the next trading day, as soon as the full analysis loads on Home.</div>`; return; }
      let lastM = "";
      $("#arList").innerHTML = list.length ? `<div class="card tm-list">${list.map(({ r, nx, ok }) => {
        const a = r.data, m = r.d.slice(0, 7), head = m !== lastM ? `<div class="gl-letter">${dfmt(r.d, { month: "long", year: "numeric" })}</div>` : ""; lastM = m;
        const b = a.bottom;
        return `${head}<button class="tm-row ar-row" data-day="${r.d}">
          <span class="ar-date"><b>${new Date(r.d + "T00:00:00").getDate()}</b><i>${dfmt(r.d, { weekday: "short" })}</i></span>
          <span class="tm-row-t"><strong>${nfNum(a.close, 0)} <span class="${a.chg >= 0 ? "up" : "down"}">${sp(a.pct)}%</span></strong>
            <span class="ar-chips">${b ? `<em class="rd-chip ${b.lean[2]}">${esc(b.lean[0])}</em>` : ""}${nx ? `<em class="ar-nx ${ok == null ? "" : ok ? "ok" : "bad"}">Next day ${sp(nx.pct)}%${ok == null ? "" : ok ? " ✓" : " ✗"}</em>` : `<em class="ar-nx">Next day pending</em>`}</span></span>
          <span class="sh-chev">›</span></button>`;
      }).join("")}</div>` : `<div class="card empty">No saved day matches this filter yet.</div>`;
      $$("[data-day]", app).forEach(bt => bt.onclick = () => openSavedDay(bt.dataset.day));
    };
    $$("#arF [data-f]").forEach(bt => bt.onclick = () => { filt = bt.dataset.f; $$("#arF [data-f]").forEach(x => x.setAttribute("aria-pressed", x === bt)); draw(); });
    draw();
  };
  window._arReset = () => { rows = null; };
})();
