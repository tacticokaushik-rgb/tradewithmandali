// =============================================================
// Mandali features: line icons · Call the day · Learning path ·
// Live OI snapshot · weekly steps saved to the account
// =============================================================

/* ---------- Line icons (replace emoji in UI chrome) ---------- */
const ICO = (() => {
  const s = (p, w = 18) => `<svg class="ico" width="${w}" height="${w}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${p}</svg>`;
  return {
    search: s('<circle cx="11" cy="11" r="6.5"/><path d="M20 20l-4-4"/>', 20),
    book: s('<path d="M4 5h11a3 3 0 013 3v12H7a3 3 0 01-3-3z"/><path d="M4 17a3 3 0 013-3h11"/>'),
    quiz: s('<path d="M6 3h9l4 4v14H6z"/><path d="M14 3v5h5"/><path d="M9 13h7M9 17h5"/>'),
    chat: s('<path d="M4 5h16v11H9l-5 4z"/>'),
    flame: s('<path d="M12 3c1 4 5 5 5 10a5 5 0 01-10 0c0-3 2-4 2-6 1 1 2 2 3 2 0-2-1-4 0-6z"/>'),
    pen: s('<path d="M4 20h4L19 9l-4-4L4 16z"/><path d="M14 6l4 4"/>'),
    target: s('<circle cx="12" cy="12" r="8"/><circle cx="12" cy="12" r="4"/><circle cx="12" cy="12" r="1"/>'),
    check: s('<path d="M5 12l4 4 10-10"/>'),
    up: s('<path d="M4 17l6-6 4 4 6-8"/><path d="M14 7h6v6"/>'),
    down: s('<path d="M4 7l6 6 4-4 6 8"/><path d="M14 17h6v-6"/>'),
    side: s('<path d="M3 12h18"/><path d="M7 8l-4 4 4 4M17 8l4 4-4 4"/>'),
    trophy: s('<path d="M8 4h8v5a4 4 0 01-8 0z"/><path d="M8 6H5a3 3 0 003 4M16 6h3a3 3 0 01-3 4M12 13v4M8 21h8M10 17h4"/>'),
    layers: s('<path d="M12 3l9 5-9 5-9-5z"/><path d="M3 13l9 5 9-5"/>')
  };
})();

/* ---------- Weekly steps: sync with the account ---------- */
async function syncGrowSteps() {
  if (!profile?.id) return;
  const cycle = growKey().replace("m_goal_", "");
  try {
    const { data } = await sb.from("goal_steps").select("done").eq("user_id", profile.id).eq("cycle", cycle).maybeSingle();
    const local = growSteps();
    if (data && Array.isArray(data.done)) {
      const merged = [0, 1, 2].map(i => !!(data.done[i] || local[i]));
      localStorage.setItem(growKey(), JSON.stringify(merged));
      if (merged.some((v, i) => v !== !!data.done[i])) saveGrowSteps(merged);
    } else if (local.some(Boolean)) saveGrowSteps([0, 1, 2].map(i => !!local[i]));
    const box = $("#growSteps"); if (box) { box.innerHTML = growStepsHtml(); bindGrowSteps(); }
  } catch (e) { /* offline: keep local */ }
}
function saveGrowSteps(arr) {
  if (!profile?.id) return;
  const cycle = growKey().replace("m_goal_", "");
  sb.from("goal_steps").upsert({ user_id: profile.id, cycle, done: [0, 1, 2].map(i => !!arr[i]), updated_at: new Date().toISOString() }).then(() => {}, () => {});
}

/* ---------- Call the day ---------- */
const CALLS = [["bullish", "Bullish", "up"], ["bearish", "Bearish", "down"], ["sideways", "Sideways", "side"]];
const callLabel = (b) => t((CALLS.find(c => c[0] === b) || [, b])[1]);
let callPick = null;
async function mountCall() {
  const box = $("#callBox"); if (!box || !profile?.id) return;
  const today = todayIST(), now = istNow(), mins = now.getHours() * 60 + now.getMinutes(), td = isTradingDay(now);
  const since = new Date(Date.now() - 45 * 86400e3).toISOString().slice(0, 10);
  const [mc, rs] = await Promise.all([
    sb.from("day_calls").select("*").eq("user_id", profile.id).gte("call_date", since).order("call_date", { ascending: false }),
    sb.from("day_results").select("*").gte("day", since).order("day", { ascending: false })
  ]);
  if (!$("#callBox")) return;
  if (mc.error && /day_calls/.test(mc.error.message)) { box.innerHTML = ""; return; }
  const calls = mc.data || [], res = new Map((rs.data || []).map(r => [r.day, r]));
  const mine = calls.find(c => c.call_date === today), todayRes = res.get(today);
  // stats (last 30 days, only scored days)
  const scored = calls.filter(c => res.has(c.call_date) && c.call_date >= new Date(Date.now() - 30 * 86400e3).toISOString().slice(0, 10));
  const correct = scored.filter(c => res.get(c.call_date).outcome === c.bias).length;
  let run = 0; for (const c of calls.filter(c => res.has(c.call_date))) { if (res.get(c.call_date).outcome === c.bias) run++; else break; }
  const stats = scored.length ? `<span>${t("Last 30 days")}: <strong>${correct}/${scored.length}</strong> (${Math.round(correct / scored.length * 100)}%)</span>${run >= 2 ? `<span>${ICO.flame} ${run} ${t("in a row")}</span>` : ""}` : `<span>${t("Your accuracy appears after your first scored call.")}</span>`;
  const open = td && mins < 555;
  const g = (typeof mbData !== "undefined" && mbData?.gift) ? mbData.gift : null;
  let body;
  if (open) {
    const pick = callPick || mine?.bias || null;
    body = `<p class="call-q">${mine ? t("Your call is locked. You can change it until 9:15.") : t("Where will Nifty close today? Decide before 9:15.")}</p>
      ${g ? `<p class="muted small" style="margin:-4px 0 10px">${t("GIFT Nifty")}: ${g.pct >= 0 ? "+" : ""}${nfNum(g.pct)}%. ${t("A hint, not an answer.")}</p>` : ""}
      <div class="call-opts" role="radiogroup" aria-label="${t("Your call")}">${CALLS.map(([k, l, ic]) => `<button type="button" role="radio" aria-checked="${pick === k}" class="call-opt ${ic}${pick === k ? " on" : ""}" data-call="${k}">${ICO[ic]}<span>${t(l)}</span></button>`).join("")}</div>
      <details class="call-range"${mine?.range_low ? " open" : ""}><summary>${t("Add an expected range (optional)")}</summary>
        <div class="call-range-in"><label><span>${t("Low")}</span><input id="callLo" type="number" inputmode="decimal" value="${mine?.range_low ?? ""}" placeholder="22,550"></label>
        <label><span>${t("High")}</span><input id="callHi" type="number" inputmode="decimal" value="${mine?.range_high ?? ""}" placeholder="22,700"></label></div></details>
      <button class="btn call-lock" id="callLock" ${pick ? "" : "disabled"}>${mine ? t("Update my call") : t("Lock my call")}</button>`;
  } else if (todayRes && td) {
    const ok = mine && mine.bias === todayRes.outcome;
    body = `<div class="call-res"><span class="muted small">${t("Market today")}</span><strong class="${todayRes.pct >= 0 ? "up" : "down"}">${callLabel(todayRes.outcome)} · ${todayRes.pct >= 0 ? "+" : ""}${nfNum(+todayRes.pct)}%</strong></div>
      ${mine ? `<div class="call-res"><span class="muted small">${t("Your call")}</span><strong class="${ok ? "up" : "down"}">${callLabel(mine.bias)} ${ok ? "✓" : "✗"}</strong></div>
        ${mine.range_low != null && mine.range_high != null ? `<p class="muted small" style="margin:6px 0 0">${t("Range")} ${nfNum(+mine.range_low, 0)}–${nfNum(+mine.range_high, 0)}: ${+todayRes.close >= +mine.range_low && +todayRes.close <= +mine.range_high ? t("close was inside") + " ✓" : t("close was outside") + " ✗"}</p>` : ""}`
        : `<p class="muted small" style="margin:6px 0 0">${t("You didn't make a call today. The next one opens tomorrow at 6 AM.")}</p>`}`;
  } else if (td && mins >= 555) {
    body = mine ? `<div class="call-res"><span class="muted small">${t("Your call")}</span><strong>${callLabel(mine.bias)}</strong></div><p class="muted small" style="margin:6px 0 0">${t("Locked at")} ${new Date(mine.created_at).toLocaleTimeString("en-IN", { timeZone: "Asia/Kolkata", hour: "numeric", minute: "2-digit" })}. ${t("Result at 3:45 PM.")}</p>`
      : `<p class="muted small" style="margin:0">${t("Calls close at 9:15. Make tomorrow's call before the open.")}</p>`;
  } else {
    body = `<p class="muted small" style="margin:0">${t("Market closed today. The next call opens on the next trading day before 9:15.")}</p>`;
  }
  box.innerHTML = `<section class="card call-card" aria-label="${t("Call the day")}">
    <div class="call-head"><span class="call-tag">${ICO.target} ${t("Call the day")}</span>${open ? `<span class="call-timer">${t("Closes 9:15")}</span>` : ""}</div>
    ${body}
    <div class="call-stats">${stats}<a href="#" id="callBoard">${ICO.trophy} ${t("Top callers")}</a></div>
    <div id="callBoardBox"></div>
  </section>`;
  $$("[data-call]", box).forEach(b => b.onclick = () => {
    callPick = b.dataset.call;
    $$("[data-call]", box).forEach(x => { const on = x === b; x.classList.toggle("on", on); x.setAttribute("aria-checked", on); });
    $("#callLock").disabled = false;
  });
  const lock = $("#callLock");
  if (lock) lock.onclick = async () => {
    const bias = callPick || mine?.bias; if (!bias) return;
    const lo = parseFloat($("#callLo")?.value), hi = parseFloat($("#callHi")?.value);
    const row = { user_id: profile.id, call_date: today, bias, range_low: Number.isFinite(lo) ? Math.min(lo, hi || lo) : null, range_high: Number.isFinite(hi) ? Math.max(hi, lo || hi) : null };
    if ((row.range_low == null) !== (row.range_high == null)) return toast(t("Fill both Low and High, or leave both empty"));
    lock.disabled = true;
    const { error } = await sb.from("day_calls").upsert(row);
    if (error) { lock.disabled = false; return toast(/row-level|policy/i.test(error.message) ? t("Calls are closed for today (after 9:15).") : "Couldn't save: " + error.message); }
    callPick = null; toast(t("Call locked. Result at 3:45 PM.")); mountCall();
  };
  $("#callBoard").onclick = async (e) => {
    e.preventDefault();
    const bb = $("#callBoardBox"); if (bb.innerHTML) { bb.innerHTML = ""; return; }
    bb.innerHTML = `<p class="muted small">${t("Loading…")}</p>`;
    const { data, error } = await sb.rpc("call_leaderboard");
    bb.innerHTML = error ? `<p class="muted small">${t("Leaderboard isn't available yet.")}</p>` : (data || []).length
      ? `<ol class="call-board">${data.map((r, i) => `<li><span class="${i ? "" : "gold"}">${i + 1}</span><strong>${esc(r.name)}</strong><span>${r.correct}/${r.calls}</span><b>${r.accuracy}%</b></li>`).join("")}</ol><p class="muted small" style="margin:6px 0 0">${t("Last 30 days, minimum 5 calls.")}</p>`
      : `<p class="muted small">${t("No one has 5 scored calls yet. Be the first.")}</p>`;
  };
}

/* ---------- Learning path ---------- */
const LEVELS = [
  { n: 1, name: "Beginner", req: {} },
  { n: 2, name: "Intermediate", req: { classes: 10, quizzes: 3, entries: 10 } },
  { n: 3, name: "Advanced", req: { classes: 25, quizzes: 8, entries: 30, reflections: 4, calls: 10 } },
  { n: 4, name: "Panch-ready", req: { classes: 40, quizzes: 15, entries: 60, reflections: 8, calls: 20, accuracy: 55, streak: 10 } }
];
const REQ_LABEL = { classes: "Classes watched", quizzes: "Quizzes passed (60%+)", entries: "Journal entries", reflections: "Weekly reflections", calls: "Day calls made", accuracy: "Call accuracy (%)", streak: "Best journal streak (days)" };
let pathCache = null;
async function learnStats() {
  if (pathCache && Date.now() - pathCache.at < 60e3) return pathCache.s;
  const id = profile.id;
  const [vp, qa, je, tr, dc, dr] = await Promise.all([
    sb.from("video_progress").select("video_id").eq("user_id", id),
    sb.from("quiz_attempts").select("quiz_id, score, total").eq("user_id", id),
    sb.from("journal_entries").select("entry_date, kind").eq("user_id", id).limit(2000),
    sb.from("trades").select("trade_date").eq("user_id", id).limit(2000),
    sb.from("day_calls").select("call_date, bias").eq("user_id", id).limit(2000),
    sb.from("day_results").select("day, outcome").limit(2000)
  ]);
  const notes = je.data || [], res = new Map((dr.data || []).map(r => [r.day, r.outcome]));
  const calls = dc.data || [], scored = calls.filter(c => res.has(c.call_date));
  const dates = new Set([...notes.map(n => n.entry_date), ...(tr.data || []).map(x => x.trade_date)]);
  // best streak over trading days
  const sorted = [...dates].filter(Boolean).sort(); let best = 0, cur = 0, prev = null;
  for (const d of sorted) {
    const dt = new Date(d + "T12:00:00");
    if (!isTradingDay(dt)) continue;
    if (prev && ymd(prevTradingOrSame(addDays(dt, -1))) === prev) cur++; else cur = 1;
    best = Math.max(best, cur); prev = d;
  }
  const s = {
    classes: new Set((vp.data || []).map(v => v.video_id)).size,
    quizzes: new Set((qa.data || []).filter(a => a.total && a.score / a.total >= 0.6).map(a => a.quiz_id)).size,
    entries: notes.length, reflections: notes.filter(n => n.kind === "reflection").length,
    calls: calls.length, accuracy: scored.length ? Math.round(scored.filter(c => res.get(c.call_date) === c.bias).length / scored.length * 100) : 0,
    streak: best
  };
  pathCache = { at: Date.now(), s };
  return s;
}
function levelOf(s) {
  let lv = LEVELS[0];
  for (const L of LEVELS) if (Object.entries(L.req).every(([k, v]) => (s[k] || 0) >= v)) lv = L; else break;
  return lv;
}
async function mountLevelChip() {
  const el = $("#levelChip"); if (!el || !profile?.id || profile.is_admin) return;
  try {
    const s = await learnStats(), lv = levelOf(s), next = LEVELS[lv.n];
    if (!$("#levelChip")) return;
    const left = next ? Object.entries(next.req).filter(([k, v]) => (s[k] || 0) < v).length : 0;
    el.innerHTML = `<a href="#" class="lvl-chip">${ICO.layers}<span><b>${t("Level")} ${lv.n}</b> · ${t(lv.name)}</span>${next ? `<span class="muted">${left} ${t(left === 1 ? "step" : "steps")} ${t("to")} ${t(next.name)}</span>` : `<span class="muted">${t("Top level reached")}</span>`}</a>`;
    el.querySelector("a").onclick = (e) => { e.preventDefault(); viewProfile(); };
  } catch (e) { el.innerHTML = ""; }
}
async function pathHtml() {
  const s = await learnStats(), lv = levelOf(s);
  return `<section class="card path-card" aria-label="${t("Your learning path")}">
    <div class="path-head"><span class="call-tag">${ICO.layers} ${t("Your learning path")}</span><span class="path-now">${t("Level")} ${lv.n} · ${t(lv.name)}</span></div>
    <ol class="path-levels">${LEVELS.map(L => {
      const done = L.n <= lv.n, isNext = L.n === lv.n + 1;
      const reqs = Object.entries(L.req);
      return `<li class="${done ? "done" : isNext ? "next" : ""}"><div class="path-row"><span class="path-dot">${done ? "✓" : L.n}</span><strong>${t(L.name)}</strong>${done ? `<span class="muted small">${t("Unlocked")}</span>` : ""}</div>
        ${isNext && reqs.length ? `<div class="path-reqs">${reqs.map(([k, v]) => { const have = Math.min(s[k] || 0, v), ok = (s[k] || 0) >= v;
          return `<div class="path-req${ok ? " ok" : ""}"><span>${t(REQ_LABEL[k])}</span><b>${s[k] || 0}/${v}</b><i><em style="width:${Math.round(have / v * 100)}%"></em></i></div>`; }).join("")}</div>` : ""}</li>`; }).join("")}</ol>
    <p class="muted small" style="margin:10px 0 0">${t("Levels are earned by learning and discipline, never by profit.")}</p>
  </section>`;
}

/* ---------- Live OI snapshot (Markets → Analysis) ---------- */
async function mountOi() {
  const box = $("#oiBox"); if (!box) return;
  box.innerHTML = `<section class="card oi-card"><p class="muted small" style="margin:0">${t("Loading live OI…")}</p></section>`;
  let d = null;
  try { const r = await sb.functions.invoke("quick-task", { body: { oi: true } }); d = r.data && !r.data.error ? r.data : null; } catch (e) {}
  if (!$("#oiBox")) return;
  if (!d) { box.innerHTML = `<section class="card oi-card"><div class="oi-head"><span class="call-tag">${t("Live OI snapshot")}</span></div><p class="muted small" style="margin:6px 0 0">${t("NSE's option chain isn't reachable right now. Use the OI notes in today's view below.")}</p></section>`; return; }
  const cr = (n) => n >= 1e7 ? (n / 1e7).toFixed(2) + " Cr" : n >= 1e5 ? (n / 1e5).toFixed(1) + " L" : nfNum(n, 0);
  const seen = new Set(["max call oi", "max put oi", "max pain", "oi", "support", "resistance"]);
  const pcrNote = d.pcr == null ? "" : d.pcr > 1.2 ? t("More puts than calls written: traders expect support to hold.") : d.pcr < 0.8 ? t("More calls than puts written: traders expect a cap overhead.") : t("Balanced: no strong lean either way.");
  box.innerHTML = `<section class="card oi-card">
    <div class="oi-head"><span class="call-tag">${t("Live OI snapshot")} · NIFTY</span><span class="oi-meta">${t("Expiry")} ${esc(d.expiry || "–")}${d.time ? " · " + esc(String(d.time).split(" ").pop().slice(0, 5)) : ""}</span></div>
    <div class="oi-grid">
      <div><span>PCR</span><strong>${d.pcr ?? "–"}</strong></div>
      <div><span>Max Pain</span><strong>${nfNum(d.maxPain, 0)}</strong></div>
      <div class="res"><span>Max Call OI</span><strong>${(d.maxCall || []).map(x => nfNum(x.strike, 0)).join(" / ")}</strong><em>${(d.maxCall || [])[0] ? cr(d.maxCall[0].oi) : ""}</em></div>
      <div class="sup"><span>Max Put OI</span><strong>${(d.maxPut || []).map(x => nfNum(x.strike, 0)).join(" / ")}</strong><em>${(d.maxPut || [])[0] ? cr(d.maxPut[0].oi) : ""}</em></div>
    </div>
    <details class="fold"><summary><span>${t("What this means")}</span></summary><p class="oi-read">${markTerms(`PCR ${d.pcr ?? "–"}. ${pcrNote} Max Call OI at ${nfNum(d.maxCall?.[0]?.strike, 0)} acts as resistance; Max Put OI at ${nfNum(d.maxPut?.[0]?.strike, 0)} acts as support. Max Pain ${nfNum(d.maxPain, 0)}.${d.freshCall?.oi > 0 ? ` Fresh call writing led at ${nfNum(d.freshCall.strike, 0)}` : ""}${d.freshPut?.oi > 0 ? `, fresh put writing at ${nfNum(d.freshPut.strike, 0)}.` : "."}`, seen)}</p>
    <p class="muted small" style="margin:8px 0 0">${t("Nearest expiry, from NSE. Refreshes every 3 minutes. For education only.")}</p></details>
  </section>`;
}

/* ---------- Event explanations (event-day banner) ---------- */
const EVENT_NOTES = [
  [/RBI|MPC|repo/i, "Interest-rate decision. Volatility usually jumps around the announcement and option premiums (IV) often drop right after."],
  [/CPI|inflation/i, "Inflation data. Usually released after market hours, so it tends to move the next morning's open."],
  [/GDP/i, "Economy growth data. A big surprise can move banks and the whole index."],
  [/Fed|FOMC/i, "US rate decision (late night IST). Its effect shows up in GIFT Nifty and the next open."],
  [/budget/i, "Union Budget. Very high intraday volatility; trade small or watch."],
  [/result/i, "Company results season. Heavyweight results (Reliance, HDFC Bank, Infosys) can move Nifty."],
  [/holiday/i, "Market holiday. No trading on NSE today."]
];
const eventNote = (label) => (EVENT_NOTES.find(([re]) => re.test(label)) || [, ""])[1];

/* ---------- "Now" box: changes with the time of day ---------- */
let nowTimer = null, nowCtx = null;
async function mountNow() {
  const box = $("#nowBox"); if (!box || !profile?.id) return;
  const today = todayIST();
  if (!nowCtx || nowCtx.day !== today || Date.now() - nowCtx.at > 300e3) {
    const [mp, dc, je, dr] = await Promise.all([
      sb.from("market_posts").select("post_date, title, bias, support, resistance").order("post_date", { ascending: false }).limit(1),
      sb.from("day_calls").select("bias, range_low, range_high").eq("user_id", profile.id).eq("call_date", today).maybeSingle(),
      sb.from("journal_entries").select("id, plan, review, body").eq("user_id", profile.id).eq("entry_date", today),
      sb.from("day_results").select("*").eq("day", today).maybeSingle()
    ]);
    nowCtx = { day: today, at: Date.now(), post: (mp.data || [])[0] || null, call: dc.data || null, entries: je.data || [], result: dr.data || null };
  }
  drawNow();
  clearInterval(nowTimer);
  nowTimer = setInterval(() => { if (!$("#nowBox")) { clearInterval(nowTimer); return; } drawNow(); }, 30000);
}
function nowLevels() {
  // yesterday's candle → pivot levels; plus mentor's posted levels for today
  const out = [], d = (typeof nfData !== "undefined" && nfData?.daily) || [];
  const today = todayIST();
  const prev = [...d].reverse().find(c => new Date((c[0] + 19800) * 1000).toISOString().slice(0, 10) < today);
  if (prev) { const [, , h, l, c] = prev, p = (h + l + c) / 3; out.push(["S1", 2 * p - h], ["Pivot", p], ["R1", 2 * p - l]); }
  const post = nowCtx?.post;
  if (post && post.post_date === today) {
    const nums = (txt) => String(txt || "").split(/[\/|;\n]/).map(x => parseFloat(x.replace(/[^\d.]/g, ""))).filter(x => x > 1000);
    nums(post.support).forEach((v, i) => out.push([`S${i + 1} (view)`, v]));
    nums(post.resistance).forEach((v, i) => out.push([`R${i + 1} (view)`, v]));
  }
  return out;
}
function drawNow() {
  const box = $("#nowBox"); if (!box) return;
  const now = istNow(), m = now.getHours() * 60 + now.getMinutes(), td = isTradingDay(now), today = todayIST();
  const q = (typeof nfData !== "undefined" && nfData?.nifty) || null;
  const ctx = nowCtx || {};
  const evs = upcomingEvents(6).filter(e => e[0] === today && !/holiday/i.test(e[2]));
  const exp = upcomingExpiries().find(x => x.kind.startsWith("nifty") && ymd(x.date) === today);
  const evRow = [...evs.map(e => [e[2], eventNote(e[2])]), ...(exp ? [[t("Nifty weekly expiry today"), t("Theta decay is fastest today. Price often gets pulled toward the strikes with the biggest OI.")]] : [])]
    .map(([l, n]) => `<div class="now-ev"><strong>${esc(l)}</strong>${n ? `<span>${esc(n)}</span>` : ""}</div>`).join("");
  const btn = (to, label, extra = "") => `<button class="btn sm ${extra}" data-now="${to}">${label}</button>`;
  let tag, body = "", actions = "";
  if (td && m < 555) {
    tag = t("Before the open");
    const g = (typeof mbData !== "undefined" && mbData?.gift) || null;
    const lv = nowLevels().filter(([k]) => ["S1", "Pivot", "R1"].includes(k));
    body = `${g ? `<p class="now-line">GIFT Nifty <b class="${g.pct >= 0 ? "up" : "down"}">${g.pct >= 0 ? "+" : ""}${nfNum(g.pct)}%</b> · ${g.pct >= 0.25 ? t("positive start likely") : g.pct <= -0.25 ? t("negative start likely") : t("flat start likely")}</p>` : ""}
      ${lv.length ? `<div class="now-lv">${lv.map(([k, v]) => `<div><span>${k}</span><strong>${nfNum(v, 0)}</strong></div>`).join("")}</div>` : ""}`;
    actions = (ctx.call ? `<span class="now-done">✓ ${t("Call made")}: ${callLabel(ctx.call.bias)}</span>` : btn("call", t("Make your call"))) +
      (ctx.entries?.some(e => e.plan || e.body) ? `<span class="now-done">✓ ${t("Plan written")}</span>` : btn("plan", t("Write your plan"), "ghost"));
  } else if (td && m < 930) {
    tag = t("Market live");
    if (q?.price) {
      const lv = nowLevels(), p = q.price;
      const above = lv.filter(([, v]) => v > p).sort((a, b) => a[1] - b[1])[0], below = lv.filter(([, v]) => v <= p).sort((a, b) => b[1] - a[1])[0];
      const near = [above, below].filter(Boolean).find(([, v]) => Math.abs(v - p) <= 10);
      body = `${near ? `<p class="now-alert">${t("Nifty is testing")} <b>${esc(near[0])} ${nfNum(near[1], 0)}</b> (${nfNum(Math.abs(near[1] - p), 0)} ${t("pts away")})</p>` : ""}
        <div class="now-gauge">
          <div><span>${below ? esc(below[0]) : "–"}</span><strong>${below ? nfNum(below[1], 0) : "–"}</strong><em>${below ? "−" + nfNum(p - below[1], 0) + " pts" : ""}</em></div>
          <div class="mid"><span>Nifty</span><strong>${nfNum(p)}</strong></div>
          <div><span>${above ? esc(above[0]) : "–"}</span><strong>${above ? nfNum(above[1], 0) : "–"}</strong><em>${above ? "+" + nfNum(above[1] - p, 0) + " pts" : ""}</em></div>
        </div>`;
    } else body = `<p class="now-line muted">${t("Waiting for live price…")}</p>`;
    actions = ctx.call ? `<span class="now-done">${t("Your call")}: ${callLabel(ctx.call.bias)} · ${t("result at 3:45 PM")}</span>` : "";
  } else if (td) {
    tag = t("After the close");
    const r = ctx.result;
    const pct = r ? +r.pct : (q?.price && q?.prevClose ? (q.price / q.prevClose - 1) * 100 : null);
    const outcome = r ? r.outcome : pct == null ? null : pct >= 0.25 ? "bullish" : pct <= -0.25 ? "bearish" : "sideways";
    body = pct != null ? `<p class="now-line">${t("Today")}: <b class="${pct >= 0 ? "up" : "down"}">${callLabel(outcome)} ${pct >= 0 ? "+" : ""}${nfNum(pct)}%</b>${ctx.call ? ` · ${t("your call")} ${callLabel(ctx.call.bias)} ${ctx.call.bias === outcome ? "✓" : "✗"}${r ? "" : ` <span class="muted small">(${t("final at 3:45")})</span>`}` : ""}</p>` : "";
    actions = ctx.entries?.some(e => e.review || e.body) ? `<span class="now-done">✓ ${t("Review written")}</span>` : btn("review", t("Write your review"));
    actions += btn("read", t("Read today's analysis"), "ghost");
  } else {
    tag = t("Market closed today");
    const next = upcomingEvents(3)[0];
    body = `<p class="now-line muted">${t("Next session")}: ${shortDay(nextTradingDay(now))} · 9:15 AM</p>${next ? `<p class="now-line muted small">${t("Coming up")}: ${esc(next[2])} · ${shortDay(new Date(next[0] + "T00:00:00"))}</p>` : ""}`;
  }
  box.innerHTML = `<section class="card now-card"><div class="now-head"><span class="call-tag">${tag}</span><span class="now-time">${now.toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit" })} IST</span></div>
    ${body}${evRow ? `<div class="now-evs">${evRow}</div>` : ""}${actions ? `<div class="now-actions">${actions}</div>` : ""}</section>`;
  $$("[data-now]", box).forEach(b => b.onclick = () => {
    const k = b.dataset.now;
    if (k === "call") go("market");
    else if (k === "read") { const d = $("#nfRead details.fold"); if (d) { d.open = true; d.scrollIntoView({ behavior: "smooth", block: "start" }); } }
    else { noteMode = k === "plan" ? "plan" : null; newKind = null; editingNote = null; go("journal"); setTimeout(() => { const b2 = $("#addNoteBtn"); if (b2) b2.click(); }, 400); }
  });
}

/* ---------- My patterns ---------- */
async function viewPatterns() {
  section = "patterns";
  app.innerHTML = `<div class="wrap">${tabsHtml()}<p class="muted">${t("Reading your journal…")}</p></div>`; bindTabs();
  const id = profile.id;
  const [tr, je, dc, dr] = await Promise.all([
    sb.from("trades").select("*").eq("user_id", id).limit(3000),
    sb.from("journal_entries").select("entry_date, kind, view, plan, review, body, pnl").eq("user_id", id).limit(3000),
    sb.from("day_calls").select("call_date, bias").eq("user_id", id).limit(3000),
    sb.from("day_results").select("day, outcome, pct").limit(3000)
  ]);
  if (section !== "patterns") return;
  const trades = (tr.data || []).filter(x => tradePnl(x) != null), notes = je.data || [], calls = dc.data || [];
  const res = new Map((dr.data || []).map(r => [r.day, r]));
  const cards = [];
  const pct = (a, b) => b ? Math.round(a / b * 100) : 0;
  const card = (title, lines, note) => `<section class="card pat-card"><p class="call-tag">${title}</p>${lines.map(l => `<p class="pat-line">${l}</p>`).join("")}${note ? `<p class="muted small" style="margin:8px 0 0">${note}</p>` : ""}</section>`;
  // Trades
  if (trades.length >= 5) {
    const st = journalStats(trades), lines = [];
    const by = (key) => { const m = {}; trades.forEach(x => { const k = x[key] || "Other"; (m[k] = m[k] || []).push(tradePnl(x)); }); return Object.entries(m).filter(([, v]) => v.length >= 2).map(([k, v]) => ({ k, n: v.length, win: pct(v.filter(p => p > 0).length, v.length), net: v.reduce((a, b) => a + b, 0) })); };
    const strat = by("strategy").sort((a, b) => b.win - a.win);
    if (strat.length >= 2) lines.push(`${t("Best strategy")}: <b>${esc(strat[0].k)}</b> ${strat[0].win}% ${t("win rate")} (${strat[0].n} ${t("trades")}). ${t("Weakest")}: <b>${esc(strat[strat.length - 1].k)}</b> ${strat[strat.length - 1].win}%.`);
    const losers = trades.filter(x => tradePnl(x) < 0);
    const top = (arr, key) => { const m = {}; arr.forEach(x => { const k = x[key]; if (k && !/^none$/i.test(k)) m[k] = (m[k] || 0) + 1; }); return Object.entries(m).sort((a, b) => b[1] - a[1])[0]; };
    const em = top(losers, "emotion"), mi = top(losers, "mistake");
    if (em && losers.length >= 3) lines.push(`${pct(em[1], losers.length)}% ${t("of your losing trades were tagged")} <b>${esc(em[0])}</b>.`);
    if (mi && losers.length >= 3) lines.push(`${t("Most common mistake on losses")}: <b>${esc(mi[0])}</b> (${mi[1]}×).`);
    const wd = {}; trades.forEach(x => { const d = new Date(x.trade_date + "T12:00:00").getDay(); (wd[d] = wd[d] || []).push(tradePnl(x)); });
    const names = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
    const wdl = Object.entries(wd).filter(([, v]) => v.length >= 2).map(([d, v]) => [names[d], v.reduce((a, b) => a + b, 0)]).sort((a, b) => b[1] - a[1]);
    if (wdl.length >= 2) lines.push(`${t("Best day")}: <b>${wdl[0][0]}</b> (${inr0(wdl[0][1])}). ${t("Worst day")}: <b>${wdl[wdl.length - 1][0]}</b> (${inr0(wdl[wdl.length - 1][1])}).`);
    const wins = trades.map(tradePnl).filter(p => p > 0), loss = trades.map(tradePnl).filter(p => p < 0);
    if (wins.length && loss.length) { const aw = wins.reduce((a, b) => a + b, 0) / wins.length, al = Math.abs(loss.reduce((a, b) => a + b, 0) / loss.length);
      lines.push(`${t("Average win")} <b>${inr0(aw)}</b> vs ${t("average loss")} <b>${inr0(al)}</b>. ${aw >= al ? t("Your winners are bigger than your losers. Good.") : t("Your losers are bigger than your winners. Cut losses sooner.")}`); }
    cards.push(card(t("Your trades"), lines, `${st.closed} ${t("closed trades analysed")}.`));
  } else cards.push(card(t("Your trades"), [t("Log at least 5 trades to see your patterns.")]));
  // Journal
  if (notes.length >= 5) {
    const lines = [];
    const pr = notes.filter(n => n.plan || n.review).length;
    lines.push(`${t("You used Plan & Review in")} <b>${pct(pr, notes.length)}%</b> ${t("of entries")}.${pct(pr, notes.length) < 40 ? " " + t("Planning before the open is the habit that helps most.") : ""}`);
    const views = notes.filter(n => n.view && res.has(n.entry_date) && /bull|bear|side/i.test(n.view));
    if (views.length >= 3) { const ok = views.filter(n => res.get(n.entry_date).outcome === n.view.toLowerCase()).length; lines.push(`${t("Your written market view matched the day")} <b>${ok}/${views.length}</b> ${t("times")} (${pct(ok, views.length)}%).`); }
    const plans = notes.filter(n => n.plan && n.review).length;
    if (plans) lines.push(`${plans} ${t("days with both a plan and a review. Compare them: was the plan right?")}`);
    cards.push(card(t("Your journal"), lines));
  } else cards.push(card(t("Your journal"), [t("Write at least 5 journal entries to see your patterns.")]));
  // Calls
  const scored = calls.filter(c => res.has(c.call_date));
  if (scored.length >= 5) {
    const lines = [], n = scored.length;
    const myB = pct(scored.filter(c => c.bias === "bullish").length, n), mkB = pct(scored.filter(c => res.get(c.call_date).outcome === "bullish").length, n);
    const myD = pct(scored.filter(c => c.bias === "bearish").length, n), mkD = pct(scored.filter(c => res.get(c.call_date).outcome === "bearish").length, n);
    const ok = scored.filter(c => res.get(c.call_date).outcome === c.bias).length;
    lines.push(`${t("Accuracy")}: <b>${ok}/${n}</b> (${pct(ok, n)}%).`);
    lines.push(`${t("You called Bullish")} <b>${myB}%</b> ${t("of the time; the market was bullish")} <b>${mkB}%</b>. ${t("Bearish")}: ${myD}% vs ${mkD}%.`);
    if (myB - mkB >= 20) lines.push(`<b>${t("Bullish bias")}</b>: ${t("you expect up-moves more than they happen. Check your reasons on up-calls.")}`);
    else if (myD - mkD >= 20) lines.push(`<b>${t("Bearish bias")}</b>: ${t("you expect down-moves more than they happen.")}`);
    const side = scored.filter(c => res.get(c.call_date).outcome === "sideways"), sideOk = side.filter(c => c.bias === "sideways").length;
    if (side.length >= 3) lines.push(`${t("On sideways days you were right")} ${sideOk}/${side.length}. ${sideOk / side.length < 0.4 ? t("Range days are your blind spot.") : ""}`);
    cards.push(card(t("Your day calls"), lines));
  } else cards.push(card(t("Your day calls"), [t("Make at least 5 day calls (Markets tab) to see your bias.")]));
  app.innerHTML = `<div class="wrap">${tabsHtml()}
    <h2 class="sec-title" style="margin:8px 0 4px">${t("My patterns")}</h2>
    <p class="muted small" style="margin:0 0 14px">${t("What your own journal, trades and calls say about you. Updated every time you open this page.")}</p>
    ${cards.join("")}</div>`;
  bindTabs();
}

/* ---------- Glossary (300+ terms, basic to advanced) ---------- */
const FREE_DICT = new Set(["ltp", "bullish", "bearish", "call option", "put option", "strike price", "premium", "lot size", "expiry", "stop-loss", "nifty 50", "support", "resistance", "atm", "itm", "otm"]);
let glLevel = "all", glCat = "All";
function loadGlossary() {
  if (window.GLOSSARY_FULL) return Promise.resolve();
  if (window._glLoading) return window._glLoading;
  return (window._glLoading = new Promise((res) => {
    const sc = document.createElement("script"); sc.src = "glossary-data.js?v=20261012b"; sc.onload = res; sc.onerror = res; document.head.appendChild(sc);
  }));
}
function viewGlossary(q = "") {
  section = "glossary";
  app.innerHTML = `<div class="wrap">${tabsHtml()}
    <h2 class="sec-title" style="margin:8px 0 4px">${t("Dictionary")}</h2>
    <p class="muted small" style="margin:0 0 10px">Quick meanings of trading words. For full explanations of economy and newspaper words, open <button class="linkbtn" id="glToTerms">Terms</button>.</p>
    <div class="gl-tools">
      <input id="glQ" type="search" placeholder="${t("Search a term…")}" value="${esc(q)}" autocomplete="off" style="width:100%">
      <div class="chips" id="glLv">${[["all", "All levels"], ["b", "Basic"], ["i", "Intermediate"], ["a", "Advanced"]].map(([k, l]) => `<button class="chip" data-lv="${k}" aria-pressed="${glLevel === k}">${l}</button>`).join("")}</div>
      <div class="chips" id="glCats"></div>
    </div>
    <p class="gl-count" id="glCount"></p>
    <div class="card gl-list" id="glList"><p class="muted">Loading terms…</p></div></div>`;
  bindTabs();
  $("#glToTerms").onclick = () => go("terms");
  Promise.all([loadGlossary(), window.loadTerms ? loadTerms() : null]).then(() => {
    if (section !== "glossary") return;
    const base = window.GLOSSARY_FULL || (window.GLOSSARY || []).map(([k, v]) => [k, v, "b", "Basics", ""]);
    const TN = new Map(); (window.TERMS_DATA || []).forEach(x => { TN.set(x[0].toLowerCase(), x[0]); String(x[1] || "").split(",").forEach(a => { a = a.trim().toLowerCase(); if (a && !TN.has(a)) TN.set(a, x[0]); }); });
    const list = [...base].sort((a, b) => a[0].localeCompare(b[0], "en", { sensitivity: "base" }));
    const cats = ["All", ...new Set(list.map(x => x[3]))];
    const LV = { b: "Basic", i: "Intermediate", a: "Advanced" };
    const reEsc = (x) => x.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    const hi = (txt, qq) => { const h = esc(txt); return qq ? h.replace(new RegExp("(" + reEsc(esc(qq)) + ")", "ig"), "<mark>$1</mark>") : h; };
    const norm = (x) => x.toLowerCase().replace(/[^a-z0-9%&]+/g, " ").trim();
    $("#glCats").innerHTML = cats.map(c => `<button class="chip" data-cat="${esc(c)}" aria-pressed="${glCat === c}">${esc(c)}</button>`).join("");
    const draw = () => {
      const raw = $("#glQ").value.trim(), qq = norm(raw);
      let rows = list.filter(r => (glLevel === "all" || r[2] === glLevel) && (glCat === "All" || r[3] === glCat));
      if (qq) {
        const score = (r) => { const k = norm(r[0]), a = norm(r[4] || ""), m = norm(r[1]);
          if (k === qq || a.split(" ").includes(qq) && a === qq) return 0;
          if (k.startsWith(qq)) return 1; if (a.split(/\s*,\s*|\s+/).some(w => w.startsWith(qq))) return 2;
          if (k.includes(qq)) return 3; if (a.includes(qq)) return 4; if (m.includes(qq)) return 5; return 9; };
        rows = rows.map(r => [score(r), r]).filter(x => x[0] < 9).sort((a, b) => a[0] - b[0] || a[1][0].localeCompare(b[1][0])).map(x => x[1]);
      }
      $("#glCount").innerHTML = esc(`${rows.length} term${rows.length === 1 ? "" : "s"}${qq ? ` matching "${raw}"` : ""}`) + (isPro() ? "" : ` · <button class="linkbtn" data-lock="the full Dictionary">${FREE_DICT.size} free, subscribe to unlock all ${list.length}</button>`);
      let last = "";
      $("#glList").innerHTML = rows.map(r => {
        const L = /[a-z]/i.test(r[0][0]) ? r[0][0].toUpperCase() : "#";
        const head = !qq && L !== last ? `<div class="gl-letter">${L}</div>` : ""; last = L;
        const lk = !isPro() && !FREE_DICT.has(r[0].toLowerCase());
        if (lk) return `${head}<div class="gl-row lk-row" data-lock="Dictionary" role="button" tabindex="0"><div class="gl-top"><strong>${hi(r[0], raw)}</strong><span class="lk-chip">🔒</span></div>
          <span class="lk-text" aria-hidden="true">${esc(Lock.scr(r[1]))}</span><span class="sr">Meaning available to subscribers</span></div>`;
        return `${head}<div class="gl-row"><div class="gl-top"><strong>${hi(r[0], raw)}</strong><span class="gl-lv ${r[2]}">${LV[r[2]]}</span></div>
          <span>${hi(r[1], raw)}</span>${r[4] ? `<span class="gl-aka">Also: ${hi(r[4], raw)}</span>` : ""}${TN.has(r[0].toLowerCase()) ? `<button class="linkbtn gl-more" data-term="${esc(TN.get(r[0].toLowerCase()))}">Full explanation in Terms ›</button>` : ""}</div>`;
      }).join("") || `<p class="muted" style="padding:10px 0">${t("No match in the Dictionary.")}${qq ? "" : ""}</p>`;
      const have = new Set(rows.map(r => r[0].toLowerCase()));
      const tm = qq && window.TERMS_DATA ? TERMS_DATA.filter(x => !have.has(x[0].toLowerCase()) && (norm(x[0]).includes(qq) || norm(x[1] || "").includes(qq))).slice(0, 6) : [];
      if (tm.length) $("#glList").insertAdjacentHTML("beforeend", `<div class="gl-letter">📰 Full explanations in Terms</div>${tm.map(x => `<button class="tm-row" data-term="${esc(x[0])}"><span class="tm-row-t"><strong>${hi(x[0], raw)}</strong><span>${esc((x[3].match(/^.*?[.!?](\s|$)/) || [x[3]])[0])}</span></span><span class="sh-chev">›</span></button>`).join("")}`);
    };
    { const at = $(".tab[aria-selected=true]") || $(".tab.active"); if (at && at.scrollIntoView) at.scrollIntoView({ block: "nearest", inline: "center" }); }
    $("#glList").onclick = (e) => { const b = e.target.closest("[data-term]"); if (b) openTermSheet(b.dataset.term); };
    let tmr; $("#glQ").oninput = () => { clearTimeout(tmr); tmr = setTimeout(draw, 90); };
    $$("#glLv .chip").forEach(c => c.onclick = () => { glLevel = c.dataset.lv; $$("#glLv .chip").forEach(x => x.setAttribute("aria-pressed", x === c)); draw(); });
    $$("#glCats .chip").forEach(c => c.onclick = () => { glCat = c.dataset.cat; $$("#glCats .chip").forEach(x => x.setAttribute("aria-pressed", x === c)); draw(); });
    draw();
  });
}
