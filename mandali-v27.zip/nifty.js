// =============================================================
// Live Nifty 50 card for Home: our own chart (TradingView's open
// Lightweight Charts library), so NSE data restrictions don't apply.
// Data comes from the Supabase Edge Function "nifty-live".
// =============================================================
// The breadth/macro function: works whether it was created as "market--breadth-" or "market-breadth".
let MB_NAME = null;
async function mbFn(body) {
  const names = MB_NAME ? [MB_NAME] : ["market--breadth-", "market-breadth"];
  let last = null;
  for (const n of names) {
    try { const r = await sb.functions.invoke(n, { body }); if (!r.error && r.data) { MB_NAME = n; return r; } last = r; } catch (e) { last = { error: e }; }
  }
  return last || { error: new Error("unavailable") };
}
let nfChart = null, nfSeries = null, nfRange = "1d", nfTimer = null, nfData = null, nfType = "candle", nfPrevLine = null;
const NF_IST = 19800; // seconds to shift UTC -> IST on the chart axis
const nfNum = (v, d = 2) => v == null ? "–" : Number(v).toLocaleString("en-IN", { minimumFractionDigits: d, maximumFractionDigits: d });

function nfMarketLive() {
  const n = istNow(), m = n.getHours() * 60 + n.getMinutes();
  return isTradingDay(n) && m >= 555 && m < 930;
}

function loadLWC() {
  if (window.LightweightCharts) return Promise.resolve();
  return new Promise((ok, bad) => {
    const s = document.createElement("script");
    s.src = "https://cdn.jsdelivr.net/npm/lightweight-charts@4.2.0/dist/lightweight-charts.standalone.production.js";
    s.onload = ok; s.onerror = () => bad(new Error("Chart library didn't load"));
    document.head.appendChild(s);
  });
}

async function nfFetch(range) {
  const { data, error } = await sb.functions.invoke("quick-task", { body: { range } });
  if (error) throw error;
  if (!data || data.error || !data.nifty) throw new Error((data && data.error) || "No data");
  return data;
}

function niftyCardHtml() {
  return `<section class="card nf" id="nfCard" aria-label="Nifty 50 live">
    <div class="nf-top">
      <div>
        <p class="muted small" style="margin:0">Nifty 50</p>
        <p class="nf-price" id="nfPrice">Loading…</p>
        <p class="nf-chg" id="nfChg"></p>
      </div>
      <div class="nf-state" id="nfState"></div>
    </div>
    <div class="nf-tools">
      <div class="nf-ranges" role="radiogroup" aria-label="Chart range">
        ${[["1d", "1D"], ["5d", "5D"], ["1mo", "1M"], ["6mo", "6M"], ["1y", "1Y"]].map(([k, l]) =>
          `<button role="radio" data-nfr="${k}" aria-checked="${nfRange === k}">${l}</button>`).join("")}
      </div>
      <button class="nf-type" id="nfType" aria-label="Switch chart type">${nfType === "candle" ? "Line" : "Candles"}</button>
    </div>
    <div class="nf-chart" id="nfChart"></div>
    <div class="nf-sub" id="nfSub"></div>
  </section>
  <section class="card nf-read" id="nfRead" hidden></section>`;
}

function nfDrawChart() {
  const el = $("#nfChart"); if (!el || !nfData || !window.LightweightCharts) return;
  const css = getComputedStyle(document.body);
  const up = "#5DBB8A", down = "#E26D5A";
  if (!nfChart || !el.contains(nfChart.chartElement && nfChart.chartElement())) {
    el.innerHTML = "";
    nfChart = LightweightCharts.createChart(el, {
      autoSize: true,
      layout: { background: { type: "solid", color: "transparent" }, textColor: css.getPropertyValue("--muted").trim() || "#8E98B0", fontSize: 11 },
      grid: { vertLines: { visible: false }, horzLines: { color: "rgba(142,152,176,.12)" } },
      rightPriceScale: { borderVisible: false },
      timeScale: { borderVisible: false, timeVisible: nfRange !== "6mo" && nfRange !== "1y", secondsVisible: false },
      crosshair: { mode: 0 },
      localization: { locale: "en-IN" },
      handleScroll: { vertTouchDrag: false },
    });
    nfSeries = null;
  }
  if (nfSeries) { nfChart.removeSeries(nfSeries); nfSeries = null; nfPrevLine = null; }
  const pts = nfData.candles.map(c => ({ time: c[0] + NF_IST, open: c[1], high: c[2], low: c[3], close: c[4] }));
  nfChart.applyOptions({ timeScale: { timeVisible: nfRange !== "6mo" && nfRange !== "1y" } });
  if (nfType === "candle") {
    nfSeries = nfChart.addCandlestickSeries({ upColor: up, downColor: down, borderVisible: false, wickUpColor: up, wickDownColor: down });
    nfSeries.setData(pts);
  } else {
    const last = pts.length ? pts[pts.length - 1].close : 0, first = pts.length ? pts[0].open : 0;
    const col = last >= first ? up : down;
    nfSeries = nfChart.addAreaSeries({ lineColor: col, topColor: col + "55", bottomColor: col + "05", lineWidth: 2 });
    nfSeries.setData(pts.map(p => ({ time: p.time, value: p.close })));
  }
  if (nfRange === "1d" && nfData.nifty.prevClose)
    nfPrevLine = nfSeries.createPriceLine({ price: nfData.nifty.prevClose, color: "#8E98B0", lineWidth: 1, lineStyle: 2, axisLabelVisible: true, title: "Prev close" });
  nfChart.timeScale().fitContent();
}

function nfDrawQuote() {
  const q = nfData.nifty, live = nfMarketLive();
  const chg = q.price - q.prevClose, pct = chg / q.prevClose * 100, cls = chg >= 0 ? "up" : "down";
  $("#nfPrice").textContent = nfNum(q.price);
  $("#nfChg").className = "nf-chg " + cls;
  $("#nfChg").textContent = `${chg >= 0 ? "▲ +" : "▼ "}${nfNum(chg)} (${chg >= 0 ? "+" : ""}${nfNum(pct)}%)`;
  const when = q.time ? new Date(q.time * 1000).toLocaleString("en-IN", { timeZone: "Asia/Kolkata", day: "numeric", month: "short", hour: "numeric", minute: "2-digit" }) : "";
  $("#nfState").innerHTML = live
    ? `<span class="nf-live"><span class="sess-dot"></span>Live</span><span class="muted small">Updates every 20 sec</span>`
    : `<span class="nf-closed">Closed</span><span class="muted small">Closing price${when ? ", " + when : ""}</span>`;
  const b = nfData.bank;
  const bTxt = b && b.price && b.prevClose ? (() => { const c = b.price - b.prevClose, p = c / b.prevClose * 100;
    return `<span>Bank Nifty <strong>${nfNum(b.price)}</strong> <span class="${c >= 0 ? "up" : "down"}">${c >= 0 ? "+" : ""}${nfNum(p)}%</span></span>`; })() : "";
  $("#nfSub").innerHTML = `
    <span>High <strong>${nfNum(q.high)}</strong></span><span>Low <strong>${nfNum(q.low)}</strong></span>
    <span>Prev close <strong>${nfNum(q.prevClose)}</strong></span>${bTxt}
    <span class="muted small nf-src">Market data may be delayed by about a minute. For education only.</span>`;
}

/* ---------- What an advanced trader reads from today ---------- */
// Extra data for the deeper read: breadth/sectors/VIX/long history ("market-breadth"), OI ("quick-task" oi), headlines ("Market-news-").
let nfExt = { br: null, brAt: 0, oi: null, oiAt: 0, news: null, newsAt: 0, busy: false };
const NF_DKEY = (t) => new Date((t + 19800) * 1000).toISOString().slice(0, 10);
function nfMergeDaily(a, b) {
  const m = new Map();
  (b || []).forEach(c => m.set(NF_DKEY(c[0]), c));
  (a || []).forEach(c => { const k = NF_DKEY(c[0]), old = m.get(k); m.set(k, [c[0], c[1], c[2], c[3], c[4], (c[5] || (old && old[5]) || 0)]); });
  return [...m.entries()].sort((x, y) => x[0] < y[0] ? -1 : 1).map(e => e[1]);
}

// What usually moves each sector (shown as context, not as today's proven cause)
const SECTOR_DRIVERS = {
  "Bank": "rate expectations, credit growth and FII flows", "Private Bank": "loan growth, margins (NIM) and FII flows",
  "PSU Bank": "bond yields, asset quality and government policy; a high-beta pocket", "Financial Services": "funding costs, the rate outlook and NBFC credit growth",
  "IT": "the US tech outlook, deal wins and the rupee (a weaker rupee helps exporters)", "Pharma": "US FDA updates, US drug pricing and the rupee; a defensive sector",
  "Healthcare": "hospital demand, US FDA news and pricing; a defensive sector", "Auto": "monthly sales numbers, input costs and interest rates",
  "FMCG": "rural demand, inflation and the monsoon; a defensive sector", "Metal": "China demand, global metal prices and the dollar",
  "Realty": "home-loan rates and housing demand; very rate-sensitive", "Energy": "crude oil, gas prices and government pricing decisions",
  "Oil & Gas": "crude oil prices and fuel marketing margins", "Media": "advertising spends and content deals",
  "Consumer Durables": "festive demand, input costs and consumer credit", "Infra": "government capex, order inflows and cement and steel prices"
};
const SECTOR_NEWS = {
  "Bank": /\bbank|RBI|repo|HDFC Bank|ICICI|SBI\b|Axis|Kotak|deposit|NIM\b|lending/i, "Private Bank": /private bank|HDFC Bank|ICICI|Axis|Kotak|IndusInd/i,
  "PSU Bank": /PSU bank|SBI\b|Bank of Baroda|PNB|Canara|Union Bank/i, "Financial Services": /NBFC|Bajaj Fin|insurance|Jio Financial|HDFC Life|SBI Life|Shriram/i,
  "IT": /\bIT\b|Infosys|TCS|Wipro|HCL|Tech Mahindra|software|Accenture|Nasdaq|H-1B/i, "Pharma": /pharma|drug|USFDA|FDA|Sun Pharma|Cipla|Dr Reddy|Lupin/i,
  "Healthcare": /hospital|health|Apollo|Max Health|pharma|FDA/i, "Auto": /\bauto|car sales|vehicle|Maruti|Tata Motors|Mahindra|Bajaj Auto|Hero|Eicher|\bEV\b/i,
  "FMCG": /FMCG|HUL|Hindustan Unilever|ITC\b|Nestle|Britannia|Dabur|consumption|rural|monsoon/i, "Metal": /metal|steel|Tata Steel|JSW|Hindalco|Vedanta|aluminium|copper|iron ore|China/i,
  "Realty": /realty|real estate|DLF|Godrej Prop|Lodha|Oberoi|housing/i, "Energy": /crude|oil|Reliance|ONGC|NTPC|Power Grid|\bgas\b|OPEC|coal/i,
  "Oil & Gas": /crude|oil|ONGC|BPCL|HPCL|IOC|GAIL|\bgas\b|OPEC/i, "Media": /media|Zee|PVR|Sun TV|Nazara/i,
  "Consumer Durables": /durables|Titan|Havells|Voltas|Dixon|festive/i, "Infra": /infra|L&T|Larsen|capex|order|cement|UltraTech|port/i
};
const DEFENSIVE = new Set(["FMCG", "Pharma", "Healthcare", "IT"]), CYCLICAL = new Set(["Metal", "Realty", "PSU Bank", "Auto", "Bank", "Infra", "Energy", "Oil & Gas"]);

function nfMA(d) {
  const cl = d.map(x => x[4]), n = cl.length;
  const ema = (arr, k) => { if (arr.length < k) return null; const a = 2 / (k + 1); let e = arr.slice(0, k).reduce((x, y) => x + y, 0) / k; const out = [e]; for (let i = k; i < arr.length; i++) { e = arr[i] * a + e * (1 - a); out.push(e); } return out; };
  const last2 = (s) => s && s.length >= 2 ? [s[s.length - 1], s[s.length - 2]] : null;
  const sma = (k) => n >= k + 1 ? [cl.slice(n - k).reduce((x, y) => x + y, 0) / k, cl.slice(n - k - 1, n - 1).reduce((x, y) => x + y, 0) / k] : null;
  const dema = (k) => { const e1 = ema(cl, k); if (!e1) return null; const e2 = ema(e1, k); if (!e2 || e2.length < 2) return null;
    return [2 * e1[e1.length - 1] - e2[e2.length - 1], 2 * e1[e1.length - 2] - e2[e2.length - 2]]; };
  const vwma = (k) => { if (n < k + 1) return null; const s = d.slice(n - k), p = d.slice(n - k - 1, n - 1);
    if (s.some(x => !(x[5] > 0)) || p.some(x => !(x[5] > 0))) return null;
    const f = (a) => a.reduce((x, y) => x + y[4] * y[5], 0) / a.reduce((x, y) => x + y[5], 0); return [f(s), f(p)]; };
  const list = [
    ["EMA 9", last2(ema(cl, 9))], ["EMA 20", last2(ema(cl, 20))], ["EMA 50", last2(ema(cl, 50))], ["EMA 100", last2(ema(cl, 100))], ["EMA 200", last2(ema(cl, 200))],
    ["SMA 20", sma(20)], ["SMA 50", sma(50)], ["SMA 100", sma(100)], ["SMA 200", sma(200)],
    ["DEMA 20", dema(20)], ["DEMA 50", dema(50)], ["VWMA 20", vwma(20)]
  ].filter(x => x[1]).map(([k, [v, pv]]) => ({ k, v, pv }));
  // Golden / death cross: SMA 50 vs SMA 200, and how many sessions ago it last flipped
  let cross = null;
  if (n >= 205) {
    const s = (k, end) => cl.slice(end - k, end).reduce((x, y) => x + y, 0) / k;
    const now = s(50, n) > s(200, n);
    let ago = 0; for (let i = n - 1; i >= 200 && ago < 260; i--, ago++) if ((s(50, i) > s(200, i)) !== now) break;
    cross = { golden: now, ago };
  }
  return { list, cross };
}
function nfRSI(cl, k = 14) {
  if (cl.length < k + 2) return null;
  let g = 0, l = 0;
  for (let i = 1; i <= k; i++) { const ch = cl[i] - cl[i - 1]; if (ch > 0) g += ch; else l -= ch; }
  g /= k; l /= k;
  for (let i = k + 1; i < cl.length; i++) { const ch = cl[i] - cl[i - 1]; g = (g * (k - 1) + Math.max(ch, 0)) / k; l = (l * (k - 1) + Math.max(-ch, 0)) / k; }
  return l === 0 ? 100 : 100 - 100 / (1 + g / l);
}

/* ---- Helpers for the deeper read ---- */
let nfIntra = null; // today's intraday candles, saved whenever the 1D chart loads
const nfMin = (t) => Math.floor(((t + 19800) % 86400) / 60);
const nfHM = (t) => { const m = nfMin(t); return `${Math.floor(m / 60)}:${String(m % 60).padStart(2, "0")}`; };

// What happened after similar days in the past (next-day and 3-day outcomes)
function nfAnalogs(d) {
  const n = d.length; if (n < 120) return null;
  const cl = d.map(x => x[4]);
  const feat = (i) => {
    const [, , h, l, c] = d[i], [, , ph, pl, pc] = d[i - 1], pct = (c - pc) / pc * 100, rng = h - l, clv = rng > 0 ? (c - l) / rng : 0.5;
    const type = h <= ph && l >= pl ? "inside" : h > ph && l < pl ? "outside" : h > ph && c < ph ? "failup" : l < pl && c > pl ? "faildn" : "normal";
    const s50 = i >= 50 ? cl.slice(i - 49, i + 1).reduce((a, b) => a + b, 0) / 50 : null;
    return { dir: pct >= 0 ? 1 : -1, size: Math.abs(pct) >= 1 ? 2 : Math.abs(pct) >= 0.4 ? 1 : 0, loc: clv >= 0.67 ? 2 : clv <= 0.33 ? 0 : 1, type, trend: s50 == null ? null : c >= s50 ? 1 : 0 };
  };
  const T = feat(n - 1), F = [];
  for (let i = 51; i < n - 1; i++) F[i] = feat(i);
  const tiers = [["type", "dir", "size", "loc", "trend"], ["type", "dir", "size", "loc"], ["type", "dir", "loc"], ["dir", "size", "loc", "trend"], ["dir", "size", "loc"], ["dir", "loc"]];
  for (const keys of tiers) {
    const m = []; for (let i = 51; i < n - 1; i++) if (keys.every(k => F[i][k] === T[k])) m.push(i);
    if (m.length < 8) continue;
    const nx = m.map(i => (cl[i + 1] - cl[i]) / cl[i] * 100), three = m.filter(i => i + 3 < n).map(i => (cl[i + 3] - cl[i]) / cl[i] * 100);
    const words = {
      type: { inside: "an inside day", outside: "an outside day", failup: "a failed breakout", faildn: "a failed breakdown", normal: "" }[T.type],
      dir: T.dir > 0 ? "an up day" : "a down day", size: ["small (under 0.4%)", "normal-sized (0.4–1%)", "big (over 1%)"][T.size],
      loc: ["closing near the low", "closing mid-range", "closing near the high"][T.loc], trend: T.trend ? "above the 50-day average" : "below the 50-day average"
    };
    const desc = [keys.includes("type") && words.type, keys.includes("size") ? `${words.size} ${T.dir > 0 ? "gain" : "fall"}` : words.dir, words.loc, keys.includes("trend") && words.trend].filter(Boolean).join(", ");
    return { n: m.length, desc, up: nx.filter(v => v > 0).length / nx.length * 100, avg: nx.reduce((a, b) => a + b, 0) / nx.length,
      hi: m.filter(i => d[i + 1][2] > d[i][2]).length / m.length * 100, lo: m.filter(i => d[i + 1][3] < d[i][3]).length / m.length * 100,
      avg3: three.length ? three.reduce((a, b) => a + b, 0) / three.length : null, up3: three.length ? three.filter(v => v > 0).length / three.length * 100 : null, years: Math.round(n / 250 * 10) / 10 };
  }
  return null;
}
const nfCPR = (h, l, c) => { const p = (h + l + c) / 3, bc = (h + l) / 2, tc = 2 * p - bc; return { p, tc: Math.max(tc, bc), bc: Math.min(tc, bc), w: Math.abs(tc - bc) / p * 100 }; };
// Classic pivots for the period the next session falls in (weekly / monthly), from the last completed period
function nfPeriodPivot(d, kind) {
  const key = (t) => { const s = NF_DKEY(t); if (kind === "m") return s.slice(0, 7); const dt = new Date(s + "T00:00:00Z"), wd = (dt.getUTCDay() + 6) % 7; dt.setUTCDate(dt.getUTCDate() - wd); return dt.toISOString().slice(0, 10); };
  const lastKey = key(d[d.length - 1][0]);
  let next = null;
  if (typeof isTradingDay === "function" && typeof addDays === "function") { let t0 = addDays(new Date(NF_DKEY(d[d.length - 1][0]) + "T00:00:00"), 1); for (let k = 0; k < 10 && !isTradingDay(t0); k++) t0 = addDays(t0, 1); next = t0; }
  const nextKey = next ? key(Math.floor(Date.UTC(next.getFullYear(), next.getMonth(), next.getDate(), 4) / 1000)) : lastKey;
  const want = nextKey !== lastKey ? lastKey : null; // the period that just completed
  const groups = new Map(); d.forEach(x => { const k = key(x[0]); if (!groups.has(k)) groups.set(k, []); groups.get(k).push(x); });
  const ks = [...groups.keys()]; const pk = want || ks[ks.length - 2]; const g = groups.get(pk); if (!g) return null;
  const H = Math.max(...g.map(x => x[2])), L = Math.min(...g.map(x => x[3])), C = g[g.length - 1][4], P = (H + L + C) / 3;
  return { p: P, r1: 2 * P - L, s1: 2 * P - H, h: H, l: L };
}
// Today's intraday structure from 1-5 minute candles
function nfIntraday(cs, atr) {
  if (!cs || cs.length < 10) return null;
  const day = NF_DKEY(cs[cs.length - 1][0]);
  cs = cs.filter(x => NF_DKEY(x[0]) === day && nfMin(x[0]) >= 555 && nfMin(x[0]) < 930);
  if (cs.length < 10) return null;
  const or = cs.filter(x => nfMin(x[0]) < 570); if (!or.length) return null;
  const orH = Math.max(...or.map(x => x[2])), orL = Math.min(...or.map(x => x[3]));
  const rest = cs.filter(x => nfMin(x[0]) >= 570);
  const bu = rest.find(x => x[2] > orH), bd = rest.find(x => x[3] < orL);
  const open = cs[0][1], close = cs[cs.length - 1][4];
  let H = -Infinity, L = Infinity, tH = 0, tL = 0; cs.forEach(x => { if (x[2] > H) { H = x[2]; tH = x[0]; } if (x[3] < L) { L = x[3]; tL = x[0]; } });
  const fh = cs.filter(x => nfMin(x[0]) < 615), lh = cs.filter(x => nfMin(x[0]) >= 870);
  const fhChg = fh.length ? fh[fh.length - 1][4] - open : null, lhChg = lh.length ? close - lh[0][1] : null;
  const rng = H - L, oc = rng ? (close - open) / rng : 0, clv = rng ? (close - L) / rng : 0.5;
  const early = (t) => nfMin(t) < 742;
  let type;
  if (Math.abs(oc) >= 0.65) type = oc > 0 ? "Trend day up" : "Trend day down";
  else if (early(tH) && clv <= 0.3 && (H - open) > rng * 0.3) type = "Reversal day down";
  else if (early(tL) && clv >= 0.7 && (open - L) > rng * 0.3) type = "Reversal day up";
  else if (atr && rng < atr * 0.7) type = "Range day";
  else type = "Normal day";
  const first = bu && bd ? (bu[0] < bd[0] ? "up" : "down") : bu ? "up" : bd ? "down" : null;
  return { orH, orL, bu, bd, first, held: first === "up" ? close > orH : first === "down" ? close < orL : null, H, L, tH, tL, fhChg, lhChg, type, open, close, rng };
}
const nfRV = (cl, k) => { if (cl.length < k + 1) return null; const r = []; for (let i = cl.length - k; i < cl.length; i++) r.push(Math.log(cl[i] / cl[i - 1])); const m = r.reduce((a, b) => a + b, 0) / r.length; return Math.sqrt(r.reduce((a, b) => a + (b - m) ** 2, 0) / (r.length - 1)) * Math.sqrt(252) * 100; };
const nfLakh = (v) => { const a = Math.abs(v); return (v < 0 ? "−" : "+") + (a >= 1e5 ? nfNum(a / 1e5, 1) + " L" : nfNum(a, 0)); };

function niftyRead(d0, live, X = {}) {
  const d = X.br && X.br.daily && X.br.daily.length > (d0 || []).length ? nfMergeDaily(d0, X.br.daily) : d0;
  if (!d || d.length < 55) return null;
  const n = d.length, T = d[n - 1], P = d[n - 2];
  const [, o, h, l, c] = T, [, , ph, pl, pc] = P;
  const avg = (a) => a.reduce((x, y) => x + y, 0) / a.length;
  const tr = (i) => Math.max(d[i][2] - d[i][3], Math.abs(d[i][2] - d[i - 1][4]), Math.abs(d[i][3] - d[i - 1][4]));
  const atr = avg(Array.from({ length: 14 }, (_, k) => tr(n - 2 - k)));
  const typ = avg(Array.from({ length: 20 }, (_, k) => Math.abs(d[n - 2 - k][4] - d[n - 3 - k][4]) / d[n - 3 - k][4] * 100));
  const sma = (k) => avg(d.slice(n - k).map(x => x[4]));
  const s20 = sma(20), s50 = sma(50);
  const chg = c - pc, pct = chg / pc * 100, mult = Math.abs(pct) / typ, rng = h - l, ratio = rng / atr;
  const clv = rng > 0 ? (c - l) / rng : 0.5, gap = (o - pc) / pc * 100;
  const pts = (v) => nfNum(Math.abs(v), 0), lvl = (v) => nfNum(v, 0), sp = (v, k = 2) => (v >= 0 ? "+" : "−") + nfNum(Math.abs(v), k);
  const tag = (txt, tone) => ({ tag: txt, tone });
  const groups = [];
  const out = [];
  const sig = [], S = (w, txt) => { if (w) sig.push({ w, txt }); };

  /* ===== 1. Price action ===== */
  out.push({ ...tag(mult >= 1.5 ? "Big move" : mult <= 0.5 ? "Quiet day" : "Normal move", chg >= 0 ? "up" : "down"), t: "Size of the move", x: `Nifty ${chg >= 0 ? "gained" : "lost"} ${pts(chg)} points (${nfNum(pct)}%), about ${nfNum(mult, 1)}x its usual daily move of ${nfNum(typ)}%. ` +
    (mult >= 1.5 ? "A move this big usually carries institutional participation; don't fade it without a clear reversal signal."
      : mult <= 0.5 ? "A quiet session. Option premiums decayed without direction, which favours sellers over buyers."
      : "A normal-sized move, so the location of the close matters more than the size.") });

  out.push({ ...tag(ratio >= 1.3 ? "Expansion" : ratio <= 0.7 ? "Contraction" : "Normal range", ratio >= 1.3 ? "warn" : "flat"), t: "Range and volatility", x: `Today's range was ${pts(rng)} points against a 14-day average (ATR) of ${pts(atr)}. ` +
    (ratio >= 1.3 ? "Range expansion: volatility is rising. Widen stops or cut position size, and expect option premiums to stay firm."
      : ratio <= 0.7 ? "Range contraction: the market is coiling. Compression usually comes before expansion, so watch for a break of today's high or low."
      : "Range was close to normal, no volatility signal on its own.") });

  out.push({ ...tag(clv >= 0.75 ? "Buyers" : clv <= 0.25 ? "Sellers" : "Balanced", clv >= 0.75 ? "up" : clv <= 0.25 ? "down" : "flat"), t: "Who controlled the close", x: `Nifty closed at ${Math.round(clv * 100)}% of the day's range. ` +
    (clv >= 0.75 ? `Buyers held control into the close. Follow-through above ${lvl(h)} would confirm it.`
      : clv <= 0.25 ? `Sellers held control into the close. A break below ${lvl(l)} would confirm it.`
      : `Neither side won. Treat ${lvl(h)} and ${lvl(l)} as the battle lines for the next session.`) });

  if (Math.abs(gap) >= 0.3) {
    const filled = gap > 0 ? l <= pc : h >= pc;
    out.push({ ...tag(filled ? "Filled" : "Unfilled", gap > 0 ? "up" : "down"), t: gap > 0 ? "Gap up" : "Gap down", x: `Nifty opened ${nfNum(Math.abs(gap))}% ${gap > 0 ? "above" : "below"} the previous close. ` +
      (filled ? `The gap was filled back to ${lvl(pc)}, so the opening ${gap > 0 ? "buyers" : "sellers"} were tested and the early conviction faded.`
        : `The gap stayed unfilled, a sign of strength in that direction. ${lvl(pc)} now acts as ${gap > 0 ? "support" : "resistance"}.`) });
  }

  if (h > ph && c < ph) out.push({ tag: "Trap", tone: "down", t: "Failed breakout", x: `Price went above yesterday's high of ${lvl(ph)} but closed back below it. Buyers who chased the breakout are trapped, and their exits can fuel a move lower.` });
  else if (l < pl && c > pl) out.push({ tag: "Trap", tone: "up", t: "Failed breakdown", x: `Price went below yesterday's low of ${lvl(pl)} but closed back above it. Sellers are trapped, and short covering can push it higher.` });
  else if (h <= ph && l >= pl) out.push({ tag: "Compression", tone: "warn", t: "Inside day", x: `The whole day stayed inside yesterday's range (${lvl(pl)} to ${lvl(ph)}). This is indecision and compression; the side that breaks first usually gets the follow-through.` });
  else if (h > ph && l < pl) out.push({ tag: "Two-sided", tone: "warn", t: "Outside day", x: `Nifty took out both yesterday's high and low. Volatile two-sided trade; the direction of the close (${chg >= 0 ? "up" : "down"}) usually carries more weight the next day.` });

  out.push({ ...tag(c >= s20 && c >= s50 ? "Uptrend" : c < s20 && c < s50 ? "Downtrend" : "Mixed", c >= s20 && c >= s50 ? "up" : c < s20 && c < s50 ? "down" : "flat"), t: "Trend context", x: `Nifty is ${c >= s20 ? "above" : "below"} its 20-day average (${lvl(s20)}) and ${c >= s50 ? "above" : "below"} its 50-day average (${lvl(s50)}). ` +
    (c >= s20 && c >= s50 ? "The trend is up; dips toward the 20-day average are where trend traders look to buy."
      : c < s20 && c < s50 ? "The trend is down; rallies toward the 20-day average are where trend traders look to sell."
      : "Mixed signals between the short and medium trend; stay selective and trade the levels, not the trend.") });
  S(c >= s20 && c >= s50 ? 1 : c < s20 && c < s50 ? -1 : 0, c >= s20 ? "Nifty is above its 20 and 50-day averages" : "Nifty is below its 20 and 50-day averages");
  S(clv >= 0.75 ? 0.75 : clv <= 0.25 ? -0.75 : 0, clv >= 0.75 ? "buyers controlled the close" : "sellers controlled the close");
  if (h > ph && c < ph) S(-0.75, "a failed breakout above yesterday's high"); else if (l < pl && c > pl) S(0.75, "a failed breakdown below yesterday's low");
  groups.push({ h: "Price action", items: out, free: true });

  /* ----- Intraday structure ----- */
  const pItems = [], ID = nfIntraday(X.intra, atr);
  if (ID) {
    let x = `The opening range (first 15 minutes) was ${lvl(ID.orL)}–${lvl(ID.orH)}. `;
    if (!ID.first) x += "Price never broke out of it: a tight, indecisive session. ";
    else { const b = ID.first === "up" ? ID.bu : ID.bd; x += `Price first broke ${ID.first === "up" ? "above" : "below"} it at ${nfHM(b[0])} and ` + (ID.held ? `held, closing ${ID.first === "up" ? "above" : "below"} the range: the ${ID.first === "up" ? "breakout" : "breakdown"} was genuine. ` : `reversed by the close: a failed opening-range ${ID.first === "up" ? "breakout" : "breakdown"}, which often traps traders who chased it. `); }
    x += `The day's high came at ${nfHM(ID.tH)} and the low at ${nfHM(ID.tL)}. `;
    if (ID.fhChg != null) x += `First hour: ${sp(ID.fhChg, 0)} ${Math.round(Math.abs(ID.fhChg)) === 1 ? "point" : "points"}. `;
    if (ID.lhChg != null) x += `Last hour (2:30–3:30): ${sp(ID.lhChg, 0)} ${Math.round(Math.abs(ID.lhChg)) === 1 ? "point" : "points"}` + (Math.abs(ID.lhChg) >= atr * 0.25 ? `, a strong ${ID.lhChg > 0 ? "push higher" : "sell-off"} into the close; late moves usually reflect institutional positioning and often carry into the next open. ` : ", a quiet finish. ");
    x += { "Trend day up": "Day type: trend day up. Price opened near the low and closed near the high; buying persisted all session.", "Trend day down": "Day type: trend day down. Price opened near the high and closed near the low; selling persisted all session.",
      "Reversal day down": "Day type: reversal day. Early strength was sold into and the close came near the low, a bearish shift in control.", "Reversal day up": "Day type: reversal day. Early weakness was bought and the close came near the high, a bullish shift in control.",
      "Range day": "Day type: range day. A narrow, rotational session with no follow-through either way.", "Normal day": "Day type: normal day. Some directional movement, but neither side dominated the whole session." }[ID.type];
    if (ID.lhChg != null && Math.abs(ID.lhChg) >= atr * 0.25) S(ID.lhChg > 0 ? 0.5 : -0.5, ID.lhChg > 0 ? "a strong last hour" : "a weak last hour");
    if (ID.first && ID.held === false) S(ID.first === "up" ? -0.5 : 0.5, ID.first === "up" ? "a failed breakout above the opening range" : "a failed break below the opening range");
    pItems.push({ tag: ID.type.replace(" day", ""), tone: /up/.test(ID.type) ? "up" : /down/.test(ID.type) ? "down" : "flat", t: "How the day unfolded", x });
  }
  /* ----- CPR, weekly and monthly pivots ----- */
  const cprT = nfCPR(ph, pl, pc), cprN = nfCPR(h, l, c);
  const widths = d.slice(-61, -1).map((z, i, a) => nfCPR(z[2], z[3], z[4]).w);
  const wPct = widths.length ? widths.filter(w => w < cprN.w).length / widths.length * 100 : 50;
  const wp = nfPeriodPivot(d, "w"), mp = nfPeriodPivot(d, "m");
  {
    const rel = cprN.bc > cprT.tc ? "higher" : cprN.tc < cprT.bc ? "lower" : "overlapping";
    let x = `Next session's CPR (Central Pivot Range) is ${lvl(cprN.bc)}–${lvl(cprN.tc)}, with the pivot at ${lvl(cprN.p)}. Its width is ${nfNum(cprN.w, 2)}%, ` +
      (wPct <= 25 ? "among the narrowest of the last 60 sessions. A narrow CPR often comes before a trending day; be ready for a directional move rather than a range." : wPct >= 75 ? "among the widest of the last 60 sessions. A wide CPR usually points to a sideways, two-way session." : "about average, so no strong trending or sideways signal from width alone.");
    x += rel === "higher" ? ` It sits entirely above today's CPR (higher value relationship): a bullish shift in value.` : rel === "lower" ? ` It sits entirely below today's CPR (lower value relationship): a bearish shift in value.` : ` It overlaps today's CPR: value is balanced, which favours range trading.`;
    x += c > cprN.tc ? ` Nifty closed above it, so the CPR acts as support for the open.` : c < cprN.bc ? ` Nifty closed below it, so the CPR acts as resistance for the open.` : ` Nifty closed inside it, so the open will decide the bias.`;
    if (wp) x += ` Weekly pivot ${lvl(wp.p)} (R1 ${lvl(wp.r1)}, S1 ${lvl(wp.s1)}); Nifty is ${c >= wp.p ? "above" : "below"} it, so the week leans ${c >= wp.p ? "positive" : "negative"}.`;
    if (mp) x += ` Monthly pivot ${lvl(mp.p)}; Nifty is ${c >= mp.p ? "above" : "below"} it.`;
    S(rel === "higher" ? 0.5 : rel === "lower" ? -0.5 : 0, rel === "higher" ? "a higher CPR (value moving up)" : "a lower CPR (value moving down)");
    if (wp) S(c >= wp.p ? 0.25 : -0.25, c >= wp.p ? "above the weekly pivot" : "below the weekly pivot");
    pItems.push({ tag: wPct <= 25 ? "Narrow CPR" : wPct >= 75 ? "Wide CPR" : rel === "higher" ? "Higher CPR" : rel === "lower" ? "Lower CPR" : "CPR", tone: wPct <= 25 ? "warn" : rel === "higher" ? "up" : rel === "lower" ? "down" : "flat", t: "CPR and pivots", x });
  }
  if (pItems.length) groups.push({ h: "Structure and pivots", items: pItems });

  /* ----- Statistical edge: similar days in the past ----- */
  const an = nfAnalogs(d);
  if (an) {
    const x = `In the last ${an.years} years, Nifty had ${an.n} days like today (${an.desc}). The next day it closed higher ${Math.round(an.up)}% of the time, with an average move of ${sp(an.avg)}%. It went above the day's high ${Math.round(an.hi)}% of the time and below the day's low ${Math.round(an.lo)}% of the time.` +
      (an.avg3 != null ? ` Three days later it was higher ${Math.round(an.up3)}% of the time (average ${sp(an.avg3)}%).` : "") +
      ` ${an.up >= 65 ? "History leans bullish for the next session." : an.up <= 35 ? "History leans bearish for the next session." : "History shows no strong edge either way, so the levels matter more than the pattern."}` +
      (an.n < 15 ? " The sample is small, so treat this as a hint, not a rule." : "");
    S(an.up >= 65 ? 1 : an.up <= 35 ? -1 : 0, `similar past days closed higher next day ${Math.round(an.up)}% of the time`);
    groups.push({ h: "Statistical edge", items: [{ tag: an.up >= 65 ? "Leans up" : an.up <= 35 ? "Leans down" : "No edge", tone: an.up >= 65 ? "up" : an.up <= 35 ? "down" : "flat", t: "What happened after similar days", x }] });
  }

  /* ===== 2. Breadth and sectors ===== */
  const br = X.br && !X.br.error ? X.br : null, bItems = [];
  const chain = br && br.chain && br.chain.straddle ? br.chain : null, fu = br && br.fut && br.fut.last ? br.fut : null;
  if (br) {
    const b50 = br.breadth && br.breadth.n50, b500 = br.breadth && br.breadth.n500;
    if (b50 && b50.adv != null) {
      const a = b50.adv, dc = b50.dec, ad = dc ? a / dc : a, up = chg >= 0;
      const broadUp = ad >= 1.5, broadDn = ad <= 0.67, div = (up && a < dc) || (!up && a > dc);
      const tg = div ? ["Divergence", "warn"] : up ? (broadUp ? ["Broad rally", "up"] : ["Narrow rally", "warn"]) : (broadDn ? ["Broad selling", "down"] : ["Narrow fall", "warn"]);
      let x = `In the Nifty 50, ${a} stocks rose and ${dc} fell, an advance-decline ratio of ${nfNum(ad, 2)}.`;
      if (b500 && b500.adv != null) x += ` Across the wider Nifty 500, ${b500.adv} rose and ${b500.dec} fell.`;
      x += " " + (div ? (up ? "Divergence: Nifty rose but more stocks fell. A few heavyweights carried the index, and such rallies are fragile without wider support."
          : "Divergence: Nifty fell but more stocks rose. Heavyweights dragged the index while the broader market held up, so the selling may not be as deep as the index suggests.")
        : up ? (broadUp ? "Breadth was strong: the rally had wide participation, which makes it more reliable." : "Breadth was only modest; the move was led by a handful of stocks.")
        : (broadDn ? "Breadth was weak: selling was broad-based, not limited to a few names." : "Breadth was mixed; the fall was concentrated in a few stocks."));
      const bm = (br.broad || []).filter(z => z.pct != null && z.name !== "Nifty 500");
      if (bm.length) {
        const out2 = bm.filter(z => z.pct > pct + 0.3), und = bm.filter(z => z.pct < pct - 0.3);
        x += ` ${bm.map(z => `${z.name} ${sp(z.pct)}%`).join(", ")} against Nifty ${sp(pct)}%. ` +
          (out2.length === bm.length ? "Mid and small caps outperformed: risk appetite is healthy (risk-on)." : und.length === bm.length ? "Mid and small caps underperformed: traders are getting defensive with riskier stocks." : "Broader market moved roughly in line with Nifty.");
      }
      const tot = a + dc + (b50.unch || 0) || 1;
      let html = `<div class="br-bar" role="img" aria-label="${a} advances, ${dc} declines"><i class="up" style="width:${a / tot * 100}%"></i><i class="flat" style="width:${(b50.unch || 0) / tot * 100}%"></i><i class="down" style="width:${dc / tot * 100}%"></i></div>
        <div class="br-leg"><span class="up">▲ ${a} advances</span><span class="down">▼ ${dc} declines</span></div>`;
      if (br.stocks) html += `<div class="br-stk"><div><span class="muted small">Top Nifty gainers</span>${br.stocks.gainers.map(s => `<p><b>${esc(s.s)}</b><span class="up">${sp(s.p)}%</span></p>`).join("")}</div>
        <div><span class="muted small">Top Nifty losers</span>${br.stocks.losers.map(s => `<p><b>${esc(s.s)}</b><span class="${s.p >= 0 ? "up" : "down"}">${sp(s.p)}%</span></p>`).join("")}</div></div>`;
      bItems.push({ tag: tg[0], tone: tg[1], t: "Advances and declines", x, html });
      S(div ? (up ? -0.5 : 0.5) : up ? (broadUp ? 1 : 0.25) : (broadDn ? -1 : -0.25), div ? "breadth disagrees with the index move" : `${up ? "broad" : "weak"} breadth (${a} up, ${dc} down)`);
    }
    const secs = (br.sectors || []).filter(s => s.pct != null).slice().sort((p1, p2) => p2.pct - p1.pct);
    if (secs.length >= 4) {
      const green = secs.filter(s => s.pct > 0).length, top = secs.slice(0, 2), bot = secs.slice(-2).reverse();
      const topDef = top.filter(s => DEFENSIVE.has(s.name)).length, botCyc = bot.filter(s => CYCLICAL.has(s.name)).length;
      const topCyc = top.filter(s => CYCLICAL.has(s.name)).length, botDef = bot.filter(s => DEFENSIVE.has(s.name)).length;
      const rot = topDef >= 1 && botCyc >= 1 && topCyc === 0 ? ["Risk-off", "down"] : topCyc >= 1 && botDef >= 1 && topDef === 0 ? ["Risk-on", "up"] : green >= secs.length * 0.75 ? ["Broad buying", "up"] : green <= secs.length * 0.25 ? ["Broad selling", "down"] : ["Mixed", "flat"];
      let x = `${green} of ${secs.length} sectors closed green. Strongest: ${top.map(s => `${s.name} (${sp(s.pct)}%)`).join(", ")}. Weakest: ${bot.map(s => `${s.name} (${sp(s.pct)}%)`).join(", ")}. `;
      x += rot[0] === "Risk-off" ? "Money moved into defensive sectors while cyclicals lagged: a risk-off rotation. Traders are protecting capital, not chasing growth."
        : rot[0] === "Risk-on" ? "Cyclical, economy-sensitive sectors led while defensive ones lagged: a risk-on rotation. Traders are willing to take risk."
        : rot[0] === "Broad buying" ? "Buying was spread across almost every sector, which backs the index move."
        : rot[0] === "Broad selling" ? "Selling hit almost every sector, a sign of market-wide risk reduction."
        : "No clear rotation: money moved stock by stock rather than by theme.";
      const mx = Math.max(...secs.map(s => Math.abs(s.pct)), 0.5);
      const html = `<div class="sec-bars">${secs.map(s => `<div class="sec-bar"><span class="sb-n">${esc(s.name)}</span><span class="sb-t"><i class="${s.pct >= 0 ? "up" : "down"}" style="width:${Math.max(2, Math.abs(s.pct) / mx * 50)}%;${s.pct >= 0 ? "left:50%" : "right:50%"}"></i></span><span class="sb-v ${s.pct >= 0 ? "up" : "down"}">${sp(s.pct)}%</span></div>`).join("")}</div>`;
      bItems.push({ tag: rot[0], tone: rot[1], t: "Sector leaders and laggards", x, html });
      S(rot[0] === "Risk-on" ? 0.5 : rot[0] === "Risk-off" ? -0.5 : 0, rot[0] === "Risk-on" ? "a risk-on sector rotation" : "a risk-off sector rotation");

      // Why: short reasoning per top/bottom sector, built from the data we have
      const news = (X.news || []).filter(nw => !nw.published || Date.now() - new Date(nw.published) < 30 * 3600 * 1000);
      const why = (s, lead) => {
        const rs = s.pct - pct, bits = [];
        bits.push(`${Math.abs(rs) < 0.1 ? "in line with" : nfNum(Math.abs(rs)) + "% " + (rs > 0 ? "ahead of" : "behind")} Nifty`);
        if (s.adv != null && s.dec != null) { const tot2 = s.adv + s.dec + (s.unch || 0);
          bits.push(lead ? (s.adv >= tot2 * 0.7 ? `broad-based, ${s.adv} of ${tot2} stocks rose` : `narrow, only ${s.adv} of ${tot2} stocks rose`)
            : (s.dec >= tot2 * 0.7 ? `broad-based weakness, ${s.dec} of ${tot2} stocks fell` : `concentrated, ${s.dec} of ${tot2} stocks fell`)); }
        const drv = (s.drivers && s.drivers.length ? s.drivers : (lead ? s.leaders : s.laggards)) || [];
        if (drv.length) bits.push(`${s.drivers ? "moved most by" : lead ? "led by" : "dragged by"} ${drv.slice(0, 2).map(z => `${z.s} ${sp(z.p, 1)}%`).join(" and ")}`);
        const re = SECTOR_NEWS[s.name], hl = re ? news.find(nw => re.test(nw.title || "")) : null;
        return `<li><strong>${esc(s.name)}</strong> <span class="${s.pct >= 0 ? "up" : "down"}">${sp(s.pct)}%</span><br>${esc(bits.join("; "))}.` +
          `${hl ? `<br><span class="muted small">In the news:</span> <a href="${esc(hl.link)}" target="_blank" rel="noopener" class="why-news">${esc(hl.title)}</a>` : ""}` +
          `${SECTOR_DRIVERS[s.name] ? `<br><span class="muted small">Usually moved by ${esc(SECTOR_DRIVERS[s.name])}.</span>` : ""}</li>`;
      };
      bItems.push({ tag: "Why", tone: "up", t: "Why the leaders were strong", x: "Relative strength, how many stocks joined in, and which names did the heavy lifting:", html: `<ul class="why-list">${top.map(s => why(s, true)).join("")}</ul>` });
      bItems.push({ tag: "Why", tone: "down", t: "Why the laggards were weak", x: "Where the selling came from, and whether it was broad or limited to a few names:", html: `<ul class="why-list">${bot.map(s => why(s, false)).join("")}</ul>` });
    }
  }
  if (X.bank && X.bank.price && X.bank.prevClose) {
    const bp = (X.bank.price - X.bank.prevClose) / X.bank.prevClose * 100, rd = bp - pct;
    let x = `Bank Nifty ${sp(bp)}% against Nifty ${sp(pct)}% today, ${rd >= 0 ? "outperforming" : "underperforming"} by ${nfNum(Math.abs(rd))}%. `, r20 = null;
    const bd = br && br.bankDaily;
    if (bd && bd.length > 21) { const b20 = (bd[bd.length - 1][1] / bd[bd.length - 21][1] - 1) * 100, n20 = (c / d[n - 21][4] - 1) * 100; r20 = b20 - n20; x += `Over the last 20 sessions: Bank Nifty ${sp(b20)}%, Nifty ${sp(n20)}%. `; }
    x += chg >= 0 ? (rd >= 0 ? "Banks led the rally. Financials are about a third of Nifty, so bank-led rallies tend to be more durable." : "Nifty rose without the banks keeping pace. Rallies that lack bank participation are harder to sustain.")
      : (rd < 0 ? "Banks led the fall, the heaviest drag on the index. Watch Bank Nifty's support levels for the next move." : "Banks held up better than Nifty, which cushions the downside.");
    S(rd > 0.3 ? 0.5 : rd < -0.3 ? -0.5 : 0, rd > 0 ? "Bank Nifty outperforming" : "Bank Nifty lagging");
    bItems.push({ tag: rd >= 0 ? "Banks leading" : "Banks lagging", tone: rd >= 0 ? "up" : "down", t: "Bank Nifty vs Nifty", x });
  }
  if (bItems.length) groups.push({ h: "Breadth and sectors", items: bItems, note: br && br.approx ? "Breadth and sectors are approximate (Nifty 50 stocks only) because NSE data wasn't reachable." : "" });

  /* ===== Institutional flows ===== */
  const fItems = [];
  const fl = br && br.flows;
  if (fl && (fl.fii != null || fl.dii != null)) {
    const f = fl.fii || 0, di = fl.dii || 0, cr = (v) => "₹" + nfNum(Math.abs(v), 0) + " Cr";
    let x = `${fl.date ? `On ${fl.date}, f` : "F"}oreign investors (FIIs) net ${f >= 0 ? "bought" : "sold"} ${cr(f)} in the cash market, and domestic institutions (DIIs) net ${di >= 0 ? "bought" : "sold"} ${cr(di)}. `;
    x += f >= 0 && di >= 0 ? "Both bought: strong institutional support." : f < 0 && di >= 0 ? (di >= Math.abs(f) ? "DIIs absorbed all of the FII selling, which cushions falls but tends to cap rallies." : "DIIs bought, but not enough to absorb FII selling: net institutional pressure was negative.")
      : f >= 0 && di < 0 ? "FIIs bought while DIIs booked profits, a sign of fresh foreign interest." : "Both sold: broad institutional selling, a clearly bearish signal.";
    x += " These are provisional figures, published by NSE each evening.";
    S(f > 1000 ? 0.75 : f > 0 ? 0.25 : f < -1000 ? -0.75 : -0.25, `FIIs net ${f >= 0 ? "bought" : "sold"} ${cr(f)} in cash`);
    fItems.push({ tag: f >= 0 ? "FII buying" : "FII selling", tone: f >= 0 ? "up" : "down", t: "FII and DII cash flows", x });
  }
  const pt = br && br.part && br.part.latest;
  if (pt && pt.fii && pt.fii.fl != null) {
    const lp = (r) => r && r.fl != null && (r.fl + r.fs) ? r.fl / (r.fl + r.fs) * 100 : null;
    const L = lp(pt.fii), Lp = lp(br.part.prev && br.part.prev.fii), Lc = lp(pt.client), dL = Lp != null ? L - Lp : null;
    let x = `FIIs hold ${nfNum(L, 0)}% long and ${nfNum(100 - L, 0)}% short in index futures (as of ${pt.date})` + (dL != null ? `, ${Math.abs(dL) < 0.5 ? "unchanged" : (dL > 0 ? "up" : "down") + " from " + nfNum(Lp, 0) + "%"} the previous day. ` : ". ");
    x += L < 25 ? "This is an extreme short position. FIIs are betting on downside, but such extremes have often preceded sharp short-covering rallies when the trend turns. " : L < 40 ? "FIIs lean short, a bearish tilt in their positioning. " : L > 65 ? "FIIs are strongly long, a bullish stance. " : L > 55 ? "FIIs lean long. " : "Positioning is fairly balanced. ";
    if (dL != null && Math.abs(dL) >= 2) x += `The ${dL > 0 ? "rise" : "fall"} in long exposure matters more than the level: FIIs are ${dL > 0 ? "covering shorts or adding longs" : "adding shorts or cutting longs"}. `;
    if (Lc != null) x += `Retail clients are ${nfNum(Lc, 0)}% long${(Lc > 55 && L < 45) || (Lc < 45 && L > 55) ? ", on the opposite side of FIIs, which is common; FIIs have usually been on the right side over time" : ""}.`;
    const pn = pt.fii.pl - pt.fii.ps, cn = pt.fii.cl - pt.fii.cs;
    if (Number.isFinite(pn) && Number.isFinite(cn)) x += ` In index options, FIIs are net ${pn >= 0 ? "long" : "short"} puts (${nfLakh(pn)} contracts) and net ${cn >= 0 ? "long" : "short"} calls (${nfLakh(cn)}).`;
    S((L < 25 ? -1 : L < 40 ? -0.5 : L > 65 ? 1 : L > 55 ? 0.5 : 0) + (dL == null ? 0 : dL >= 3 ? 0.25 : dL <= -3 ? -0.25 : 0), `FIIs ${nfNum(L, 0)}% long in index futures`);
    fItems.push({ tag: L < 40 ? "FIIs short" : L > 55 ? "FIIs long" : "Balanced", tone: L < 40 ? "down" : L > 55 ? "up" : "flat", t: "FII positioning in index futures", x });
  }
  if (fu && fu.oiChg != null && fu.chg != null) {
    const pu = fu.chg >= 0, ou = fu.oiChg >= 0;
    const bt = pu && ou ? ["Long buildup", "up", "Price up with rising open interest: fresh buying. Bulls are adding positions, the strongest form of a rally.", 1]
      : pu ? ["Short covering", "up", "Price up with falling open interest: sellers are exiting. Rallies driven by covering can be sharp but fade once the covering ends.", 0.5]
      : ou ? ["Short buildup", "down", "Price down with rising open interest: fresh selling. Bears are adding positions, the strongest form of a decline.", -1]
      : ["Long unwinding", "down", "Price down with falling open interest: buyers are exiting. Weakness from profit-taking rather than aggressive selling.", -0.5];
    const spot = fu.spot || c, basis = fu.last - spot;
    let x = `Nifty ${fu.expiry} futures ${sp(fu.pct || 0)}% with open interest ${sp(fu.oiPct || 0)}%. ${bt[2]}`;
    const exD = (() => { const m = String(fu.expiry).match(/(\d{1,2})-([A-Za-z]{3})-(\d{4})/); if (!m) return null; const dt = new Date(`${m[2]} ${m[1]}, ${m[3]}`); return Math.max(1, Math.round((dt - addDays(istNow(), 0)) / 86400000)); })();
    if (exD) { const fair = spot * 0.065 * exD / 365; x += ` Futures trade at a ${basis >= 0 ? "premium" : "discount"} of ${pts(basis)} points to spot` + (basis < 0 ? ", a bearish sign: traders are willing to sell below spot." : basis < fair * 0.5 ? `, thinner than the usual carry (about ${pts(fair)}): a mildly bearish tilt.` : basis > fair * 1.6 ? `, richer than the usual carry (about ${pts(fair)}): buyers are paying up, a bullish tilt.` : ", close to the normal carry cost."); }
    S(bt[3], bt[0].toLowerCase() + " in Nifty futures");
    fItems.push({ tag: bt[0], tone: bt[1], t: "Nifty futures buildup", x });
  }
  if (fItems.length) groups.push({ h: "Institutional flows", items: fItems });

  /* ===== 3. Moving averages ===== */
  const ma = nfMA(d), mItems = [];
  if (ma.list.length) {
    const near = ma.list.map(m => ({ ...m, dist: (m.v - c) / c * 100 })).filter(m => Math.abs(m.v - c) <= 1.5 * atr).sort((x1, x2) => Math.abs(x1.dist) - Math.abs(x2.dist));
    const far = ma.list.filter(m => Math.abs(m.v - c) > 1.5 * atr);
    const above = ma.list.filter(m => c >= m.v).length;
    const crossed = ma.list.filter(m => (pc < m.pv && c >= m.v) || (pc > m.pv && c <= m.v));
    const res = near.filter(m => m.v > c)[0], sup = near.filter(m => m.v <= c)[0];
    // Confluence: two or more averages within a quarter ATR of each other
    const srt = [...near].sort((x1, x2) => x1.v - x2.v), zones = [];
    for (let i = 0; i < srt.length; i++) { const z = [srt[i]]; while (i + 1 < srt.length && srt[i + 1].v - z[z.length - 1].v <= atr * 0.25) z.push(srt[++i]); if (z.length >= 2) zones.push(z); }
    const tg = above >= ma.list.length * 0.75 ? ["Above most", "up"] : above <= ma.list.length * 0.25 ? ["Below most", "down"] : ["Tangled", "warn"];
    let x = `Nifty is above ${above} of the ${ma.list.length} averages tracked. `;
    if (near.length) x += `${near.length} ${near.length === 1 ? "average sits" : "averages sit"} within reach (1.5x ATR, about ${pts(1.5 * atr)} points). `;
    else x += `None are within 1.5x ATR (${pts(1.5 * atr)} points), so averages aren't a near-term factor; price is stretched away from them. `;
    if (res) x += `Nearest overhead: ${res.k} at ${lvl(res.v)} (${nfNum(res.dist)}% above), likely resistance. `;
    if (sup) x += `Nearest below: ${sup.k} at ${lvl(sup.v)} (${nfNum(Math.abs(sup.dist))}% below), likely support. `;
    zones.forEach(z => { x += `Confluence zone ${lvl(z[0].v)}–${lvl(z[z.length - 1].v)} (${z.map(m => m.k).join(" + ")}): several averages stacked, so expect a stronger reaction there. `; });
    if (crossed.length) x += `Today Nifty ${crossed.map(m => (c >= m.v ? "reclaimed " : "lost ") + m.k).join(", ")}. `;
    if (ma.cross) x += ma.cross.golden ? `Long-term structure: golden cross (SMA 50 above SMA 200)${ma.cross.ago < 260 ? `, flipped ${ma.cross.ago} sessions ago` : ""}.` : `Long-term structure: death cross (SMA 50 below SMA 200)${ma.cross.ago < 260 ? `, flipped ${ma.cross.ago} sessions ago` : ""}.`;
    const row = (m) => `<div class="ma-row${Math.abs(m.v - c) <= 1.5 * atr ? " near" : ""}"><span>${m.k}</span><strong>${lvl(m.v)}</strong><span class="${m.v > c ? "down" : "up"}">${m.v > c ? "Resistance" : "Support"} · ${sp(m.dist ?? (m.v - c) / c * 100)}%</span></div>`;
    const html = `<div class="ma-tbl">${near.map(row).join("")}</div>` + (far.length ? `<details class="ma-more"><summary>${far.length} more averages further away</summary><div class="ma-tbl">${far.map(m => row({ ...m, dist: (m.v - c) / c * 100 })).join("")}</div></details>` : "") +
      (!ma.list.some(m => m.k === "VWMA 20") ? `<p class="muted small" style="margin:6px 0 0">VWMA needs index volume, which isn't available from the data feed right now.</p>` : "");
    mItems.push({ tag: tg[0], tone: tg[1], t: "Moving averages near price", x: x.trim(), html });
    S(above >= ma.list.length * 0.75 ? 1 : above <= ma.list.length * 0.25 ? -1 : 0, `Nifty is above ${above} of ${ma.list.length} moving averages`);
  }
  if (mItems.length) groups.push({ h: "Moving averages", items: mItems });

  /* ===== 4. Momentum and volatility ===== */
  const vItems = [], cl = d.map(z => z[4]), rsi = nfRSI(cl);
  if (rsi != null) {
    let streak = 0; const dir = Math.sign(cl[n - 1] - cl[n - 2]);
    for (let i = n - 1; i > 0 && Math.sign(cl[i] - cl[i - 1]) === dir && dir !== 0; i--) streak++;
    const yr = d.slice(-250), hi52 = Math.max(...yr.map(z => z[2])), lo52 = Math.min(...yr.map(z => z[3]));
    const tg = rsi >= 70 ? ["Overbought", "warn"] : rsi <= 30 ? ["Oversold", "warn"] : rsi >= 55 ? ["Bullish zone", "up"] : rsi <= 45 ? ["Bearish zone", "down"] : ["Neutral", "flat"];
    let x = `RSI (14) is ${nfNum(rsi, 1)}. ` + (rsi >= 70 ? "Momentum is stretched to the upside; fresh longs carry pullback risk, though strong trends can stay overbought for a while."
      : rsi <= 30 ? "Momentum is stretched to the downside; shorts carry bounce risk, and short covering can be sharp."
      : rsi >= 55 ? "Momentum favours buyers without being stretched." : rsi <= 45 ? "Momentum favours sellers without being stretched." : "Momentum is neutral, no edge either way.");
    if (streak >= 2) x += ` Nifty has closed ${dir > 0 ? "higher" : "lower"} for ${streak} sessions in a row${streak >= 5 ? ", a long streak; a pause or pullback becomes more likely" : ""}.`;
    if (d.length >= 200) x += ` It is ${nfNum((hi52 - c) / hi52 * 100, 1)}% below its 52-week high (${lvl(hi52)}) and ${nfNum((c - lo52) / lo52 * 100, 1)}% above its 52-week low (${lvl(lo52)}).`;
    vItems.push({ tag: tg[0], tone: tg[1], t: "Momentum", x });
    S(rsi >= 55 && rsi < 70 ? 0.5 : rsi <= 45 && rsi > 30 ? -0.5 : 0, `RSI at ${nfNum(rsi, 0)}`);
  }
  const vix = br && br.vix && br.vix.last ? br.vix : null;
  let em = null, emx = null;
  if (vix) {
    em = c * vix.last / 100 / Math.sqrt(252);
    const ex = (typeof upcomingExpiries === "function" ? upcomingExpiries(20) : []).find(z => z.kind.startsWith("nifty"));
    let tdays = 0; if (ex) { for (let t0 = addDays(istNow(), 1); t0 <= ex.date; t0 = addDays(t0, 1)) if (isTradingDay(t0)) tdays++; }
    const tg = vix.pct >= 5 ? ["Fear rising", "down"] : vix.pct <= -5 ? ["Fear easing", "up"] : vix.last < 12 ? ["Calm", "flat"] : vix.last > 20 ? ["High fear", "down"] : ["Steady", "flat"];
    let x = `India VIX is ${nfNum(vix.last)} (${sp(vix.pct)}% today). ` +
      (vix.pct >= 5 ? (chg >= 0 ? "VIX rose even as Nifty gained, so traders are paying up for protection; the rally isn't fully trusted." : "VIX jumped with the fall: fear is building and option premiums are getting expensive.")
        : vix.pct <= -5 ? (chg >= 0 ? "VIX fell as Nifty rose: a healthy, confident rally and cheaper premiums." : "VIX fell despite the dip, so the selling isn't causing panic.")
        : "VIX barely moved, so options aren't pricing in anything unusual. ");
    x += ` The expected move for the next session is about ±${pts(em)} points (${lvl(c - em)} to ${lvl(c + em)}), roughly a 68% probability range.`;
    if (ex && tdays > 0) { emx = em * Math.sqrt(tdays); x += ` Until the ${shortDay(ex.date)} expiry (${tdays} trading ${tdays === 1 ? "day" : "days"}), the expected move is about ±${pts(emx)} points (${lvl(c - emx)} to ${lvl(c + emx)}).`; }
    vItems.push({ tag: tg[0], tone: tg[1], t: "India VIX and expected move", x });
    S(vix.pct >= 5 ? -0.5 : vix.pct <= -5 && chg >= 0 ? 0.5 : 0, vix.pct >= 5 ? "India VIX rising" : "India VIX falling");
  }
  {
    const rv10 = nfRV(cl, 10), rv20 = nfRV(cl, 20), ivNow = chain && chain.iv ? chain.iv : vix ? vix.last : null;
    if (rv20 && ivNow) {
      const ratio = ivNow / rv20, vd = br && br.vixDaily;
      let x = `Nifty has actually been moving at ${nfNum(rv10, 1)}% (10-day) and ${nfNum(rv20, 1)}% (20-day) annualized. Options are pricing ${nfNum(ivNow, 1)}% (${chain && chain.iv ? "ATM IV" : "India VIX"}), ${nfNum(ratio, 2)}x the 20-day realized volatility. ` +
        (ratio >= 1.25 ? "Premiums are rich: option sellers have the statistical edge, and buyers need a large move quickly to profit." : ratio <= 0.9 ? "Premiums are cheap compared with actual movement: option buying is relatively good value, and sellers are underpaid for the risk." : "Premiums are fairly priced, with no strong edge for buyers or sellers.");
      if (vd && vd.length > 100 && vix) { const pr = vd.filter(z => z[1] < vix.last).length / vd.length * 100; x += ` India VIX at ${nfNum(vix.last, 1)} is in the ${Math.round(pr)}th percentile of the past year (${pr <= 25 ? "low; complacency, and volatility tends to rise from here" : pr >= 75 ? "high; fear is elevated, and volatility tends to fall back" : "mid-range"}).`; }
      vItems.push({ tag: ratio >= 1.25 ? "Premiums rich" : ratio <= 0.9 ? "Premiums cheap" : "Fairly priced", tone: ratio >= 1.25 ? "warn" : ratio <= 0.9 ? "up" : "flat", t: "Implied vs actual volatility", x });
    }
  }
  if (vItems.length) groups.push({ h: "Momentum and volatility", items: vItems });

  /* ===== 5. Options positioning ===== */
  const oiQ = X.oi && !X.oi.error && X.oi.pcr != null ? X.oi : null, oItems = [];
  const oi = chain ? { pcr: chain.pcr != null ? chain.pcr : oiQ && oiQ.pcr, expiry: chain.expiry, maxCall: chain.callWall, maxPut: chain.putWall, maxPain: oiQ && oiQ.maxPain } : oiQ;
  if (oi && oi.pcr != null) {
    const mc = (oi.maxCall || [])[0], mp = (oi.maxPut || [])[0], pcr = Number(oi.pcr);
    const tg = pcr > 1.2 ? ["Put-heavy", "up"] : pcr < 0.8 ? ["Call-heavy", "down"] : ["Balanced", "flat"];
    let x = `PCR is ${oi.pcr}${oi.expiry ? ` for the ${oi.expiry} expiry` : ""}. ` + (pcr > 1.2 ? "More puts than calls are written: writers expect support to hold. Very high readings can also mean the market is crowded on one side."
      : pcr < 0.8 ? "More calls than puts are written: writers expect a cap overhead." : "Positioning is balanced.");
    if (mc && mp) x += ` The call wall (Max Call OI) is at ${lvl(mc.strike)} and the put wall (Max Put OI) is at ${lvl(mp.strike)}, so option writers are defending a ${lvl(mp.strike)}–${lvl(mc.strike)} band.`;
    if (oi.maxPain) { const gp = Math.abs(oi.maxPain - c); x += ` Max Pain is ${lvl(oi.maxPain)}, ${gp < atr * 0.5 ? "close to the current price" : `${pts(oi.maxPain - c)} points ${oi.maxPain > c ? "above" : "below"} the close`}` + (gp > atr * 2 ? "; too far away to act as a magnet this expiry." : "; price often drifts toward it near expiry, especially in quiet weeks."); }
    if (mc && mc.strike < c) x += ` Nifty closed above the biggest call wall: call writers there are under pressure, and their covering can add fuel to the upside.`;
    else if (mp && mp.strike > c) x += ` Nifty closed below the biggest put wall: put writers there are under pressure, and their exits can add to the downside.`;
    else if (em && mc && c + em >= mc.strike) x += ` The VIX-implied upper range (${lvl(c + em)}) reaches the call wall, so a test of ${lvl(mc.strike)} is within normal odds.`;
    else if (em && mp && c - em <= mp.strike) x += ` The VIX-implied lower range (${lvl(c - em)}) reaches the put wall, so a test of ${lvl(mp.strike)} is within normal odds.`;
    S(pcr > 1.2 && pcr < 1.6 ? 0.5 : pcr < 0.8 ? -0.5 : 0, `PCR at ${pcr}`);
    oItems.push({ tag: tg[0], tone: tg[1], t: "Option chain read", x });
  }
  if (chain) {
    const sd = chain.straddle;
    let x = `The ${lvl(chain.atm)} straddle (ATM call ${nfNum(chain.ce, 1)} + put ${nfNum(chain.pe, 1)}) costs ${nfNum(sd, 1)} for the ${chain.expiry} expiry. Options are pricing a move of about ±${pts(sd)} points by expiry, with breakevens at ${lvl(chain.atm - sd)} and ${lvl(chain.atm + sd)}.`;
    if (emx) x += ` The VIX-based estimate for the same period is ±${pts(emx)}, so ${sd > emx * 1.15 ? "the straddle is pricing extra movement, often an event premium ahead of news" : sd < emx * 0.85 ? "the straddle is cheaper than VIX suggests" : "the two agree"}.`;
    x += " Sellers profit if Nifty stays inside the breakevens by expiry; buyers need a move beyond them.";
    oItems.push({ tag: "±" + pts(sd), tone: "flat", t: "Straddle: the move options are pricing", x });
    const ca = chain.callAdd[0], pa = chain.putAdd[0], cc = chain.callCut[0], pc2 = chain.putCut[0];
    let y = `Open interest added today: calls ${nfLakh(chain.callChg)} contracts, puts ${nfLakh(chain.putChg)}. `;
    if (ca && ca.v > 0) y += `The heaviest call writing was at ${lvl(ca.strike)} (${nfLakh(ca.v)})${ca.strike <= c ? ", at or below the current price, an aggressive sign that writers expect a pullback" : ""}. `;
    if (pa && pa.v > 0) y += `The heaviest put writing was at ${lvl(pa.strike)} (${nfLakh(pa.v)})${pa.strike >= c ? ", at or above the current price, an aggressive sign that writers expect support to hold" : ""}. `;
    const sh = chain.putChg > Math.max(chain.callChg, 0) * 1.3 && chain.putChg > 0 ? 1 : chain.callChg > Math.max(chain.putChg, 0) * 1.3 && chain.callChg > 0 ? -1 : 0;
    y += sh > 0 ? "Put writers are adding faster than call writers: support is being built under price. " : sh < 0 ? "Call writers are adding faster than put writers: supply is being stacked overhead. " : "Both sides are adding at a similar pace: writers are defending a range. ";
    if (cc && cc.v < 0) y += `Biggest call unwinding: ${lvl(cc.strike)} (${nfLakh(cc.v)})${cc.strike > c ? ", so resistance there is weakening" : ""}. `;
    if (pc2 && pc2.v < 0) y += `Biggest put unwinding: ${lvl(pc2.strike)} (${nfLakh(pc2.v)})${pc2.strike < c ? ", so support there is weakening" : ""}.`;
    S(sh * 0.5, sh > 0 ? "put writers adding faster than call writers" : "call writers adding faster than put writers");
    oItems.push({ tag: sh > 0 ? "Support building" : sh < 0 ? "Supply building" : "Range defended", tone: sh > 0 ? "up" : sh < 0 ? "down" : "flat", t: "OI shift today", x: y.trim() });
  }
  if (oItems.length) groups.push({ h: "Options positioning", items: oItems, note: chain ? "OI changes are since the previous session's close." : "" });

  /* ===== 6. Before the next session ===== */
  const nItems = [], pv = (h + l + c) / 3, r1 = 2 * pv - l, s1 = 2 * pv - h;
  const lvlRaw = [[h, "today's high"], [l, "today's low"], [r1, "R1"], [s1, "S1"], [cprN.tc, "CPR top"], [cprN.bc, "CPR bottom"]];
  ma.list.filter(m => Math.abs(m.v - c) <= 1.5 * atr).forEach(m => lvlRaw.push([m.v, m.k]));
  if (oi && (oi.maxCall || [])[0]) lvlRaw.push([oi.maxCall[0].strike, "call wall"]);
  if (oi && (oi.maxPut || [])[0]) lvlRaw.push([oi.maxPut[0].strike, "put wall"]);
  if (wp) { lvlRaw.push([wp.p, "weekly pivot"]); }
  if (mp && Math.abs(mp.p - c) <= 2 * atr) lvlRaw.push([mp.p, "monthly pivot"]);
  if (chain) { lvlRaw.push([chain.atm + chain.straddle, "straddle breakeven"]); lvlRaw.push([chain.atm - chain.straddle, "straddle breakeven"]); }
  const merge = (up) => { const tol = Math.max(atr * 0.08, 6), o2 = [];
    lvlRaw.filter(z => up ? z[0] > c + 1 : z[0] < c - 1).sort((p1, p2) => up ? p1[0] - p2[0] : p2[0] - p1[0]).forEach(z => {
      const last = o2[o2.length - 1];
      if (last && Math.abs(z[0] - last.vs[last.vs.length - 1]) <= tol) { last.vs.push(z[0]); if (!last.labels.includes(z[1])) last.labels.push(z[1]); }
      else o2.push({ vs: [z[0]], labels: [z[1]] }); });
    return o2; };
  const fmtL = (g) => { const lo = Math.min(...g.vs), hi = Math.max(...g.vs); return (hi - lo >= 1 ? `${lvl(lo)}–${lvl(hi)}` : lvl(lo)) + ` (${g.labels.join(" + ")}${g.labels.length >= 3 ? ", a strong zone" : ""})`; };
  const U = merge(true).slice(0, 3), D = merge(false).slice(0, 3);
  // GIFT Nifty: where the next session may open
  const g = X.gift;
  if (!live && g && g.price) {
    const io = fu && fu.last ? c + (g.price - fu.last) : c * (1 + (g.pct || 0) / 100), gp = io - c, gpp = gp / c * 100;
    const where = io > h ? "above today's high" : io < l ? "below today's low" : io > cprN.tc ? "above the CPR" : io < cprN.bc ? "below the CPR" : "inside the CPR";
    const x = `GIFT Nifty is at ${nfNum(g.price)} (${sp(g.pct || 0)}%)${g.updated ? ` as of ${g.updated}` : ""}. ${fu && fu.last ? `Compared with where Nifty futures closed (${lvl(fu.last)}), that` : "That"} points to an open near ${lvl(io)} (${gp >= 0 ? "+" : "−"}${pts(gp)} points), ${where}. ` +
      (Math.abs(gpp) < 0.2 ? "A flat start: today's levels stay in play from the open." : Math.abs(gpp) >= 0.6 ? `A large gap ${gp > 0 ? "up" : "down"}. Big gaps often see an early test back toward ${lvl(c)}; wait for the first 15 minutes before acting.` : `A modest gap ${gp > 0 ? "up" : "down"}.`) +
      " GIFT moves overnight with global cues, so recheck it at 9:00 AM.";
    S(gpp >= 0.3 ? 0.5 : gpp <= -0.3 ? -0.5 : 0, `GIFT Nifty indicates a ${gp >= 0 ? "higher" : "lower"} open`);
    nItems.push({ tag: Math.abs(gpp) < 0.2 ? "Flat open" : gp > 0 ? "Gap up" : "Gap down", tone: Math.abs(gpp) < 0.2 ? "flat" : gp > 0 ? "up" : "down", t: "GIFT Nifty and the likely open", x });
  }
  {
    let x = "";
    if (U.length) x += `Bulls need to clear ${U.map(fmtL).join(", then ")}. `;
    if (D.length) x += `Bears need to break ${D.map(fmtL).join(", then ")}. `;
    const ex = (typeof upcomingExpiries === "function" ? upcomingExpiries(20) : [])[0];
    if (ex) { const dd = Math.round((addDays(ex.date, 0) - addDays(istNow(), 0)) / 86400000); x += `Next expiry: ${ex.label}, ${shortDay(ex.date)}${dd <= 1 ? ". Theta decay is at its fastest, so ATM premiums melt quickly and sharp swings near big OI strikes are common." : `, in ${dd} days.`} `; }
    const evs = (typeof upcomingEvents === "function" ? upcomingEvents(6) : []).filter(([ds]) => (new Date(ds + "T00:00:00") - addDays(istNow(), 0)) / 86400000 <= 3);
    if (evs.length) x += `Coming up: ${evs.map(([ds, , lb]) => `${lb} (${shortDay(new Date(ds + "T00:00:00"))})`).join("; ")}. Event days can bring gaps, so size down beforehand.`;
    if (x) nItems.push({ tag: "Plan", tone: "warn", t: "Checklist for the next session", x: x.trim() });
  }
  if (nItems.length) groups.push({ h: "Before the next session", items: nItems });

  /* ===== Bottom line: everything above, weighed together ===== */
  let bottom = null;
  if (sig.length >= 4) {
    const tot = sig.reduce((a2, z) => a2 + z.w, 0), sgn = Math.sign(tot);
    const lean = tot >= 3 ? ["Bullish", "strong", "up"] : tot >= 1.5 ? ["Bullish", "moderate", "up"] : tot >= 0.6 ? ["Leaning bullish", "mild", "up"]
      : tot <= -3 ? ["Bearish", "strong", "down"] : tot <= -1.5 ? ["Bearish", "moderate", "down"] : tot <= -0.6 ? ["Leaning bearish", "mild", "down"] : ["Mixed", "no clear edge", "flat"];
    const by = (z1, z2) => Math.abs(z2.w) - Math.abs(z1.w);
    const pro = sgn ? sig.filter(z => Math.sign(z.w) === sgn).sort(by).slice(0, 3) : sig.filter(z => z.w > 0).sort(by).slice(0, 2);
    const con = sgn ? sig.filter(z => Math.sign(z.w) === -sgn).sort(by).slice(0, 2) : sig.filter(z => z.w < 0).sort(by).slice(0, 2);
    const trig = lean[2] === "up" ? (D[0] ? `A close below ${fmtL(D[0])} would weaken this view.` : "") : lean[2] === "down" ? (U[0] ? `A close above ${fmtL(U[0])} would weaken this view.` : "") : `A close above ${lvl(h)} or below ${lvl(l)} would give direction.`;
    bottom = { lean, score: tot, n: sig.length, pro, con, trig };
  }

  return {
    live, groups, bottom, items: groups.flatMap(g2 => g2.items), chg, pct, close: c, range: rng, atr, clv,
    levels: [["Pivot", pv], ["R1", r1], ["S1", s1], ["CPR top", cprN.tc], ["CPR bottom", cprN.bc], ["Weekly pivot", wp ? wp.p : null], ["Day high", h], ["Day low", l], ["Close", c]].filter(z => z[1] != null)
  };
}

function bottomHtml(b) {
  const li = (a) => a.map(z => esc(z.txt)).join("; ");
  return `<div class="rd-bottom lean-${b.lean[2]}"><div class="rdb-top"><span class="rdb-k">${t("Bottom line")}</span><span class="rd-chip ${b.lean[2]}">${esc(b.lean[0])}${b.lean[1] !== "no clear edge" && b.lean[0].indexOf("Leaning") < 0 ? " · " + esc(b.lean[1]) : ""}</span></div>
    <p class="rdb-l">${b.lean[2] === "flat" ? "The signals are mixed, with no clear edge either way." : `The data leans ${b.lean[2] === "up" ? "bullish" : "bearish"}${b.lean[1] === "mild" ? ", but only mildly" : ""}.`}</p>
    ${b.pro.length ? `<p class="rdb-r"><b>${b.lean[2] === "flat" ? "Bullish side" : "For"}:</b> ${li(b.pro)}.</p>` : ""}
    ${b.con.length ? `<p class="rdb-r"><b>${b.lean[2] === "flat" ? "Bearish side" : "Against"}:</b> ${li(b.con)}.</p>` : ""}
    ${b.trig ? `<p class="rdb-r"><b>${t("What would change it")}:</b> ${esc(b.trig)}</p>` : ""}
    <p class="rdb-n">${b.n ? `Weighed from ${b.n} signals. ` : ""}A reading of the data for learning, not a buy or sell call.</p></div>`;
}

function nfDrawRead() {
  const box = $("#nfRead"); if (!box || !nfData) return;
  const pro = typeof isPro !== "function" || isPro();
  const X = pro ? { ...nfExt, intra: nfIntra || (nfExt.br && nfExt.br.intra), bank: nfData.bank, gift: typeof mbData !== "undefined" && mbData ? mbData.gift : null } : {};
  const r = niftyRead(nfData.daily, nfMarketLive(), X);
  if (!r) { box.hidden = true; return; }
  box.hidden = false;
  const wasOpen = !!box.querySelector("details.fold[open]");
  const openMore = new Set([...box.querySelectorAll("details.ma-more[open]")].map((_, i) => i));
  const seen = new Set();
  let k = 0;
  const point = (i) => `<li class="nf-point"><div class="rd-head"><span class="rd-n">${++k}</span><strong>${esc(i.t)}</strong>${i.tag ? `<span class="rd-chip ${i.tone || "flat"}">${esc(i.tag)}</span>` : ""}</div><p>${markTerms(i.x, seen)}</p>${i.html || ""}</li>`;
  const shown = pro ? r.groups : r.groups.filter(g => g.free);
  const body = shown.map(g => `<p class="rd-lbl">${t(g.h)}</p><ol class="nf-points">${g.items.map(point).join("")}</ol>${g.note ? `<p class="muted small" style="margin:6px 0 0">${esc(g.note)}</p>` : ""}`).join("");
  const loading = pro && !nfExt.br && nfExt.busy ? `<p class="muted small" style="margin:12px 0 0">Loading breadth, sectors and moving averages…</p>` : "";
  const teaser = !pro && typeof Lock !== "undefined" ? Lock.wrap(`<p class="rd-lbl">Breadth and sectors</p><p>In the Nifty 50, 34 stocks rose and 16 fell. 9 of 14 sectors closed green. Strongest: IT and Auto. Weakest: Metal and Realty.</p>
      <p class="rd-lbl">Moving averages</p><p>Nearest overhead: EMA 20 at 22,640. Confluence zone 22,950–23,010.</p><p class="rd-lbl">India VIX and options</p><p>Expected move ±185 points. Call wall 22,800, put wall 22,300.</p>`,
      "Full market analysis", { title: "Subscribe to read the full analysis", sub: "Breadth, sector rotation, moving averages, VIX range and OI walls" }) : "";
  box.innerHTML = `
    <h3 class="nf-read-h">${t("What an advanced trader reads from today")}</h3>
    <p class="muted small" style="margin:2px 0 10px">${r.live ? `<span class="nf-live"><span class="sess-dot"></span>Live</span> Updating through the session · last refresh ${new Date().toLocaleTimeString("en-IN", { timeZone: "Asia/Kolkata", hour: "numeric", minute: "2-digit" })}. The final read is saved after 3:35 PM.` : `${t("Based on today's final candle.")}${pro ? ` <button type="button" class="linkbtn" data-sec="archive">Past days →</button>` : ""}`}</p>
    ${pro && r.bottom ? bottomHtml(r.bottom) : !pro && typeof Lock !== "undefined" ? Lock.wrap(bottomHtml({ lean: ["Leaning bullish", "mild", "up"], pro: [{ txt: "buyers controlled the close" }, { txt: "a higher CPR" }], con: [{ txt: "FIIs short in index futures" }], trig: "A close below 22,350 would weaken this view." }), "The bottom line", { short: true, title: "Subscribe to see the bottom line", sub: "Every signal weighed into one clear read" }) : ""}
    <div class="rd-sum">${shown.flatMap(g => g.items).filter(i => i.tag && i.tag !== "Why" && i.tag !== "Plan").slice(0, 10).map(i => `<span class="rd-chip ${i.tone || "flat"}">${esc(i.tag)}</span>`).join("")}</div>
    <details class="fold"${wasOpen ? " open" : ""}><summary><span>${t("Read full analysis")}</span></summary>
      <p class="muted small" style="margin:10px 0 0">${t("Tap underlined words for their meaning.")}</p>
      ${body}${loading}${teaser}
      <p class="rd-lbl">${t("Levels for the next session")}</p>
      <div class="nf-levels">${r.levels.map(([kk, v]) => `<div><span>${kk}</span><strong>${nfNum(v, 0)}</strong></div>`).join("")}</div>
      <p class="muted small" style="margin:8px 0 0"><button type="button" class="kt" data-tip="(High + Low + Close) ÷ 3, the day's balance point">Pivot</button> · <button type="button" class="kt" data-tip="first resistance above the pivot">R1</button> · <button type="button" class="kt" data-tip="first support below the pivot">S1</button></p>
      <p class="muted small" style="margin:10px 0 0">${t("Calculated automatically from price data. For education only, not a trade call.")}${pro && nfExt.br && nfExt.br.source ? ` Breadth and sectors: ${nfExt.br.source === "NSE" ? "NSE" : "Yahoo Finance (approx.)"}.` : ""}</p>
    </details>`;
  $$("details.ma-more", box).forEach((el, i) => { if (openMore.has(i)) el.open = true; });
  $$("[data-sec]", box).forEach(b => b.onclick = () => go(b.dataset.sec));
  if (!nfExt.firstAt) nfExt.firstAt = Date.now();
  if (pro && !r.live && typeof nfMaybeSave === "function") nfMaybeSave(r);
}

// Load the extra data (subscribers only), refreshed every 2 min while the market is open, else every 15 min.
async function nfLoadExt() {
  if (nfExt.busy || (typeof isPro === "function" && !isPro())) return;
  const now = Date.now(), ttl = nfMarketLive() ? 120000 : 900000, jobs = [];
  if (now - nfExt.brAt > ttl) jobs.push(mbFn({}).then(r => { if (r.data && !r.data.error) { nfExt.br = r.data; nfExt.brAt = Date.now(); } }).catch(() => {}));
  if (now - nfExt.oiAt > ttl) jobs.push(sb.functions.invoke("quick-task", { body: { oi: true } }).then(r => { if (r.data && !r.data.error) { nfExt.oi = r.data; nfExt.oiAt = Date.now(); } }).catch(() => {}));
  if (now - nfExt.newsAt > 600000) {
    if (typeof newsCache !== "undefined" && newsCache && now - newsCache.at < 600000) { nfExt.news = newsCache.items; nfExt.newsAt = newsCache.at; }
    else jobs.push(sb.functions.invoke("Market-news-").then(r => { if (r.data && Array.isArray(r.data.items)) { nfExt.news = r.data.items; nfExt.newsAt = Date.now(); } }).catch(() => {}));
  }
  if (!jobs.length) return;
  nfExt.busy = true;
  try { await Promise.all(jobs); } finally { nfExt.busy = false; }
  if ($("#nfRead")) nfDrawRead();
}

async function nfRefresh(first) {
  try {
    const data = await nfFetch(nfRange);
    if (!$("#nfCard")) return;
    nfData = data;
    if (nfRange === "1d" && Array.isArray(data.candles) && data.candles.length) nfIntra = data.candles;
    if (mbNiftyPrev && nfData.nifty) nfData.nifty.prevClose = mbNiftyPrev; // official NSE previous close wins
    nfDrawQuote();
    if (typeof drawNow === "function" && document.getElementById("nowBox")) drawNow(); nfDrawChart(); nfDrawRead();
    nfLoadExt();
  } catch (e) {
    if (first && $("#nfPrice")) {
      $("#nfPrice").textContent = "Unavailable";
      $("#nfSub").innerHTML = `<span class="muted small">Live prices couldn't load. Pull down to refresh, or try again in a minute.</span>`;
    }
  }
}

async function mountNifty() {
  clearInterval(nfTimer); nfChart = null; nfSeries = null;
  const card = $("#nfCard"); if (!card) return;
  $$("[data-nfr]", card).forEach(b => b.onclick = () => {
    nfRange = b.dataset.nfr;
    $$("[data-nfr]", card).forEach(x => x.setAttribute("aria-checked", x.dataset.nfr === nfRange));
    nfRefresh();
  });
  $("#nfType").onclick = () => { nfType = nfType === "candle" ? "line" : "candle"; $("#nfType").textContent = nfType === "candle" ? "Line" : "Candles"; nfDrawChart(); };
  try { await loadLWC(); } catch (e) { $("#nfChart").innerHTML = `<p class="muted small">Chart couldn't load on this connection.</p>`; }
  await nfRefresh(true);
  nfTimer = setInterval(() => {
    if (!$("#nfCard")) { clearInterval(nfTimer); return; }
    if (document.hidden) return;
    if (nfMarketLive() || Date.now() / 1000 - (nfData?.fetchedAt || 0) > 300) nfRefresh();
  }, 20000);
}

/* ---------- Weekly "10% better" countdown (same for every student) ---------- */
// Each cycle runs Sunday 9:00 PM IST to the next Sunday 9:00 PM IST, then restarts.
const GROW_ANCHOR = Date.UTC(2026, 0, 4, 15, 30); // Sun 4 Jan 2026, 21:00 IST
const GROW_WEEK = 7 * 86400000;
let growTimer = null;
function growState() {
  const now = Date.now(), k = Math.floor((now - GROW_ANCHOR) / GROW_WEEK);
  const end = GROW_ANCHOR + (k + 1) * GROW_WEEK, left = Math.max(0, Math.floor((end - now) / 1000));
  return { week: k + 1, d: Math.floor(left / 86400), h: Math.floor(left % 86400 / 3600), m: Math.floor(left % 3600 / 60),
    s: left % 60, pct: Math.min(100, (now - (end - GROW_WEEK)) / GROW_WEEK * 100) };
}
function growInner() {
  const g = growState(), p = (v) => String(v).padStart(2, "0");
  return `<div class="grow-row">
      <span class="grow-time">${g.d}${t("d")} ${p(g.h)}${t("h")} ${p(g.m)}${t("m")} ${p(g.s)}${t("s")}</span>
      <span class="grow-left">${t("left this week")}</span>
    </div>
    <div class="grow-bar" role="progressbar" aria-label="This week" aria-valuenow="${Math.round(g.pct)}" aria-valuemin="0" aria-valuemax="100"><i style="width:${g.pct}%"></i></div>`;
}
const GROW_STEPS = [
  ["Learn one new concept", "A class, a quiz, or the Library"],
  ["Fix one repeated mistake", "Pick it from your journal"],
  ["Follow your rules on every trade", "Size, stop-loss, no revenge trades"]
];
const growKey = () => "m_goal_" + (typeof growCycleStart === "function" ? growCycleStart().toISOString().slice(0, 13) : growState().week);
function growSteps() { try { return JSON.parse(localStorage.getItem(growKey()) || "[]"); } catch (e) { return []; } }
let growOpen = false;
function growStepsHtml() {
  const done = growSteps(), n = GROW_STEPS.filter((_, i) => done[i]).length;
  if (!growOpen) return n === 3
    ? `<button type="button" class="grow-alldone" id="growExpand">${typeof ICO !== "undefined" ? ICO.check : "✓"} <span>${t("All 3 steps done this week")}</span><span class="muted small">${t("Edit")}</span></button>`
    : `<button type="button" class="grow-mini" id="growExpand" aria-expanded="false"><span>${t("This week's 3 steps")}</span><b>${n}/3</b><span class="grow-dots">${[0, 1, 2].map(i => `<i class="${done[i] ? "on" : ""}"></i>`).join("")}</span><span class="muted small">${t("Show")}</span></button>`;
  return `<div class="grow-steps-head"><span class="grow-tag" style="margin:0">${t("This week's 3 steps")}</span><span><span class="grow-score">${n}/3</span> <button type="button" class="grow-hide" id="growHide">${t("Hide")}</button></span></div>
    <ol class="grow-steps">${GROW_STEPS.map(([a, b], i) => `<li><label class="grow-step${done[i] ? " done" : ""}">
      <input type="checkbox" data-gstep="${i}" ${done[i] ? "checked" : ""}>
      <span class="grow-num">${i + 1}</span><span class="grow-txt"><strong>${t(a)}</strong><span>${t(b)}</span></span></label></li>`).join("")}</ol>`;
}
function bindGrowSteps() {
  const hd = document.getElementById("growHide");
  if (hd) hd.onclick = () => { growOpen = false; const box = $("#growSteps"); if (box) { box.innerHTML = growStepsHtml(); bindGrowSteps(); } };
  const ex = document.getElementById("growExpand");
  if (ex) ex.onclick = () => { growOpen = true; const box = $("#growSteps"); if (box) { box.innerHTML = growStepsHtml(); bindGrowSteps(); } };
  $$("[data-gstep]").forEach(cb => cb.onchange = () => {
    const d = growSteps(); d[+cb.dataset.gstep] = cb.checked;
    try { localStorage.setItem(growKey(), JSON.stringify(d)); } catch (e) {}
    if (typeof saveGrowSteps === "function") saveGrowSteps(d);
    if ([0, 1, 2].every(i => d[i])) { growOpen = false; toast(t("All 3 steps done. That's a 10% better week.")); }
    const box = $("#growSteps"); if (box) { box.innerHTML = growStepsHtml(); bindGrowSteps(); }
  });
}
function growCardHtml() {
  const g = growState();
  return `<section class="grow" aria-label="Weekly goal">
    <div class="grow-top"><p class="grow-tag">${t("Weekly goal")} · ${t("Week")} ${g.week}</p><span class="grow-reset">${t("Resets Sun 9 PM")}</span></div>
    <p class="grow-title">${t("Be 10% better than last week")}</p>
    <div id="growBox">${growInner()}</div>
    <div id="growSteps">${growStepsHtml()}</div>
    <div id="growReflect"></div>
  </section>`;
}
function mountGrow() {
  clearInterval(growTimer); bindGrowSteps();
  growTimer = setInterval(() => {
    const b = document.getElementById("growBox");
    if (!b) { clearInterval(growTimer); return; }
    b.innerHTML = growInner();
  }, 1000);
}


// =============================================================
// Market board: sector indices + top Nifty contributors (minimal)
// Data: Supabase function "quick-task" with {board:true}. NSE official first, Yahoo fallback.
// =============================================================
let mbTimer = null, mbData = null, mbNiftyPrev = null;
function marketBoardHtml() {
  return `<section class="card mb" id="mbCard" aria-label="Indices and top movers">
    <div class="mb-head"><h3 class="mb-title">${t("Indices")}</h3><span class="muted small" id="mbWhen"></span></div>
    <div id="mbBody"><p class="muted small" style="margin:0">Loading…</p></div>
  </section>`;
}
function mbRow(name, price, chg, pct) {
  const up = chg >= 0, cls = up ? "up" : "down";
  return `<div class="mb-row"><span class="mb-name">${esc(name)}</span><span class="mb-num">${nfNum(price)}</span>
    <span class="mb-num ${cls}">${up ? "▲" : "▼"} ${up ? "+" : ""}${nfNum(pct)}%</span></div>`;
}
function mbDraw() {
  const d = mbData, body = $("#mbBody"); if (!body) return;
  if (!d || !(d.indices || []).length) { body.innerHTML = `<p class="muted small" style="margin:0">Index data couldn't load. Try again in a minute.</p>`; return; }
  const idx = d.indices.filter(i => i.key !== "NIFTY 50" && i.price && i.prevClose);
  const mv = (d.movers || []).map(m => `<div class="mb-row"><span class="mb-name">${esc(m.symbol)}</span>
      <span class="mb-num ${m.pct >= 0 ? "up" : "down"}">${m.pct >= 0 ? "+" : ""}${nfNum(m.pct)}%</span>
      <span class="mb-num ${m.points >= 0 ? "up" : "down"}">${m.points >= 0 ? "+" : ""}${nfNum(m.points, 1)} pts</span></div>`).join("");
  const wasOpen = !!body.querySelector("details.fold[open]");
  const rowArr = idx.map(i => { const c = i.price - i.prevClose; return mbRow(i.label, i.price, c, c / i.prevClose * 100); });
  body.innerHTML = `<div class="mb-list">${rowArr.slice(0, 3).join("")}</div>
    <details class="fold"${wasOpen ? " open" : ""}><summary><span>${t("All indices & top contributors")}</span></summary>
      ${rowArr.length > 3 ? `<div class="mb-list">${rowArr.slice(3).join("")}</div>` : ""}
      ${mv ? `<h4 class="mb-sub">${t("Top 5 Nifty contributors")}${d.approx ? " <span class=\"muted small\">(approx.)</span>" : ""}</h4><div class="mb-list">${mv}</div>` : ""}
      <p class="muted small" style="margin:10px 0 0">${t("Points = how much each stock added to or took from Nifty today.")} Source: ${d.source === "NSE" ? "NSE" : "Yahoo Finance (approx.)"}.</p>
    </details>`;
  const w = $("#mbWhen"); if (w && d.fetchedAt) w.textContent = new Date(d.fetchedAt * 1000).toLocaleTimeString("en-IN", { timeZone: "Asia/Kolkata", hour: "numeric", minute: "2-digit" });
}
async function mbRefresh() {
  try {
    const { data, error } = await sb.functions.invoke("quick-task", { body: { board: true } });
    if (error || !data || data.error) throw error || new Error("no data");
    mbData = data;
    if (data.niftyPrev && data.source === "NSE") {
      mbNiftyPrev = data.niftyPrev;
      if (nfData && nfData.nifty && nfData.nifty.prevClose !== mbNiftyPrev) { nfData.nifty.prevClose = mbNiftyPrev; if ($("#nfCard")) { nfDrawQuote(); nfDrawChart(); } }
    }
  } catch (e) { /* keep last data */ }
  mbDraw();
  const tk = $("#tickStrip");
  if (tk) { tk.innerHTML = tickerHtml(mbData); tk.onclick = () => tk.classList.toggle("paused"); }
  const ms = $("#mktStrip"); if (ms) ms.innerHTML = mktStatusHtml();
}
async function mountMarketBoard() {
  clearInterval(mbTimer);
  if (!$("#mbCard")) return;
  if (mbData) mbDraw();
  await mbRefresh();
  mbTimer = setInterval(() => {
    if (!$("#mbCard")) { clearInterval(mbTimer); return; }
    if (document.hidden) return;
    if (nfMarketLive() || giftSessionLive() || Date.now() / 1000 - (mbData?.fetchedAt || 0) > 600) mbRefresh();
  }, 60000);
}


// ---- Terminal-style market status line + index ticker (Home) ----
function giftSessionLive() {
  const now = istNow(), m = now.getHours() * 60 + now.getMinutes(), d = now.getDay();
  // NSE IX sessions: 06:30–15:40 and 16:35–02:45 (next day), Mon–Fri
  const s1 = d >= 1 && d <= 5 && m >= 390 && m < 940, s2 = d >= 1 && d <= 5 && m >= 995, s3 = d >= 2 && d <= 6 && m < 165;
  return s1 || s2 || s3;
}
function mktStatusHtml() {
  const now = istNow(), m = now.getHours() * 60 + now.getMinutes(), td = isTradingDay(now);
  const time = now.toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit" });
  let st, cls;
  if (td && m >= 555 && m < 930) { st = "NSE OPEN"; cls = "open"; }
  else if (td && m >= 540 && m < 555) { st = "PRE-OPEN"; cls = "pre"; }
  else { st = "NSE CLOSED"; cls = "closed"; }
  const right = `<span class="mkt-st ${cls}"><i></i>${st} · ${time}</span>`;
  const g = (typeof mbData !== "undefined" && mbData) ? mbData.gift : null;
  if (!g || g.price == null) return `<span class="mkt-st ${cls}"><i></i>${st === "NSE OPEN" ? "MARKET OPEN" : st === "PRE-OPEN" ? "PRE-OPEN" : "MARKET CLOSED"}</span><span>${time} IST</span>`;
  const up = g.chg >= 0, mood = g.pct >= 0.25 ? ["POSITIVE", "up"] : g.pct <= -0.25 ? ["NEGATIVE", "down"] : ["FLAT", "flat"];
  return `<span class="gift"><span class="gift-n">GIFT NIFTY${giftSessionLive() ? ' <i class="live-dot" title="Trading now"></i>' : ""}</span>
    <span class="gift-v">${nfNum(g.price)} <b class="${up ? "up" : "down"}">${up ? "▲ +" : "▼ "}${nfNum(g.pct)}%</b></span>
    <span class="gift-m ${mood[1]}">${mood[0]}</span>${g.src === "kotakneo" && g.updated ? `<span class="gift-asof">as of ${esc(g.updated)}</span>` : ""}</span>${right}`;
}
function tickerHtml(d) {
  const rows = (d?.indices || []).filter(i => i.price && i.prevClose);
  if (!rows.length) return "";
  const items = rows.map(i => { const c = i.price - i.prevClose, p = c / i.prevClose * 100, up = c >= 0;
    return `<div class="tk"><span class="tk-n">${esc(i.label.toUpperCase())}</span><span class="tk-v">${nfNum(i.price)} <b class="${up ? "up" : "down"}">${up ? "▲" : "▼"} ${up ? "+" : ""}${nfNum(p)}%</b></span></div>`; }).join("");
  // two copies side by side → seamless loop
  return `<div class="tk-track" style="--tk-dur:${Math.max(24, rows.length * 6)}s"><div class="tk-set">${items}</div><div class="tk-set" aria-hidden="true">${items}</div></div>`;
}
setInterval(() => { const s = document.getElementById("mktStrip"); if (s) s.innerHTML = mktStatusHtml(); }, 30000);


// =============================================================
// Global troika: US 10-year yield, USD/INR, Brent crude
// The three outside numbers that move FII flows into India. Public (free) data.
// =============================================================
let gtData = null, gtTimer = null;
const GT = {
  us10y: { name: "US 10Y yield", short: "US 10Y", fmt: v => nfNum(v, 2) + "%", chg: d => `${d.chg >= 0 ? "+" : "−"}${nfNum(Math.abs(d.chg) * 100, 1)} bps`, th: 0.03, // 3 bps
    why: "When US bond yields rise, safe US bonds pay more, so foreign investors (FIIs) pull money out of riskier emerging markets like India. Falling yields do the opposite and usually bring FII money back.",
    rule: "Rising yields are a headwind for Nifty, especially banks and IT valuations. Above about 4.5% the pressure gets serious." },
  usdinr: { name: "USD / INR", short: "USD/INR", fmt: v => "₹" + nfNum(v, 2), chg: d => `${d.chg >= 0 ? "+" : "−"}${nfNum(Math.abs(d.chg), 2)} (${d.pct >= 0 ? "+" : "−"}${nfNum(Math.abs(d.pct), 2)}%)`, th: 0.15,
    why: "This is how many rupees one dollar buys. When it rises, the rupee is weakening: FIIs lose money on currency, so they tend to sell, and imports like crude get costlier. IT and pharma exporters gain from a weaker rupee.",
    rule: "A weakening rupee (number going up) is a headwind for Nifty overall but a tailwind for IT. A strengthening rupee helps FII inflows." },
  brent: { name: "Brent crude", short: "Brent", fmt: v => "$" + nfNum(v, 2), chg: d => `${d.chg >= 0 ? "+" : "−"}$${nfNum(Math.abs(d.chg), 2)} (${d.pct >= 0 ? "+" : "−"}${nfNum(Math.abs(d.pct), 2)}%)`, th: 1,
    why: "India imports over 80% of its oil. Costlier crude widens the trade deficit, weakens the rupee and pushes up inflation, which can delay RBI rate cuts. Oil marketers, paints, tyres and airlines suffer most; ONGC and Oil India benefit.",
    rule: "Rising crude is a headwind for India. Every $10 a barrel adds roughly 0.4% to inflation and widens the current account deficit." }
};
// +1 = helps Indian equities, −1 = hurts, 0 = no meaningful move (all three hurt India when they rise)
const gtImpact = (k, d) => { const mv = k === "us10y" ? d.chg : d.pct; return Math.abs(mv) < GT[k].th ? 0 : mv > 0 ? -1 : 1; };

function gtSpark(arr, w = 120, hgt = 34, cls = "") {
  if (!arr || arr.length < 2) return "";
  const mn = Math.min(...arr), mx = Math.max(...arr), sp = mx - mn || 1;
  const pts = arr.map((v, i) => [i / (arr.length - 1) * w, hgt - 3 - (v - mn) / sp * (hgt - 6)]);
  const line = pts.map((p, i) => (i ? "L" : "M") + p[0].toFixed(1) + " " + p[1].toFixed(1)).join(" ");
  const last = pts[pts.length - 1], id = "g" + Math.random().toString(36).slice(2, 7);
  return `<svg class="gt-spark ${cls}" viewBox="0 0 ${w} ${hgt}" preserveAspectRatio="none" aria-hidden="true">
    <defs><linearGradient id="${id}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="currentColor" stop-opacity=".22"/><stop offset="1" stop-color="currentColor" stop-opacity="0"/></linearGradient></defs>
    <path d="${line} L${w} ${hgt} L0 ${hgt} Z" fill="url(#${id})"/><path d="${line}" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round" stroke-linecap="round" vector-effect="non-scaling-stroke"/>
    <circle cx="${last[0].toFixed(1)}" cy="${last[1].toFixed(1)}" r="2.4" fill="currentColor"/></svg>`;
}

function globalTroikaHtml() {
  return `<section class="card gt" id="gtCard" aria-label="Global troika">
    <div class="gt-head"><div><p class="gt-k">${t("Global troika")}</p><p class="gt-sub">${t("The three outside numbers that move FII money into India")}</p></div><span class="gt-when muted small" id="gtWhen"></span></div>
    <div class="gt-grid" id="gtGrid">${["us10y", "usdinr", "brent"].map(k => `<div class="gt-tile sk"><span class="gt-n">${GT[k].short}</span><span class="gt-v">—</span><span class="gt-c">&nbsp;</span></div>`).join("")}</div>
    <p class="gt-verdict" id="gtVerdict"></p>
  </section>`;
}
function gtDraw() {
  const grid = $("#gtGrid"); if (!grid) return;
  const d = gtData;
  if (!d || d.error) { grid.innerHTML = `<p class="muted small" style="margin:0;grid-column:1/-1">Global data couldn't load right now. Pull down to refresh.</p>`; return; }
  let head = 0, tail = 0;
  grid.innerHTML = ["us10y", "usdinr", "brent"].map(k => {
    const x = d[k], g = GT[k];
    if (!x) return `<div class="gt-tile"><span class="gt-n">${g.short}</span><span class="gt-v">—</span><span class="gt-c muted">unavailable</span></div>`;
    const im = gtImpact(k, x); if (im < 0) head++; if (im > 0) tail++;
    const m1 = x.spark.slice(-22);
    return `<button type="button" class="gt-tile im${im}" data-gt="${k}" aria-label="${g.name} ${g.fmt(x.price)}, ${im < 0 ? "headwind" : im > 0 ? "tailwind" : "neutral"} for Indian markets">
      <span class="gt-n">${g.short}</span>
      <span class="gt-v">${g.fmt(x.price)}</span>
      <span class="gt-c">${x.chg >= 0 ? "▲" : "▼"} ${k === "us10y" ? g.chg(x) : `${x.pct >= 0 ? "+" : "−"}${nfNum(Math.abs(x.pct), 2)}%`}</span>
      ${gtSpark(m1)}
      <span class="gt-im">${im < 0 ? "Headwind" : im > 0 ? "Tailwind" : "Neutral"}</span>
    </button>`;
  }).join("");
  const v = $("#gtVerdict");
  if (v) v.innerHTML = head >= 2 ? `<b class="down">Macro headwind.</b> ${head} of 3 are moving against Indian equities today. FII flows may stay cautious.`
    : tail >= 2 ? `<b class="up">Macro tailwind.</b> ${tail} of 3 are supportive for Indian equities today, which helps FII inflows.`
    : head && tail ? `<b>Mixed backdrop.</b> One helps, one hurts; no strong push from outside.` : head ? `<b>Mild headwind.</b> One of the three is moving against India; the others are quiet.`
    : tail ? `<b>Mild tailwind.</b> One of the three is supportive; the others are quiet.` : `<b>Calm backdrop.</b> None of the three moved enough to matter today.`;
  const w = $("#gtWhen"); if (w && d.fetchedAt) w.textContent = new Date(d.fetchedAt * 1000).toLocaleTimeString("en-IN", { timeZone: "Asia/Kolkata", hour: "numeric", minute: "2-digit" });
  $$("[data-gt]", grid).forEach(b => b.onclick = () => gtSheet(b.dataset.gt));
}
function gtSheet(k) {
  const x = gtData && gtData[k], g = GT[k]; if (!x) return;
  const m1 = x.spark.slice(-22), hi = Math.max(...m1), lo = Math.min(...m1), m1c = m1.length > 1 ? x.price - m1[0] : 0;
  const m3 = x.spark, im = gtImpact(k, x);
  const ch = (v) => k === "us10y" ? `${v >= 0 ? "+" : "−"}${nfNum(Math.abs(v) * 100, 0)} bps` : `${v >= 0 ? "+" : "−"}${nfNum(Math.abs(v / (x.price - v) * 100), 1)}%`;
  openSheet(g.name, `
    <div class="gt-sh-top im${im}"><span class="gt-sh-v">${g.fmt(x.price)}</span><span class="gt-sh-c">${x.chg >= 0 ? "▲" : "▼"} ${g.chg(x)} today</span><span class="gt-im">${im < 0 ? "Headwind for India" : im > 0 ? "Tailwind for India" : "Neutral today"}</span></div>
    <div class="gt-sh-chart">${gtSpark(m3, 320, 90, "big")}<div class="gt-sh-ax"><span>3 months ago</span><span>Today</span></div></div>
    <div class="nf-levels" style="margin-top:12px"><div><span>1-month high</span><strong>${g.fmt(hi)}</strong></div><div><span>1-month low</span><strong>${g.fmt(lo)}</strong></div><div><span>1-month change</span><strong>${ch(m1c)}</strong></div></div>
    <p class="sh-sec">Why it matters for Nifty</p><p style="margin:0;line-height:1.6">${esc(g.why)}</p>
    <p class="sh-sec">Rule of thumb</p><p style="margin:0;line-height:1.6">${esc(g.rule)}</p>
    <p class="muted small" style="margin-top:14px">Source: Yahoo Finance, may be delayed. For education only.</p>`, { sub: "Global troika" });
}
async function gtRefresh() {
  try { const { data, error } = await mbFn({ macro: true }); if (!error && data && !data.error) gtData = data; else if (!gtData) gtData = { error: true }; }
  catch (e) { if (!gtData) gtData = { error: true }; }
  gtDraw();
}
async function mountGlobalTroika() {
  clearInterval(gtTimer);
  if (!$("#gtCard")) return;
  if (gtData && !gtData.error) gtDraw();
  if (!gtData || gtData.error || Date.now() / 1000 - (gtData.fetchedAt || 0) > 300) await gtRefresh();
  gtTimer = setInterval(() => { if (!$("#gtCard")) { clearInterval(gtTimer); return; } if (!document.hidden) gtRefresh(); }, 300000);
}
