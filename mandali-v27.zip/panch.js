// =============================================================
// Panch: the elite members' section (Lounge, Vault, Live, Members)
// Everything here is protected in the database by is_panch().
// =============================================================
let pzTimer = null, pzChannel = null, pzPosts = [], pzReacts = [], pzVotes = [], pzKind = "post", pzFilter = "all",
  pzOpen = new Set(), pzPending = false, pzVideos = [], pzWatched = new Set(), pzTopic = "All", pzPlaying = null, pzSettings = {};
const PZ_EMOJI = ["🔥", "🎯", "👍", "🙏"];

function panchAccess() {
  if (!profile) return "none";
  if (profile.is_admin) return "active";
  if (!profile.is_panch) return "none";
  if (profile.paid_until && profile.paid_until < todayIST()) return "expired";
  return "active";
}

function panchCleanup() {
  clearInterval(pzTimer); pzTimer = null;
  if (pzChannel) { try { sb.removeChannel(pzChannel); } catch (e) {} pzChannel = null; }
}

function setPanchTheme(on) {
  document.body.classList.toggle("panch", !!on);
  const m = document.querySelector('meta[name="theme-color"]');
  if (m) m.setAttribute("content", on ? "#06181A" : "#0B1220");
}

function pzAgo(ts) {
  const s = (Date.now() - new Date(ts)) / 1000;
  if (s < 60) return "just now";
  if (s < 3600) return Math.floor(s / 60) + " min ago";
  if (s < 86400) return Math.floor(s / 3600) + " h ago";
  if (s < 604800) return Math.floor(s / 86400) + " d ago";
  return new Date(ts).toLocaleDateString("en-IN", { day: "numeric", month: "short" });
}
const pzInitial = (n) => (String(n || "M").trim()[0] || "M").toUpperCase();

function panchHead() {
  const first = (profile.full_name || "").split(" ")[0];
  const status = profile.is_admin ? "You're the mentor here"
    : profile.paid_until ? `Member till ${fmtDay(profile.paid_until)}` : "Panch member";
  return `
    <header class="pz-head">
      <div class="pz-eye" aria-hidden="true"><span>५</span></div>
      <div>
        <h1>Panch</h1>
        <p>${first ? esc(first) + ", " : ""}${esc(status)}</p>
      </div>
    </header>`;
}

function panchShell(sec, inner) {
  section = sec;
  setPanchTheme(true);
  app.innerHTML = `<div class="wrap pz">${panchHead()}${tabsHtml()}<div id="pzBody">${inner}</div></div>`;
  bindTabs();
}

function panchGate(sec) {
  panchCleanup();
  const a = panchAccess();
  if (a === "active") return true;
  viewPanchLocked(a, sec);
  return false;
}

/* ---------- Locked preview for non-members ---------- */
async function viewPanchLocked(state, sec) {
  section = sec || "lounge";
  setPanchTheme(true);
  let tz = { videos: 0, members: 0, titles: [] };
  try { const r = await sb.rpc("panch_teaser"); if (r.data) tz = r.data; } catch (e) {}
  const expired = state === "expired";
  const ask = `Hi, I'm ${profile.full_name || profile.email}. I'd like to join the Panch batch (₹4,999/month).`;
  app.innerHTML = `
    <div class="wrap pz">
      <section class="pz-locked">
        <div class="pz-eye big" aria-hidden="true"><span>५</span></div>
        <h1>${expired ? "Your Panch access has ended" : "Panch is our elite batch"}</h1>
        <p class="muted">${expired
          ? `Your membership ended on ${fmtDay(profile.paid_until)}. Renew to open the lounge, the vault and the live class again.`
          : "A small group that trades and learns closely with the mentor every afternoon."}</p>
        <ul class="pz-perks">
          <li><strong>${tz.videos || 0}</strong><span>exclusive videos in the vault</span></li>
          <li><strong>2:00 PM</strong><span>live Panch class, Monday to Friday</span></li>
          <li><strong>Lounge</strong><span>private trade ideas, polls and doubts</span></li>
          <li><strong>${tz.members || 0}</strong><span>members already inside</span></li>
        </ul>
        ${(tz.titles || []).length ? `<div class="pz-teaser"><p class="small muted">Recently added</p>${tz.titles.map(t => `<div class="pz-blur">🔒 ${esc(t)}</div>`).join("")}</div>` : ""}
        <p class="pz-price">${inr(4999)}<span> per month</span></p>
        <button class="btn block" id="pzJoin">${expired ? "Renew Panch" : "Join Panch"}</button>
        ${CFG.WHATSAPP ? `<a class="btn quiet block" style="margin-top:10px" target="_blank" rel="noopener" href="${waLink(CFG.WHATSAPP, ask)}">Ask on WhatsApp</a>` : ""}
        <p class="small muted" style="margin-top:14px">After you pay, Mandali adds you to Panch and this page unlocks.</p>
      </section>
    </div>`;
  $("#pzJoin").onclick = () => go("profile");
  updateNav();
}

/* ---------- Lounge ---------- */
async function pzLoadLounge() {
  const p = await sb.from("panch_posts").select("*").order("created_at", { ascending: false }).limit(200);
  if (p.error) throw p.error;
  pzPosts = p.data || [];
  const ids = pzPosts.map(x => x.id);
  if (ids.length) {
    const [r, v] = await Promise.all([
      sb.from("panch_reactions").select("post_id,user_id,emoji").in("post_id", ids),
      sb.from("panch_votes").select("post_id,user_id,option_index").in("post_id", ids)
    ]);
    pzReacts = r.data || []; pzVotes = v.data || [];
  } else { pzReacts = []; pzVotes = []; }
}

async function viewPanchLounge() {
  if (!panchGate("lounge")) return;
  panchShell("lounge", `<p class="muted">Opening the lounge…</p>`);
  try { await pzLoadLounge(); } catch (e) { $("#pzBody").innerHTML = msg("err", "Couldn't open the lounge. " + friendly(e)); return; }
  const kinds = [["post", "Post"], ["idea", "Trade idea"], ["poll", "Poll"]].concat(profile.is_admin ? [["announce", "Announcement"]] : []);
  $("#pzBody").innerHTML = `
    <form class="pz-compose" id="pzForm">
      <div class="pz-chips" role="radiogroup" aria-label="Type of post">
        ${kinds.map(([k, l]) => `<button type="button" class="pz-chip" role="radio" data-kind="${k}" aria-checked="${pzKind === k}">${l}</button>`).join("")}
      </div>
      <div id="pzIdea" class="grid2 ${pzKind === "idea" ? "" : "hidden"}">
        <label class="field"><span>Instrument</span><input name="instrument" value="NIFTY" maxlength="40"></label>
        <label class="field"><span>View</span><select name="bias"><option value="bullish">Bullish</option><option value="bearish">Bearish</option><option value="sideways">Sideways</option></select></label>
      </div>
      <label class="field" style="margin-bottom:10px"><span class="sr" id="pzLbl">Message</span>
        <textarea name="body" maxlength="2000" required aria-labelledby="pzLbl" placeholder="Share a level, a doubt or what you're watching today"></textarea></label>
      <div id="pzPoll" class="${pzKind === "poll" ? "" : "hidden"}">
        ${[0, 1, 2, 3].map(i => `<input class="pz-opt" name="opt${i}" maxlength="80" placeholder="Option ${i + 1}${i > 1 ? " (optional)" : ""}">`).join("")}
      </div>
      <div class="pz-compose-foot">
        <span class="small muted">Only Panch members can see this.</span>
        <button class="btn sm" type="submit">Post</button>
      </div>
    </form>
    <div class="pz-chips pz-filter" role="radiogroup" aria-label="Show">
      ${[["all", "Everything"], ["idea", "Trade ideas"], ["poll", "Polls"], ["mentor", "From mentor"]].map(([k, l]) =>
        `<button type="button" class="pz-chip quiet" role="radio" data-filter="${k}" aria-checked="${pzFilter === k}">${l}</button>`).join("")}
    </div>
    <button class="pz-newpill hidden" id="pzNew">New posts. Tap to show</button>
    <div id="pzFeed"></div>`;
  pzBindComposer();
  pzRenderFeed();
  pzSubscribe();
}

function pzBindComposer() {
  const f = $("#pzForm");
  const ph = { post: "Share a level, a doubt or what you're watching today", idea: "Entry, stop loss, target and why", poll: "Your question", announce: "Announcement for all Panch members" };
  const setKind = (k) => {
    pzKind = k;
    $$("[data-kind]", f).forEach(b => b.setAttribute("aria-checked", b.dataset.kind === k));
    $("#pzIdea").classList.toggle("hidden", k !== "idea");
    $("#pzPoll").classList.toggle("hidden", k !== "poll");
    f.body.placeholder = ph[k];
  };
  $$("[data-kind]", f).forEach(b => b.onclick = () => setKind(b.dataset.kind));
  setKind(pzKind);
  f.onsubmit = async (e) => {
    e.preventDefault();
    const body = f.body.value.trim();
    if (!body) return;
    const row = { body, kind: pzKind };
    if (pzKind === "idea") { row.instrument = f.instrument.value.trim().toUpperCase() || null; row.bias = f.bias.value; }
    if (pzKind === "poll") {
      const opts = [0, 1, 2, 3].map(i => f["opt" + i].value.trim()).filter(Boolean);
      if (opts.length < 2) { toast("Add at least 2 options"); return; }
      row.poll_options = opts;
    }
    const btn = f.querySelector('[type="submit"]'); btn.disabled = true;
    const { error } = await sb.from("panch_posts").insert(row);
    btn.disabled = false;
    if (error) { toast("Couldn't post: " + error.message); return; }
    f.reset(); setKind(pzKind);
    toast(pzKind === "poll" ? "Poll posted" : "Posted");
    await pzRefresh();
  };
  $$("[data-filter]").forEach(b => b.onclick = () => {
    pzFilter = b.dataset.filter;
    $$("[data-filter]").forEach(x => x.setAttribute("aria-checked", x.dataset.filter === pzFilter));
    pzRenderFeed();
  });
  $("#pzNew").onclick = () => pzRefresh();
}

async function pzRefresh() {
  try { await pzLoadLounge(); } catch (e) { return; }
  pzPending = false;
  const pill = $("#pzNew"); if (pill) pill.classList.add("hidden");
  pzRenderFeed();
}

function pzSubscribe() {
  if (!sb.channel) return;
  let t;
  const onChange = () => {
    clearTimeout(t);
    t = setTimeout(() => {
      if (section !== "lounge" || !$("#pzFeed")) return;
      const a = document.activeElement;
      const typing = a && $("#pzFeed").contains(a) && (a.value || "").trim();
      if (typing) { pzPending = true; $("#pzNew").classList.remove("hidden"); }
      else pzRefresh();
    }, 700);
  };
  pzChannel = sb.channel("panch-lounge")
    .on("postgres_changes", { event: "*", schema: "public", table: "panch_posts" }, onChange)
    .on("postgres_changes", { event: "*", schema: "public", table: "panch_reactions" }, onChange)
    .on("postgres_changes", { event: "*", schema: "public", table: "panch_votes" }, onChange)
    .subscribe();
}

function pzPollHtml(p) {
  const opts = Array.isArray(p.poll_options) ? p.poll_options : [];
  const votes = pzVotes.filter(v => v.post_id === p.id);
  const mine = votes.find(v => v.user_id === profile.id);
  const show = mine || profile.is_admin;
  return `<div class="pz-poll">
    ${opts.map((o, i) => {
      const n = votes.filter(v => v.option_index === i).length;
      const pct = votes.length ? Math.round(n / votes.length * 100) : 0;
      return `<button class="pz-vote${mine && mine.option_index === i ? " mine" : ""}" data-vote="${i}" style="--pct:${show ? pct : 0}%">
        <span>${esc(o)}</span>${show ? `<strong>${pct}%</strong>` : ""}</button>`;
    }).join("")}
    <p class="small muted" style="margin:6px 0 0">${votes.length} ${votes.length === 1 ? "vote" : "votes"}${mine ? ". Tap another option to change your vote." : ". Vote to see results."}</p>
  </div>`;
}

function pzReactRow(p) {
  const rs = pzReacts.filter(r => r.post_id === p.id);
  return PZ_EMOJI.map(e => {
    const n = rs.filter(r => r.emoji === e).length;
    const on = rs.some(r => r.emoji === e && r.user_id === profile.id);
    return `<button class="pz-react${on ? " on" : ""}" data-react="${e}" aria-pressed="${on}" aria-label="React ${e}">${e}${n ? `<span>${n}</span>` : ""}</button>`;
  }).join("");
}

function pzPostHtml(p) {
  const replies = pzPosts.filter(r => r.parent_id === p.id).sort((a, b) => new Date(a.created_at) - new Date(b.created_at));
  const mineOrAdmin = p.user_id === profile.id || profile.is_admin;
  const open = pzOpen.has(p.id);
  return `
    <article class="pz-post k-${p.kind}${p.pinned ? " pinned" : ""}" data-id="${p.id}">
      <header>
        <span class="pz-av${p.author_is_admin ? " mentor" : ""}" aria-hidden="true">${pzInitial(p.author_name)}</span>
        <div class="pz-who">
          <span><strong>${esc(p.author_name || "Member")}</strong>${p.author_is_admin ? `<span class="pz-tag">Mentor</span>` : ""}</span>
          <span class="small muted">${pzAgo(p.created_at)}${p.pinned ? ", pinned" : ""}</span>
        </div>
        ${p.kind === "announce" ? `<span class="pz-kind">Announcement</span>` : p.kind === "idea" ? `<span class="pz-kind">Trade idea</span>` : p.kind === "poll" ? `<span class="pz-kind">Poll</span>` : ""}
      </header>
      ${p.kind === "idea" ? `<div class="pz-idea"><strong>${esc(p.instrument || "")}</strong><span class="bias ${esc(p.bias)}">${biasLabel(p.bias)}</span></div>` : ""}
      <p class="pre pz-body">${esc(p.body)}</p>
      ${p.kind === "poll" ? pzPollHtml(p) : ""}
      ${p.kind === "idea" ? `<p class="small muted" style="margin:0 0 8px">A member's view for discussion. Not a trade call.</p>` : ""}
      <footer>
        <div class="pz-reacts">${pzReactRow(p)}</div>
        <button class="pz-link" data-toggle aria-expanded="${open}">${replies.length ? `${replies.length} ${replies.length === 1 ? "reply" : "replies"}` : "Reply"}</button>
      </footer>
      <div class="pz-replies${open ? "" : " hidden"}">
        ${replies.map(r => `
          <div class="pz-reply" data-id="${r.id}">
            <span class="pz-av sm${r.author_is_admin ? " mentor" : ""}" aria-hidden="true">${pzInitial(r.author_name)}</span>
            <div><strong>${esc(r.author_name || "Member")}</strong>${r.author_is_admin ? `<span class="pz-tag">Mentor</span>` : ""} <span class="small muted">${pzAgo(r.created_at)}</span>
              <p class="pre">${esc(r.body)}</p>
              ${(r.user_id === profile.id || profile.is_admin) ? `<button class="pz-link danger" data-delreply="${r.id}">Delete</button>` : ""}
            </div>
          </div>`).join("")}
        <form class="pz-replyform"><input name="body" maxlength="1000" placeholder="Write a reply" aria-label="Write a reply" required><button class="btn sm" type="submit">Send</button></form>
      </div>
      ${mineOrAdmin ? `<div class="pz-admin">
        ${profile.is_admin ? `<button class="pz-link" data-pin>${p.pinned ? "Unpin" : "Pin to top"}</button>` : ""}
        <button class="pz-link danger" data-del>Delete</button></div>` : ""}
    </article>`;
}

function pzRenderFeed() {
  const el = $("#pzFeed"); if (!el) return;
  let top = pzPosts.filter(p => !p.parent_id);
  if (pzFilter === "idea") top = top.filter(p => p.kind === "idea");
  if (pzFilter === "poll") top = top.filter(p => p.kind === "poll");
  if (pzFilter === "mentor") top = top.filter(p => p.author_is_admin);
  top.sort((a, b) => ((+!!b.pinned) - (+!!a.pinned)) || (new Date(b.created_at) - new Date(a.created_at)));
  if (!top.length) {
    el.innerHTML = `<div class="pz-empty">${pzFilter === "all"
      ? "The lounge is quiet. Start it with today's level you're watching."
      : "Nothing here yet."}</div>`;
    return;
  }
  el.innerHTML = top.map(pzPostHtml).join("");
  $$(".pz-post", el).forEach(card => {
    const id = +card.dataset.id;
    $$("[data-react]", card).forEach(b => b.onclick = async () => {
      const on = b.classList.contains("on");
      b.disabled = true;
      const r = on
        ? await sb.from("panch_reactions").delete().eq("post_id", id).eq("user_id", profile.id).eq("emoji", b.dataset.react)
        : await sb.from("panch_reactions").insert({ post_id: id, user_id: profile.id, emoji: b.dataset.react });
      if (r.error) toast("Couldn't react: " + r.error.message);
      pzRefresh();
    });
    $$("[data-vote]", card).forEach(b => b.onclick = async () => {
      const r = await sb.from("panch_votes").upsert({ post_id: id, user_id: profile.id, option_index: +b.dataset.vote }, { onConflict: "post_id,user_id" });
      if (r.error) toast("Couldn't vote: " + r.error.message); else toast("Vote counted");
      pzRefresh();
    });
    card.querySelector("[data-toggle]").onclick = (e) => {
      const box = card.querySelector(".pz-replies");
      box.classList.toggle("hidden");
      const open = !box.classList.contains("hidden");
      e.currentTarget.setAttribute("aria-expanded", open);
      open ? pzOpen.add(id) : pzOpen.delete(id);
      if (open) box.querySelector("input").focus();
    };
    card.querySelector(".pz-replyform").onsubmit = async (e) => {
      e.preventDefault();
      const body = e.target.body.value.trim(); if (!body) return;
      const { error } = await sb.from("panch_posts").insert({ body, parent_id: id });
      if (error) return toast("Couldn't reply: " + error.message);
      pzOpen.add(id); e.target.reset(); pzRefresh();
    };
    $$("[data-delreply]", card).forEach(b => b.onclick = async () => {
      if (!confirm("Delete this reply?")) return;
      await sb.from("panch_posts").delete().eq("id", +b.dataset.delreply); pzRefresh();
    });
    const del = card.querySelector("[data-del]");
    if (del) del.onclick = async () => {
      if (!confirm("Delete this post and its replies?")) return;
      const { error } = await sb.from("panch_posts").delete().eq("id", id);
      if (error) toast("Couldn't delete: " + error.message); else toast("Deleted");
      pzRefresh();
    };
    const pin = card.querySelector("[data-pin]");
    if (pin) pin.onclick = async () => {
      const post = pzPosts.find(x => x.id === id);
      const { error } = await sb.from("panch_posts").update({ pinned: !post.pinned }).eq("id", id);
      if (error) toast("Couldn't pin: " + error.message); else toast(post.pinned ? "Unpinned" : "Pinned to top");
      pzRefresh();
    };
  });
}

/* ---------- Vault: exclusive videos ---------- */
async function viewPanchVault() {
  if (!panchGate("vault")) return;
  panchShell("vault", `<p class="muted">Opening the vault…</p>`);
  const [v, w] = await Promise.all([
    sb.from("panch_videos").select("*").order("pinned", { ascending: false }).order("created_at", { ascending: false }),
    sb.from("panch_watch").select("video_id").eq("user_id", profile.id)
  ]);
  if (v.error) { $("#pzBody").innerHTML = msg("err", "Couldn't open the vault. " + friendly(v.error)); return; }
  pzVideos = v.data || [];
  pzWatched = new Set((w.data || []).map(x => x.video_id));
  pzDrawVault();
}

function pzDrawVault() {
  const topics = ["All", ...new Set(pzVideos.map(v => v.topic || "Strategy"))];
  if (!topics.includes(pzTopic)) pzTopic = "All";
  const list = pzVideos.filter(v => pzTopic === "All" || (v.topic || "Strategy") === pzTopic);
  const done = pzVideos.filter(v => pzWatched.has(v.id)).length;
  const pct = pzVideos.length ? Math.round(done / pzVideos.length * 100) : 0;
  const cur = pzVideos.find(v => v.id === pzPlaying);
  $("#pzBody").innerHTML = `
    ${profile.is_admin ? `
      <details class="pz-addvid">
        <summary>Add an exclusive video</summary>
        <form id="pzVidForm">
          <label class="field"><span>Title</span><input name="title" required maxlength="140" placeholder="Expiry day FVG setup, live breakdown"></label>
          <label class="field"><span>YouTube (unlisted), Vimeo or Drive link</span><input name="url" required inputmode="url" placeholder="https://youtu.be/..."></label>
          <div class="grid2">
            <label class="field"><span>Topic</span><input name="topic" list="pzTopics" value="Strategy" maxlength="40"></label>
            <label class="field"><span>Pin to top</span><select name="pinned"><option value="false">No</option><option value="true">Yes</option></select></label>
          </div>
          <datalist id="pzTopics">${["Strategy", "Live trade review", "Expiry day", "Psychology", "Market prep"].map(t => `<option value="${t}">`).join("")}</datalist>
          <label class="field"><span>Notes for members (optional)</span><textarea name="description" maxlength="1500"></textarea></label>
          <button class="btn" type="submit">Post to Panch vault</button>
        </form>
      </details>` : ""}
    ${cur ? `
      <section class="pz-stage" id="pzStage">
        <div class="player"><iframe src="${esc(toEmbed(cur.video_url))}" title="${esc(cur.title)}"
          allow="autoplay; fullscreen; picture-in-picture; encrypted-media" allowfullscreen referrerpolicy="strict-origin-when-cross-origin"></iframe></div>
        <h2>${esc(cur.title)}</h2>
        ${cur.description ? `<p class="pre muted">${esc(cur.description)}</p>` : ""}
        <div class="actions">
          <button class="btn sm${pzWatched.has(cur.id) ? " quiet" : ""}" id="pzMark">${pzWatched.has(cur.id) ? "Watched ✓ (tap to undo)" : "Mark as watched"}</button>
          <button class="btn sm quiet" id="pzClose">Close player</button>
        </div>
      </section>` : ""}
    <div class="pz-progress">
      <div><strong>${done} of ${pzVideos.length}</strong> <span class="muted small">exclusive videos watched</span></div>
      <div class="pz-bar" role="progressbar" aria-valuenow="${pct}" aria-valuemin="0" aria-valuemax="100"><i style="width:${pct}%"></i></div>
    </div>
    ${topics.length > 2 ? `<div class="pz-chips" role="radiogroup" aria-label="Topic">${topics.map(t =>
      `<button class="pz-chip quiet" role="radio" data-topic="${esc(t)}" aria-checked="${pzTopic === t}">${esc(t)}</button>`).join("")}</div>` : ""}
    <div class="pz-vids">
      ${list.length ? list.map(v => `
        <div class="pz-vid${pzWatched.has(v.id) ? " done" : ""}${v.id === pzPlaying ? " playing" : ""}">
          <button class="pz-vid-main" data-vid="${v.id}">
            <span class="pz-play" aria-hidden="true">${pzWatched.has(v.id) ? "✓" : "▶"}</span>
            <span class="pz-vid-text"><strong>${esc(v.title)}</strong>
              <span class="small muted">${esc(v.topic || "Strategy")}, ${pzAgo(v.created_at)}${v.pinned ? ", pinned" : ""}</span></span>
          </button>
          ${profile.is_admin ? `<button class="pz-link danger" data-delvid="${v.id}">Delete</button>` : ""}
        </div>`).join("")
        : `<div class="pz-empty">${profile.is_admin ? "Your vault is empty. Add the first exclusive video above." : "Exclusive videos will appear here as soon as they're posted."}</div>`}
    </div>`;

  $$("[data-topic]").forEach(b => b.onclick = () => { pzTopic = b.dataset.topic; pzDrawVault(); });
  $$("[data-vid]").forEach(b => b.onclick = () => {
    pzPlaying = +b.dataset.vid; pzDrawVault();
    const st = $("#pzStage"); if (st) st.scrollIntoView({ behavior: "smooth", block: "start" });
  });
  $$("[data-delvid]").forEach(b => b.onclick = async (e) => {
    e.stopPropagation();
    if (!confirm("Delete this video from the Panch vault?")) return;
    const { error } = await sb.from("panch_videos").delete().eq("id", +b.dataset.delvid);
    if (error) return toast("Couldn't delete: " + error.message);
    pzVideos = pzVideos.filter(v => v.id !== +b.dataset.delvid); toast("Deleted"); pzDrawVault();
  });
  const close = $("#pzClose"); if (close) close.onclick = () => { pzPlaying = null; pzDrawVault(); };
  const mark = $("#pzMark");
  if (mark) mark.onclick = async () => {
    const id = pzPlaying;
    if (pzWatched.has(id)) { await sb.from("panch_watch").delete().eq("user_id", profile.id).eq("video_id", id); pzWatched.delete(id); }
    else {
      const { error } = await sb.from("panch_watch").insert({ user_id: profile.id, video_id: id });
      if (error && !/duplicate/i.test(error.message)) return toast("Couldn't save: " + error.message);
      pzWatched.add(id); toast("Marked as watched");
    }
    pzDrawVault();
  };
  const vf = $("#pzVidForm");
  if (vf) vf.onsubmit = async (e) => {
    e.preventDefault();
    const row = { title: vf.title.value.trim(), video_url: vf.url.value.trim(), topic: vf.topic.value.trim() || "Strategy",
      pinned: vf.pinned.value === "true", description: vf.description.value.trim() || null };
    const btn = vf.querySelector("button"); btn.disabled = true;
    const { data, error } = await sb.from("panch_videos").insert(row).select().single();
    btn.disabled = false;
    if (error) return toast("Couldn't post: " + error.message);
    pzVideos.unshift(data); pzPlaying = data.id; toast("Posted to the Panch vault"); pzDrawVault();
  };
}

/* ---------- Live class ---------- */
const PZ_START = [14, 0], PZ_END = [15, 15];
function pzNextSession() {
  const now = istNow();
  const at = (d, hm) => { const x = new Date(d.getFullYear(), d.getMonth(), d.getDate(), hm[0], hm[1]); return x; };
  let d = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  if (isTradingDay(d) && now < at(d, PZ_END)) return { start: at(d, PZ_START), end: at(d, PZ_END), live: now >= at(d, PZ_START) };
  d = nextTradingDay(d);
  return { start: at(d, PZ_START), end: at(d, PZ_END), live: false };
}
function pzLiveInner() {
  const s = pzNextSession(), now = istNow();
  if (s.live) {
    const left = Math.max(0, Math.round((s.end - now) / 60000));
    return `<p class="pz-live-on"><span class="pz-dot"></span>Live now</p><p class="muted">${left} min left in today's class</p>`;
  }
  const diff = Math.max(0, Math.floor((s.start - now) / 1000));
  const h = Math.floor(diff / 3600), m = Math.floor(diff % 3600 / 60), sec = diff % 60;
  const sameDay = ymd(s.start) === ymd(now);
  return `<p class="muted" style="margin:0">Next class ${sameDay ? "today" : shortDay(s.start)}, 2:00 PM</p>
    <p class="pz-count" aria-live="off">${h ? h + "h " : ""}${String(m).padStart(2, "0")}m ${String(sec).padStart(2, "0")}s</p>`;
}
async function viewPanchLive() {
  if (!panchGate("live")) return;
  panchShell("live", `<p class="muted">Loading…</p>`);
  const r = await sb.from("panch_settings").select("*");
  pzSettings = Object.fromEntries((r.data || []).map(x => [x.key, x.value]));
  const url = (pzSettings.live_url || "").trim();
  const week = []; const ns = pzNextSession().start; let d = new Date(ns.getFullYear(), ns.getMonth(), ns.getDate());
  while (week.length < 5) { week.push(new Date(d)); d = nextTradingDay(d); }
  $("#pzBody").innerHTML = `
    <section class="pz-livecard">
      <div id="pzLive">${pzLiveInner()}</div>
      ${url ? `<a class="btn block" href="${esc(url)}" target="_blank" rel="noopener">Join Panch class</a>`
            : `<button class="btn block" disabled>Class link appears here before 2:00 PM</button>`}
      ${pzSettings.live_note ? `<p class="small muted pre" style="margin:12px 0 0">${esc(pzSettings.live_note)}</p>` : ""}
    </section>
    <h3 class="pz-h3">Coming sessions</h3>
    <div class="pz-week">${week.map(w => `<div class="pz-day${ymd(w) === ymd(istNow()) ? " today" : ""}"><strong>${w.toLocaleDateString("en-IN", { weekday: "short" })}</strong><span>${w.getDate()} ${w.toLocaleDateString("en-IN", { month: "short" })}</span><small>2:00 PM</small></div>`).join("")}</div>
    <p class="small muted">Market holidays are skipped automatically.</p>
    ${profile.is_admin ? `
      <form class="card pz-adminform" id="pzLiveForm">
        <h3 style="margin-bottom:12px">Class link (only you can edit)</h3>
        <label class="field"><span>Zoom / Google Meet / YouTube Live link</span><input name="live_url" inputmode="url" value="${esc(url)}" placeholder="https://meet.google.com/..."></label>
        <label class="field"><span>Note for members</span><textarea name="live_note" maxlength="500">${esc(pzSettings.live_note || "")}</textarea></label>
        <button class="btn" type="submit">Save class link</button>
      </form>` : ""}`;
  pzTimer = setInterval(() => { const el = $("#pzLive"); if (el) el.innerHTML = pzLiveInner(); else panchCleanup(); }, 1000);
  const lf = $("#pzLiveForm");
  if (lf) lf.onsubmit = async (e) => {
    e.preventDefault();
    const { error } = await sb.from("panch_settings").upsert([
      { key: "live_url", value: lf.live_url.value.trim() }, { key: "live_note", value: lf.live_note.value.trim() }]);
    if (error) return toast("Couldn't save: " + error.message);
    toast("Class link saved"); viewPanchLive();
  };
}

/* ---------- Members ---------- */
async function viewPanchMembers() {
  if (!panchGate("members")) return;
  panchShell("members", `<p class="muted">Loading…</p>`);
  const { data, error } = await sb.rpc("panch_members");
  if (error) { $("#pzBody").innerHTML = msg("err", "Couldn't load members. " + friendly(error)); return; }
  const list = data || [];
  const students = list.filter(m => !m.is_admin);
  $("#pzBody").innerHTML = `
    <p class="pz-membercount"><strong>${students.length}</strong> ${students.length === 1 ? "member" : "members"} in Panch</p>
    <div class="pz-members">
      ${list.map(m => `
        <div class="pz-member${m.id === profile.id ? " me" : ""}">
          <span class="pz-av${m.is_admin ? " mentor" : ""}" aria-hidden="true">${pzInitial(m.full_name)}</span>
          <div><strong>${esc(m.full_name)}${m.id === profile.id ? " (you)" : ""}</strong>
          <span class="small muted">${m.is_admin ? "Mentor" : "Since " + new Date(m.joined).toLocaleDateString("en-IN", { month: "short", year: "numeric" })}</span></div>
        </div>`).join("")}
    </div>
    <p class="small muted" style="margin-top:16px">Only first names are shown. Phone numbers and emails stay private.</p>`;
}
