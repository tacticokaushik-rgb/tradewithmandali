// =============================================================
// Mandali Portal settings: the ONLY file you need to edit.
// Find these in Supabase > Project Settings > API (or "API Keys").
// The anon / publishable key is safe to put here; never paste the
// "service_role" or "secret" key.
// =============================================================
window.MANDALI_CONFIG = {
  SUPABASE_URL: "https://qwaixadhlyiarpmpoaaj.supabase.co",
  SUPABASE_ANON_KEY: "sb_publishable_baoVvFwpezNUO7CY0xskDA_BBIpbfY8",

  // WhatsApp number students message for approval (country code, no +)
  WHATSAPP: "918825336576",

  // Public key for push reminders (safe to share; the private key lives only in Supabase Secrets)
  // Name of the Supabase function for Mandali AI (change only if Supabase gave it a different name)
  // Mandali AI is switched off for now. Set to true (and add ANTHROPIC_API_KEY in Supabase) to turn it back on.
  AI_ENABLED: false,
  AI_FUNCTION: "Ask-ai",
  // Name of the reminders function (Supabase named it quick-processor)
  REMINDER_FUNCTION: "quick-processor",

  VAPID_PUBLIC_KEY: "BFQiKyG6THxlvxhjeb32914yCjY4Byqr1k0eveWrZ0dS_e2PDXTeIId_eVnO-ENEW_PjZhQ0COMbbxBUHecjDt4"
};
