/* Mandali "Terms": economy and market words from the newspaper, explained from basic to advanced. */
(function () {
  const V = "20261012b";
  let cat = "All", onlySaved = false;
  const load = () => window.TERMS_DATA ? Promise.resolve() : (window._termsLoading = window._termsLoading || new Promise((res) => {
    const s = document.createElement("script"); s.src = "terms-data.js?v=" + V; s.onload = res; s.onerror = () => { window._termsLoading = null; res(); }; document.head.appendChild(s);
  }));
  window.loadTerms = load;
  const T = () => (window.TERMS_DATA || []).map(r => ({ t: r[0], a: r[1], c: r[2], s: r[3], d: r[4], m: r[5], e: r[6], r: r[7] }));
  const byName = () => { const m = new Map(); T().forEach(x => { m.set(x.t.toLowerCase(), x); }); return m; };
  const getSaved = () => { try { return new Set(JSON.parse(localStorage.getItem("m_terms_saved") || "[]")); } catch (e) { return new Set(); } };
  const setSaved = (s) => { try { localStorage.setItem("m_terms_saved", JSON.stringify([...s])); } catch (e) {} };
  const pushRecent = (t) => { try { const r = JSON.parse(localStorage.getItem("m_terms_recent") || "[]").filter(x => x !== t); r.unshift(t); localStorage.setItem("m_terms_recent", JSON.stringify(r.slice(0, 8))); } catch (e) {} };
  const getRecent = () => { try { return JSON.parse(localStorage.getItem("m_terms_recent") || "[]"); } catch (e) { return []; } };
  const FREE_TERMS = new Set(["inflation", "cpi", "repo rate", "gdp", "ebitda", "nim"]);
  const todayTerm = () => { const all = window.TERMS_DATA || []; const day = Math.floor((Date.now() + 19800e3) / 86400e3); return all.length ? all[(day * 37) % all.length][0] : ""; };
  const termLocked = (name) => !isPro() && !FREE_TERMS.has(String(name).toLowerCase()) && name !== todayTerm();
  window.termLocked = termLocked;
  const first = (s) => (s.match(/^.*?[.!?](\s|$)/) || [s])[0].trim();
  const norm = (x) => String(x || "").toLowerCase().replace(/[^a-z0-9%&/+ -]+/g, " ").replace(/\s+/g, " ").trim();
  const reEsc = (x) => x.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const hi = (txt, q) => { const h = esc(txt); return q ? h.replace(new RegExp("(" + reEsc(esc(q)) + ")", "ig"), "<mark>$1</mark>") : h; };
  const CAT_IC = { "Inflation and prices": "🏷️", "RBI and monetary policy": "🏛️", "Banking and NBFCs": "🏦", "Company results and accounts": "📊", "Valuation": "⚖️", "Economy and growth": "🌾", "Government and budget": "🧾", "Bonds and interest rates": "📈", "External sector and currency": "💱", "Markets and capital raising": "🔔", "Global economy": "🌍", "Sector words in the news": "📰" };

  /* ---------- Term card (bottom sheet) ---------- */
  window.openTermSheet = (name, list) => {
    const m = byName(); let cur = m.get(String(name).toLowerCase()); if (!cur) return;
    const trail = [];
    const sh = openSheet(cur.t, "", { sub: "" });
    const draw = () => {
      pushRecent(cur.t);
      const saved = getSaved().has(cur.t);
      const seq = (list && list.length ? list : T().filter(x => x.c === cur.c)).map(x => x.t);
      const i = seq.indexOf(cur.t), next = i >= 0 && i < seq.length - 1 ? seq[i + 1] : null, prev = i > 0 ? seq[i - 1] : null;
      sh.el.querySelector(".sheet-head h2").textContent = cur.t;
      const sub = sh.el.querySelector(".sheet-sub"); if (sub) sub.innerHTML = `${CAT_IC[cur.c] || ""} ${esc(cur.c)}${cur.a ? ` · also called <em>${esc(cur.a)}</em>` : ""}`;
      const locked = termLocked(cur.t);
      const deep = `<ol class="tm-steps" start="2">
          <li><span class="tm-lv i">2 · How it works</span><p>${esc(cur.d)}</p></li>
          <li><span class="tm-lv a">3 · Why traders care</span><p>${esc(cur.m)}</p></li></ol>
        <div class="tm-news"><span>📰 How you'll see it in the news</span><p>${esc(cur.e.replace(/^"|"$/g, ""))}</p></div>`;
      if (locked) { sh.body.innerHTML = `
        ${trail.length ? `<button class="tm-back" data-back>‹ Back to ${esc(trail[trail.length - 1])}</button>` : ""}
        <ol class="tm-steps"><li><span class="tm-lv b">1 · In simple words</span><p>${esc(cur.s)}</p></li></ol>
        <div style="margin-top:14px">${Lock.wrap(deep, "Terms", { title: "Read the full explanation", sub: "How it works, why traders care and how it shows up in the news" })}</div>
        <div class="tm-nav">${prev ? `<button class="btn sm quiet" data-go="${esc(prev)}">‹ ${esc(prev)}</button>` : "<span></span>"}${next ? `<button class="btn sm quiet" data-go="${esc(next)}">${esc(next)} ›</button>` : ""}</div>`;
        sh.body.scrollTop = 0;
        $$("[data-go]", sh.body).forEach(b => b.onclick = () => { const n = m.get(b.dataset.go.toLowerCase()); if (n) { cur = n; draw(); } });
        const bk0 = $("[data-back]", sh.body); if (bk0) bk0.onclick = () => { cur = m.get(trail.pop().toLowerCase()); draw(); };
        return;
      }
      sh.body.innerHTML = `
        ${trail.length ? `<button class="tm-back" data-back>‹ Back to ${esc(trail[trail.length - 1])}</button>` : ""}
        <ol class="tm-steps">
          <li><span class="tm-lv b">1 · In simple words</span><p>${esc(cur.s)}</p></li>
          <li><span class="tm-lv i">2 · How it works</span><p>${esc(cur.d)}</p></li>
          <li><span class="tm-lv a">3 · Why traders care</span><p>${esc(cur.m)}</p></li>
        </ol>
        <div class="tm-news"><span>📰 How you'll see it in the news</span><p>${esc(cur.e.replace(/^"|"$/g, ""))}</p></div>
        ${cur.r.length ? `<p class="sh-sec">Related</p><div class="tm-rel">${cur.r.map(r => r.startsWith("~")
          ? `<button class="chip" data-dict="${esc(r.slice(1))}">${esc(r.slice(1))} <small>dictionary</small></button>`
          : `<button class="chip" data-rel="${esc(r)}">${esc(r)}</button>`).join("")}</div>` : ""}
        <div class="tm-acts">
          <button class="btn sm ${saved ? "" : "ghost"}" data-save>${saved ? "★ Saved" : "☆ Save"}</button>
          ${navigator.share ? `<button class="btn sm quiet" data-share>Share</button>` : `<button class="btn sm quiet" data-copy>Copy</button>`}
        </div>
        <div class="tm-nav">${prev ? `<button class="btn sm quiet" data-go="${esc(prev)}">‹ ${esc(prev)}</button>` : "<span></span>"}${next ? `<button class="btn sm quiet" data-go="${esc(next)}">${esc(next)} ›</button>` : ""}</div>`;
      sh.body.scrollTop = 0;
      const jump = (t, push = true) => { const n = m.get(t.toLowerCase()); if (!n) return; if (push) trail.push(cur.t); cur = n; draw(); };
      $$("[data-rel]", sh.body).forEach(b => b.onclick = () => jump(b.dataset.rel));
      $$("[data-go]", sh.body).forEach(b => b.onclick = () => jump(b.dataset.go, false));
      const bk = $("[data-back]", sh.body); if (bk) bk.onclick = () => { cur = m.get(trail.pop().toLowerCase()); draw(); };
      $$("[data-dict]", sh.body).forEach(b => b.onclick = () => { sh.close(); setTimeout(() => { go("glossary"); setTimeout(() => { const q = $("#glQ"); if (q) { q.value = b.dataset.dict; q.dispatchEvent(new Event("input")); } }, 400); }, 240); });
      $("[data-save]", sh.body).onclick = () => { const s = getSaved(); s.has(cur.t) ? s.delete(cur.t) : s.add(cur.t); setSaved(s); draw(); if (section === "terms") window._termsRedraw && window._termsRedraw(); };
      const txt = () => `${cur.t}\n\n${cur.s}\n\n${cur.d}\n\nWhy traders care: ${cur.m}\n\nLearn more on Mandali: ${location.origin + location.pathname}`;
      const shb = $("[data-share]", sh.body); if (shb) shb.onclick = () => navigator.share({ title: cur.t, text: txt() }).catch(() => {});
      const cpb = $("[data-copy]", sh.body); if (cpb) cpb.onclick = async () => { try { await navigator.clipboard.writeText(txt()); cpb.textContent = "Copied ✓"; } catch (e) {} };
    };
    draw();
  };

  /* ---------- Terms list ---------- */
  window.viewTerms = function (q = "") {
    section = "terms";
    app.innerHTML = `<div class="wrap">${tabsHtml()}
      <h2 class="sec-title" style="margin:8px 0 4px">${t("Terms")}</h2>
      <p class="muted small" style="margin:0 0 12px">Economy and market words you see in the newspaper every day, each explained from basic to advanced. Tap any term.</p>
      <input id="tmQ" type="search" placeholder="Search: CPI, NIM, EBITDA, repo…" value="${esc(q)}" autocomplete="off" style="width:100%">
      <div class="chips" id="tmCats" style="margin-top:10px"></div>
      <div id="tmTop"></div>
      <p class="gl-count" id="tmCount"></p>
      <div id="tmList"><p class="muted">Loading terms…</p></div></div>`;
    bindTabs();
    { const at = $(".tab[aria-selected=true]") || $(".tab.active"); if (at && at.scrollIntoView) at.scrollIntoView({ block: "nearest", inline: "center" }); }
    load().then(() => {
      if (section !== "terms") return;
      const all = T();
      if (!all.length) { $("#tmList").innerHTML = msg("err", "Terms couldn't load. Check your internet and tap Refresh on Home."); return; }
      const cats = ["All", ...new Set(all.map(x => x.c))];
      const drawCats = () => { const sv = getSaved().size;
        $("#tmCats").innerHTML = `${sv ? `<button class="chip" data-saved aria-pressed="${onlySaved}">★ Saved (${sv})</button>` : ""}` + cats.map(c => `<button class="chip" data-cat="${esc(c)}" aria-pressed="${!onlySaved && cat === c}">${c === "All" ? "All" : (CAT_IC[c] || "") + " " + esc(c)}</button>`).join("");
        $$("[data-cat]", $("#tmCats")).forEach(b => b.onclick = () => { cat = b.dataset.cat; onlySaved = false; drawCats(); draw(); });
        const sb2 = $("[data-saved]", $("#tmCats")); if (sb2) sb2.onclick = () => { onlySaved = !onlySaved; drawCats(); draw(); };
      };
      const day = Math.floor((Date.now() + 19800e3) / 86400e3), today = all[(day * 37) % all.length];
      let shown = [];
      const draw = () => {
        const raw = $("#tmQ").value.trim(), qq = norm(raw), sv = getSaved();
        let rows = all.filter(x => (onlySaved ? sv.has(x.t) : cat === "All" || x.c === cat));
        if (qq) {
          const sc = (x) => { const k = norm(x.t), a = norm(x.a);
            if (k === qq || a.split(" ").includes(qq) && qq.length > 1 && a.split(/\s*,\s*/).includes(qq)) return 0;
            if (k.startsWith(qq)) return 1; if (a.split(/[ ,]+/).some(w => w.startsWith(qq))) return 2;
            if (k.includes(qq) || a.includes(qq)) return 3; if (norm(x.s).includes(qq)) return 4; if (norm(x.d + " " + x.m).includes(qq)) return 5; return 9; };
          rows = rows.map(x => [sc(x), x]).filter(x => x[0] < 9).sort((a, b) => a[0] - b[0] || a[1].t.localeCompare(b[1].t)).map(x => x[1]);
        }
        shown = rows;
        const recent = getRecent().map(n => all.find(x => x.t === n)).filter(Boolean).slice(0, 6);
        $("#tmTop").innerHTML = qq || onlySaved || cat !== "All" ? "" : `
          <button class="card tm-today" data-open="${esc(today.t)}"><span class="tm-kick">TERM OF THE DAY · ${esc(today.c.toUpperCase())}</span>
            <strong>${esc(today.t)}</strong><span>${esc(first(today.s))}</span><span class="tm-more">Read the full explanation ›</span></button>
          ${recent.length ? `<p class="sh-sec">Recently read</p><div class="tm-rel" style="margin-bottom:6px">${recent.map(x => `<button class="chip" data-open="${esc(x.t)}">${esc(x.t)}</button>`).join("")}</div>` : ""}`;
        $("#tmCount").innerHTML = esc(`${rows.length} term${rows.length === 1 ? "" : "s"}${qq ? ` matching "${raw}"` : onlySaved ? " saved" : cat !== "All" ? " in " + cat : ""}`) + (isPro() ? "" : ` · <button class="linkbtn" data-lock="all 246 Terms">${FREE_TERMS.size + 1} free today, subscribe to unlock all</button>`);
        let last = "";
        const grouped = !qq && cat === "All" && !onlySaved;
        const list = grouped ? rows.slice().sort((a, b) => cats.indexOf(a.c) - cats.indexOf(b.c)) : rows;
        if (grouped) shown = list;
        $("#tmList").innerHTML = list.length ? `<div class="card tm-list">${list.map(x => {
          const head = grouped && x.c !== last ? `<div class="gl-letter">${CAT_IC[x.c] || ""} ${esc(x.c)}</div>` : ""; last = x.c;
          const lk = termLocked(x.t);
          return `${head}<button class="tm-row" data-open="${esc(x.t)}"><span class="tm-row-t"><strong>${hi(x.t, raw)}${sv.has(x.t) ? ` <span class="tm-star">★</span>` : ""}${lk ? ` <span class="lk-chip">🔒</span>` : ""}</strong>${x.a ? `<span class="gl-aka">${hi(x.a, raw)}</span>` : ""}${lk ? `<span class="lk-text" aria-hidden="true">${esc(Lock.scr(first(x.s)))}</span>` : `<span>${hi(first(x.s), raw)}</span>`}</span><span class="sh-chev">›</span></button>`;
        }).join("")}</div>`
          : `<div class="card empty">${onlySaved ? "No saved terms yet. Open a term and tap ☆ Save." : `No term matches "${esc(raw)}". It might be in the <button class="linkbtn" id="tmToDict">Dictionary</button>.`}</div>`;
        $$("[data-open]", app).forEach(b => b.onclick = () => openTermSheet(b.dataset.open, shown));
        const td = $("#tmToDict"); if (td) td.onclick = () => { go("glossary"); setTimeout(() => { const g = $("#glQ"); if (g) { g.value = raw; g.dispatchEvent(new Event("input")); } }, 400); };
      };
      window._termsRedraw = () => { drawCats(); draw(); };
      let tm; $("#tmQ").oninput = () => { clearTimeout(tm); tm = setTimeout(draw, 90); };
      drawCats(); draw();
    });
  };
})();
