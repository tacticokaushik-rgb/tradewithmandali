/* Mandali "Top 5 news right now": ranks the live headline feed by market importance, refreshes itself,
   and opens each story into a deep-dive: why it matters, live market reaction, who feels it, history,
   seasonality, what could neutralise it, recent developments and what to watch next. */
(function () {
  /* ---------- Theme playbooks (how each kind of news moves Indian markets) ---------- */
  // sectors: [name, direction when the news is POSITIVE for the market (+1/−1), strength 1–3]
  // inv: true when a "rise" in the headline is bad for Nifty (crude, inflation, yields, dollar)
  const TH = {
    rbi: { name: "RBI and interest rates", ic: "🏛️", w: 10, asset: null, data: "repo",
      re: /\bRBI\b|repo|MPC|monetary policy|rate cut|rate hike|Malhotra|CRR|liquidity|policy rate|bond yield|G-?sec|10-year (?:bond|yield)/i,
      why: "Interest rates set the price of money. A rate cut makes loans cheaper for companies and home buyers, lowers bond yields and makes shares more attractive than fixed deposits. A hike or a hawkish tone does the reverse. Banks, NBFCs, realty and autos react first because their business runs on borrowing.",
      sectors: [["Bank", 1, 3], ["Fin", 1, 3], ["Realty", 1, 3], ["Auto", 1, 2], ["PSU Bank", 1, 2], ["IT", 0, 1]],
      hist: [["4 May 2022", "Surprise off-cycle repo hike of 0.40%", -2.29, "Nifty fell about 2.3% the same afternoon; rate-sensitive stocks led the fall."],
        ["6 Jun 2025", "Big 0.50% repo cut plus a CRR cut", 1.02, "Banks and realty rallied; Nifty rose about 1%."],
        ["27 Mar 2020", "Emergency 0.75% cut during the Covid crash", null, "Markets stayed volatile: a rate cut can't stop a panic on its own."]],
      neut: ["Inflation coming in hotter than expected (it limits further cuts)", "A cautious or hawkish tone in the RBI commentary even after a cut", "Rising US bond yields that pull foreign money out anyway", "Banks not passing the cut on to borrowers"],
      watch: ["The next CPI inflation print", "10-year government bond yield", "Bank Nifty's reaction in the first hour", "RBI liquidity operations"] },
    inflation: { name: "Inflation", ic: "🏷️", w: 8, inv: true, asset: null, data: "cpi",
      re: /\bCPI\b|\bWPI\b|inflation|retail prices|food prices|price rise|core inflation/i,
      why: "Inflation decides what the RBI does next. Inflation below the 4% target leaves room for rate cuts, which markets like. Inflation above 6% forces the RBI to keep rates high, which squeezes company profits and consumer spending.",
      sectors: [["FMCG", 1, 2], ["Bank", 1, 2], ["Auto", 1, 2], ["Realty", 1, 2], ["Metal", -1, 1]],
      hist: [["2022", "CPI above 7% for months", null, "RBI raised the repo rate by 2.5% between May 2022 and Feb 2023, and Nifty went nowhere for a year."],
        ["Jul 2023", "Vegetable-led CPI spike to 7.4%", null, "Rate-cut hopes were pushed back; FMCG and rate-sensitive stocks lagged."]],
      neut: ["A good monsoon that cools food prices", "Falling crude oil prices", "A stronger rupee (cheaper imports)", "Government action on food supply (export bans, stock limits)"],
      watch: ["Food and vegetable prices", "Crude oil", "The RBI's next policy statement", "Core inflation (without food and fuel)"] },
    fii: { name: "FII flows", ic: "🌍", w: 8, asset: null, data: "flows",
      re: /\bFII|\bFPI|foreign (?:investor|fund|portfolio)|outflow|inflow|DII/i,
      why: "Foreign investors (FIIs) move the biggest money in Indian markets. Heavy FII selling pushes down large-cap stocks like HDFC Bank, Reliance and Infosys, which carry most of Nifty's weight. Domestic institutions (DIIs), funded by monthly SIPs, usually buy what FIIs sell.",
      sectors: [["Bank", 1, 3], ["Fin", 1, 2], ["IT", 1, 2], ["Energy", 1, 1], ["FMCG", 1, 1]],
      hist: [["Oct 2024", "Record FII selling in the cash market", -6.2, "Nifty fell about 6% that month, the start of a five-month correction."],
        ["2026 so far", "FIIs net sellers almost every month", null, "DII buying, from mutual fund SIPs, absorbed most of the selling."]],
      neut: ["Strong DII and SIP inflows", "A falling dollar or US bond yields", "Cheaper valuations attracting buyers back", "Large index-inclusion or block-deal inflows"],
      watch: ["Daily provisional FII/DII data (after 6 PM)", "FII long % in index futures", "USD/INR", "US 10-year yield"] },
    crude: { name: "Crude oil", ic: "🛢️", w: 7, inv: true, asset: "brent",
      re: /crude|\boil\b|Brent|OPEC|petrol|diesel|fuel price/i,
      why: "India imports over 80% of its oil. Costlier crude widens the trade deficit, weakens the rupee, raises inflation and squeezes companies that use oil as a raw material. Cheaper crude does the reverse and is one of the biggest tailwinds for Indian markets.",
      sectors: [["Oil & Gas", 1, 3], ["Auto", 1, 2], ["FMCG", 1, 1], ["Energy", -1, 2], ["Infra", 1, 1]],
      hist: [["7 Mar 2022", "Brent briefly near $139 after the invasion of Ukraine", -2.35, "Nifty fell over 2%; oil marketers, paints and airlines were hit hardest."],
        ["2014–15", "Crude halved from over $100", null, "A major tailwind: inflation and the deficit fell, and rates came down."]],
      neut: ["OPEC raising output", "A global slowdown cutting demand", "Government cutting fuel taxes", "A stronger rupee"],
      watch: ["Brent price", "USD/INR", "OMC stocks (BPCL, HPCL, IOC)", "Middle East news"] },
    rupee: { name: "Rupee and the dollar", ic: "💱", w: 6, inv: true, asset: "usdinr",
      re: /rupee|\bINR\b|dollar index|\bDXY\b|forex|currency/i,
      why: "A weaker rupee means FIIs lose money on currency even if stocks don't fall, so they tend to sell. It also makes imports like crude costlier. IT and pharma exporters earn in dollars and gain from a weaker rupee.",
      sectors: [["Bank", 1, 2], ["Oil & Gas", 1, 2], ["IT", -1, 2], ["Pharma", -1, 1], ["Auto", 1, 1]],
      hist: [["Aug 2013", "Taper tantrum: the rupee crashed to about 68.8", null, "One of the sharpest FII exits of the decade; banks fell hard."],
        ["2022", "Rupee slid from 74 to 83 as the US raised rates", null, "IT outperformed while importers struggled."]],
      neut: ["RBI selling dollars from reserves", "Falling crude", "Large FII inflows or index inclusion", "A weaker dollar globally"],
      watch: ["USD/INR level", "Dollar index", "RBI forex reserves (Friday data)", "FII flows"] },
    fed: { name: "US Fed and global rates", ic: "🇺🇸", w: 9, inv: false, asset: "us10y",
      re: /\bFed\b|FOMC|Powell|Federal Reserve|US yields?|Treasury|US inflation|US jobs|payrolls|US CPI/i,
      why: "The US Fed sets the world's most important interest rate. When US rates or bond yields rise, safe US assets pay more, and foreign money leaves emerging markets like India. Fed cuts usually bring money back.",
      sectors: [["IT", 1, 3], ["Bank", 1, 2], ["Realty", 1, 2], ["Metal", 1, 2], ["Fin", 1, 2]],
      hist: [["Aug 2013", "Taper tantrum: the Fed hinted at slowing bond buying", null, "Foreign money rushed out of India; the rupee and Nifty fell sharply."],
        ["Sep 2024", "Fed cut rates by 0.50%", null, "Nifty hit its record near 26,277 within a week, then turned lower as FIIs sold."]],
      neut: ["Strong domestic flows (SIPs)", "Indian growth outpacing the world", "A falling dollar"],
      watch: ["US 10-year yield", "Next FOMC meeting", "US CPI and jobs data", "Dollar index"] },
    tariff: { name: "Trade and tariffs", ic: "🚢", w: 8, asset: null,
      re: /tariff|trade deal|trade war|duties|\bduty\b|export|import ban|Trump|WTO|trade talks/i,
      why: "Tariffs make exports costlier and can slow global growth. Exporters (textiles, gems, chemicals, auto parts, IT services) are hit directly, and the uncertainty makes foreign investors cautious. Trade deals do the reverse.",
      sectors: [["IT", 1, 2], ["Auto", 1, 2], ["Pharma", 1, 2], ["Metal", 1, 2], ["FMCG", 0, 1]],
      hist: [["7 Apr 2025", "US 'reciprocal' tariffs announced", -3.24, "Nifty fell over 3% and India VIX jumped more than 50% in a day."],
        ["Late Aug 2025", "US tariffs on Indian goods raised to 50%", null, "Textile, gems and seafood exporters fell; Nifty's reaction was more measured."]],
      neut: ["A trade deal or exemptions", "Rupee weakness that offsets the tariff", "Other markets (EU, UK) opening up", "Government support for exporters"],
      watch: ["Trade talks headlines", "Exporter stocks", "USD/INR", "Global indices"] },
    geo: { name: "Geopolitics and war", ic: "⚔️", w: 9, asset: null,
      re: /\bwar\b|attack|missile|ceasefire|Israel|Iran|Pakistan|Ukraine|Russia|border|military|strike on|conflict|sanction/i,
      why: "Conflict raises uncertainty, crude prices and fear (India VIX). Markets usually fall sharply on the first shock, then recover once the worst-case scenario is ruled out. Peace news can spark big relief rallies.",
      sectors: [["Oil & Gas", 1, 2], ["Bank", 1, 2], ["Auto", 1, 1], ["Infra", 1, 1], ["Metal", 1, 1]],
      hist: [["24 Feb 2022", "Russia invades Ukraine", -4.78, "Nifty fell nearly 5% in a day, then recovered over the next weeks."],
        ["7 May 2025", "Operation Sindoor", 0.14, "Nifty barely moved: the market had expected a measured response."],
        ["12 May 2025", "India–Pakistan ceasefire", 3.82, "Relief rally: Nifty jumped about 3.8%, its biggest gain in four years."]],
      neut: ["Talks or a ceasefire", "Crude falling back", "Strong domestic buying on the dip"],
      watch: ["India VIX", "Brent crude", "Defence stocks", "GIFT Nifty overnight"] },
    results: { name: "Company results", ic: "📊", w: 6, asset: null,
      re: /\bQ[1-4]\b|results|net profit|earnings|revenue|guidance|EBITDA|quarter|beats estimates|misses estimates/i,
      why: "Share prices follow earnings. Results from heavyweights move Nifty directly: HDFC Bank, Reliance, ICICI Bank, Infosys and TCS alone make up over a third of the index. Management guidance about the next quarters often matters more than the past quarter's numbers.",
      sectors: [["IT", 1, 3], ["Bank", 1, 3], ["FMCG", 1, 2], ["Auto", 1, 2], ["Energy", 1, 2]],
      hist: [["Every results season", "Heavyweight surprises", null, "A big miss in a heavyweight can drag Nifty 0.5–1% on its own, even when the rest of the market is fine."]],
      neut: ["Strong guidance despite a weak quarter", "Results already priced in (the stock had run up)", "Sector peers reporting the opposite"],
      watch: ["Which heavyweights report this week", "Management commentary on demand", "Sector index reaction"] },
    gdp: { name: "Economy and growth data", ic: "🌾", w: 6, asset: null, data: "gdp",
      re: /\bGDP\b|\bIIP\b|\bPMI\b|GST collection|core sector|industrial output|trade deficit|current account|fiscal deficit|growth forecast/i,
      why: "Growth data shows whether companies will earn more. Faster GDP, rising PMI and strong GST collections point to better earnings ahead. A slowdown makes markets nervous, especially when valuations are high.",
      sectors: [["Bank", 1, 2], ["Infra", 1, 2], ["Auto", 1, 2], ["Metal", 1, 2], ["FMCG", 1, 1]],
      hist: [["Aug 2026", "Q1 FY27 GDP at 7.8%", null, "Strong growth supported banks and capital goods."]],
      neut: ["Strong growth also raising inflation fears", "Global slowdown headlines"],
      watch: ["Monthly PMI data", "GST collections (1st of the month)", "Next GDP release"] },
    budget: { name: "Budget, tax and policy", ic: "🧾", w: 8, asset: null, data: "budget",
      re: /budget|\bGST\b|income tax|tax cut|capital gains|\bSTT\b|fiscal|disinvestment|PLI|government spending|capex/i,
      why: "Government policy changes what companies earn and what investors keep. Tax cuts and higher capital spending lift profits and sentiment; higher taxes on investors (like capital gains or STT) can trigger selling.",
      sectors: [["Infra", 1, 3], ["Auto", 1, 2], ["FMCG", 1, 2], ["Bank", 1, 2], ["Realty", 1, 1]],
      hist: [["20 Sep 2019", "Surprise corporate tax cut", 5.32, "Nifty jumped about 5.3% in a single day."],
        ["1 Feb 2021", "Growth-focused Union Budget", 4.74, "Nifty rose about 4.7% on Budget day."],
        ["Sep 2025", "GST rate cuts on cars and daily goods", null, "Auto and FMCG stocks rallied on hopes of stronger demand."]],
      neut: ["Higher taxes on investors elsewhere in the same policy", "A wider fiscal deficit pushing up bond yields", "Slow implementation"],
      watch: ["Details and dates of implementation", "Sector index reaction", "Bond yields"] },
    sebi: { name: "SEBI and market rules", ic: "⚖️", w: 6, asset: null,
      re: /\bSEBI\b|F&O|derivatives? (?:rules|curbs|framework)|weekly expir|lot size|margin rules|insider|front[- ]running/i,
      why: "SEBI's rules shape how traders can trade. Changes to F&O rules (expiries, lot sizes, margins) change volumes, option premiums and broker earnings. Enforcement action against big players can change how the market moves near expiry.",
      sectors: [["Fin", 1, 2], ["Bank", 0, 1]],
      hist: [["Nov 2024", "F&O curbs: one weekly expiry per exchange, bigger lots", null, "Option volumes fell sharply; broker and exchange stocks reacted most."],
        ["Jul 2025", "SEBI order against Jane Street", null, "Expiry-day option volumes and premiums changed in the following weeks."]],
      neut: ["Phased implementation", "Consultation leading to softer final rules"],
      watch: ["Effective dates", "Exchange and broker stocks", "Option volumes and premiums"] },
    global: { name: "Global markets", ic: "🌐", w: 7, asset: null,
      re: /Wall Street|Nasdaq|Dow|S&P 500|Nikkei|Hang Seng|global (?:markets|sell-off|rally)|Asian markets|China|recession|yen/i,
      why: "Indian markets don't move alone. A big sell-off in the US or Asia usually leads to a gap-down in Nifty the next morning, visible first in GIFT Nifty. Global rallies help the same way.",
      sectors: [["IT", 1, 3], ["Metal", 1, 3], ["Bank", 1, 2], ["Auto", 1, 1]],
      hist: [["5 Aug 2024", "Global sell-off (yen carry trade unwind)", -2.68, "Japan's Nikkei fell 12%; Nifty fell about 2.7%."],
        ["Mar 2020", "Global Covid crash", -12.98, "Nifty's worst day in decades, on 23 March 2020."]],
      neut: ["Strong domestic flows", "Indian growth outpacing the world", "A quick rebound overnight in the US"],
      watch: ["GIFT Nifty", "US futures", "Asian markets at 9 AM", "Dollar index"] },
    ipo: { name: "IPOs and fundraising", ic: "🔔", w: 3, asset: null,
      re: /\bIPO\b|listing|\bQIP\b|\bOFS\b|block deal|stake sale|fundraise|anchor investors/i,
      why: "Big IPOs and stake sales soak up money that would otherwise go into listed stocks. A crowded IPO calendar can weigh on the market; strong listings signal healthy risk appetite.",
      sectors: [["Fin", 1, 1]],
      hist: [["Oct 2024", "Hyundai India's ₹27,870 Cr IPO, India's largest", null, "Came near the market top, as supply of new shares peaked."]],
      neut: ["Strong inflows from mutual funds", "IPOs spread out over time"],
      watch: ["IPO subscription numbers", "Listing-day gains", "Block deals in heavyweights"] },
    monsoon: { name: "Monsoon and agriculture", ic: "🌧️", w: 4, asset: null,
      re: /monsoon|rainfall|\bIMD\b|kharif|rabi|sowing|drought|El Ni/i,
      why: "Around half of India's workforce depends on farming. A good monsoon lifts rural incomes and spending, and keeps food inflation low. A weak monsoon does the opposite.",
      sectors: [["FMCG", 1, 3], ["Auto", 1, 2], ["Infra", 0, 1]],
      hist: [["2023", "El Niño and a dry August", null, "Food inflation spiked; CPI touched 7.4% in July 2023."]],
      neut: ["Good reservoir levels", "Government food stocks"],
      watch: ["IMD weekly rainfall", "Sowing data", "Tractor and two-wheeler sales"] },
    gold: { name: "Gold and commodities", ic: "🥇", w: 3, asset: null,
      re: /\bgold\b|silver|copper|aluminium|steel prices|commodit|iron ore/i,
      why: "Rising gold often signals fear or a weaker dollar. Metal prices drive metal stocks directly and, through costs, affect autos and capital goods.",
      sectors: [["Metal", 1, 3], ["Auto", -1, 1]],
      hist: [["2025", "Gold hit repeated record highs", null, "Investors moved money into safe havens amid tariff and war uncertainty."]],
      neut: ["A stronger dollar", "Calmer geopolitics"],
      watch: ["Gold and silver prices", "Metal index", "Dollar index"] },
    general: { name: "Market news", ic: "📰", w: 2, asset: null, re: /./,
      why: "A general market story. It matters most for the stocks or sectors it names; check whether the move spreads to the wider index.",
      sectors: [], hist: [], neut: ["Broad market strength or weakness overriding the story"], watch: ["Nifty and the sector index named in the story"] }
  };
  const ORDER = ["rbi", "fed", "geo", "budget", "tariff", "fii", "inflation", "crude", "global", "rupee", "gdp", "sebi", "results", "monsoon", "gold", "ipo", "general"];
  const UP = /\b(rise|rises|rising|rose|surge|surges|jump|jumps|jumped|rally|rallies|gain|gains|climb|soar|record high|high|hike|hikes|up|higher|beats|strong|boost|inflow|inflows|buying|bought|cut taxes|eases|easing|cut|cuts|deal|ceasefire|peace|recovers|rebound)\b/gi;
  const DOWN = /\b(fall|falls|falling|fell|slump|slumps|drop|drops|dropped|plunge|plunges|crash|crashes|slide|slides|slip|slips|dip|dips|sink|sinks|tumble|tumbles|decline|declines|lower|low|weak|weakens|misses|outflow|outflows|pull out|pulls out|withdraw|selling|sold|war|attack|tariff|tariffs|sanction|fears?|concern|worries|recession|loss|losses|down)\b/gi;
  const BIG = /\b(record|biggest|crash|plunge|surge|emergency|unexpected|surprise|historic|sharp|steep|tumble|soar|massive|worst|best)\b/i;

  // The story's subject usually comes first, so pick the theme whose keyword appears earliest in the headline.
  const themeOf = (title) => { let best = "general", at = Infinity;
    for (const k of ORDER) { if (k === "general") continue; const m = title.match(TH[k].re); if (m && m.index < at) { at = m.index; best = k; } }
    return best; };
  function toneOf(k, title) {
    const u = (title.match(UP) || []).length, d = (title.match(DOWN) || []).length;
    let s = u - d;
    if (k === "rbi" && /\bcut/i.test(title)) s += 2; if (k === "rbi" && /\bhike/i.test(title)) s -= 3;
    if (k === "fii" && /sell|outflow|pull(?:s|ed)? out|withdr/i.test(title)) s = -2; if (k === "fii" && /buy|inflow|pump|invest/i.test(title) && !/sell|outflow|pull(?:s|ed)? out|withdr/i.test(title)) s = 2;
    if (TH[k].inv && /rise|rises|rising|rose|jump|surge|climb|higher|soar|spike|hot|\bups\b|raises|hikes? (?:its )?forecast|to \$\d/i.test(title)) s = -2;
    if (TH[k].inv && /fall|falls|fell|drop|slide|eases|cool|lower|soft/i.test(title)) s = 2;
    if (k === "rupee" && /weak|falls|fell|slips|slides|dips|record low|depreciat/i.test(title)) s = -2;
    if (k === "rupee" && /strengthens|gains|rises|recovers|appreciat/i.test(title) && !/weak|falls|fell|slips|slides|dips/i.test(title)) s = 2;
    if (k === "geo" && /ceasefire|peace|talks|truce|war[’']?s end|end (?:of|to) (?:the )?war|de-?escalat|calm/i.test(title)) s = 2;
    if (k === "rbi") { const hawk = /yields? (?:hits?|rises?|climbs?|jumps?|surges?|spikes?|at) .*?(?:high|peak)|yields? (?:rise|rises|climb|climbs|jump|jumps|surge|spike)|hawkish|tight(?:er|ening)? liquidity|liquidity (?:deficit|crunch|tight)|rate hike|hikes? (?:repo|rates?)/i.test(title);
      const dove = /rate cut|cuts? (?:repo|rates?)|dovish|yields? (?:fall|falls|ease|eases|drop|drops|slide)|liquidity (?:surplus|infusion|boost)|eases? liquidity/i.test(title);
      s = hawk ? -2 : dove ? 2 : s; }
    if (k === "fed") { const hawk = /hawkish|patience|higher for longer|on hold|pause|yields? (?:rise|rises|climb|climbs|jump|jumps|surge|spike|hit)|hot(?:ter)? inflation|strong jobs/i.test(title);
      const dove = /dovish|cuts? rates|rate cut|yields? (?:fall|falls|ease|eases|drop|drops|slide)|cooling inflation|weak jobs/i.test(title);
      s = hawk ? -2 : dove ? 2 : s; }
    return s > 0 ? 1 : s < 0 ? -1 : 0;
  }
  const ageH = (iso) => iso ? (Date.now() - new Date(iso)) / 3600000 : 24;
  function rank(items) {
    const JUNK = /share price live|live updates?:|stock price today|price live blog|stocks to watch|top gainers|top losers|buy or sell|stocks? to buy|share price today/i;
    const seenT = new Set(), scored = (items || []).filter(n => n && n.title && ageH(n.published) < 36 && !JUNK.test(n.title)).map(n => {
      const k = themeOf(n.title), a = ageH(n.published);
      const score = TH[k].w * 6 + (a < 1 ? 22 : a < 3 ? 16 : a < 8 ? 9 : a < 16 ? 4 : 0) + (BIG.test(n.title) ? 10 : 0) + ((n.tags || []).includes("nifty") ? 6 : 0) + ((n.tags || []).includes("economy") ? 4 : 0);
      return { ...n, k, tone: toneOf(k, n.title), score };
    }).sort((a, b) => b.score - a.score);
    // de-duplicate near-identical headlines, keep themes diverse
    const out = [], norm = (s) => s.toLowerCase().replace(/[^a-z0-9 ]/g, "").split(" ").filter(w => w.length > 3);
    for (const n of scored) {
      const w = new Set(norm(n.title));
      if (out.some(o => { const ow = norm(o.title); const same = ow.filter(x => w.has(x)).length; return same >= Math.min(4, Math.max(2, ow.length * 0.5)); })) continue;
      if (seenT.has(n.k) && n.k !== "general" && out.length < 5 && scored.filter(x => !seenT.has(x.k)).length) { continue; }
      out.push(n); seenT.add(n.k); if (out.length === 5) break;
    }
    if (out.length < 5) for (const n of scored) { if (out.length >= 5) break; if (!out.includes(n) && !out.some(o => o.title === n.title)) out.push(n); }
    return { top: out.slice(0, 5), all: scored };
  }
  const impact = (n) => Math.max(20, Math.min(98, Math.round(n.score)));

  /* ---------- Live feed ---------- */
  let pulse = null, pulseAt = 0, pTimer = null, busy = false;
  async function fetchNews(force) {
    if (busy) return;
    if (!force && typeof newsCache !== "undefined" && newsCache && Date.now() - newsCache.at < 120000) { pulse = rank(newsCache.items); pulseAt = newsCache.at; return; }
    busy = true;
    try {
      const { data } = await sb.functions.invoke("Market-news-");
      if (data && Array.isArray(data.items)) { pulse = rank(data.items); pulseAt = Date.now(); try { if (typeof newsCache !== "undefined") newsCache = { at: Date.now(), items: data.items }; } catch (e) {} }
    } catch (e) { /* keep last */ } finally { busy = false; }
  }
  const ago = (iso) => { if (!iso) return ""; const m = Math.round((Date.now() - new Date(iso)) / 60000); return m < 1 ? "just now" : m < 60 ? m + " min ago" : Math.round(m / 60) + " hr ago"; };
  const toneLbl = (t0) => t0 > 0 ? ["Positive", "up"] : t0 < 0 ? ["Negative", "down"] : ["Mixed", "flat"];

  window.newsPulseHtml = () => `<section class="card np" id="npCard" aria-label="Top 5 news right now">
      <div class="np-head"><div><p class="np-k"><span class="np-live"></span>${t("Top 5 news right now")}</p><p class="np-sub" id="npSub">Ranked by how much they can move Nifty</p></div>
        <button type="button" class="linkbtn" data-sec="news">All news ›</button></div>
      <ol class="np-list" id="npList">${[0, 1, 2, 3, 4].map(i => `<li class="np-row sk"><span class="np-n">${i + 1}</span><span class="np-t"><i></i><i></i></span></li>`).join("")}</ol></section>
    <section class="card np-about" id="npAbout" aria-live="polite" hidden></section>`;
  let npSel = 0, npSelTitle = "";
  function drawAbout(scroll) {
    const box = $("#npAbout"); if (!box || !pulse || !pulse.top.length) { if (box) box.hidden = true; return; }
    let i = npSelTitle ? pulse.top.findIndex(x => x.title === npSelTitle) : npSel; if (i < 0) i = 0;
    npSel = i; const n = pulse.top[i], th = TH[n.k]; npSelTitle = n.title;
    box.hidden = false;
    box.innerHTML = `<div class="npa-head"><p class="np-k">${t("All about it")}</p>
        <div class="npa-tabs" role="tablist">${pulse.top.map((x, j) => `<button type="button" role="tab" class="npa-tab${j === i ? " on" : ""}" data-npa="${j}" aria-selected="${j === i}" aria-label="News ${j + 1}">${j + 1}</button>`).join("")}</div></div>
      <p class="npa-theme">${th.ic} ${esc(th.name)} · ${esc(n.source || "")}${n.published ? " · " + ago(n.published) : ""}</p>
      ${newsBody(n)}`;
    $$("[data-npa]", box).forEach(b => b.onclick = () => select(+b.dataset.npa, false));
    if (scroll) box.scrollIntoView({ behavior: matchMedia("(prefers-reduced-motion: reduce)").matches ? "auto" : "smooth", block: "start" });
  }
  function select(i, scroll) {
    npSel = i; npSelTitle = pulse.top[i] ? pulse.top[i].title : "";
    $$("#npList [data-np]").forEach(b => b.classList.toggle("on", +b.dataset.np === i));
    drawAbout(scroll);
  }
  function drawCard() {
    const ul = $("#npList"); if (!ul) return;
    if (!pulse || !pulse.top.length) { ul.innerHTML = `<li class="np-empty muted small">Headlines couldn't load right now. Pull down to refresh.</li>`; return; }
    ul.innerHTML = pulse.top.map((n, i) => { const th = TH[n.k], tl = toneLbl(n.tone);
      return `<li><button type="button" class="np-row" data-np="${i}"><span class="np-n">${i + 1}</span>
        <span class="np-t"><strong>${esc(n.title)}</strong><span class="np-meta"><em class="np-th">${th.ic} ${esc(th.name)}</em><em class="np-tone ${tl[1]}">${tl[0]}</em><span>${esc(n.source || "")}${n.published ? " · " + ago(n.published) : ""}</span></span></span>
        <span class="np-imp" title="Market impact score"><b>${impact(n)}</b><i style="--v:${impact(n)}%"></i></span></button></li>`; }).join("");
    const sub = $("#npSub"); if (sub) sub.textContent = `Ranked by how much they can move Nifty · updated ${new Date(pulseAt).toLocaleTimeString("en-IN", { timeZone: "Asia/Kolkata", hour: "numeric", minute: "2-digit" })}`;
    $$("[data-np]", ul).forEach(b => b.onclick = () => select(+b.dataset.np, true));
    const cur = npSelTitle ? pulse.top.findIndex(x => x.title === npSelTitle) : npSel;
    $$("[data-np]", ul).forEach(b => b.classList.toggle("on", +b.dataset.np === (cur < 0 ? 0 : cur)));
    drawAbout(false);
    const card = $("#npCard"); if (card) $$("[data-sec]", card).forEach(b => b.onclick = () => go(b.dataset.sec));
  }
  window.mountNewsPulse = async () => {
    clearInterval(pTimer);
    if (!$("#npCard")) return;
    if (pulse) drawCard();
    await fetchNews(!pulse || Date.now() - pulseAt > 180000); drawCard();
    pTimer = setInterval(async () => {
      if (!$("#npCard")) { clearInterval(pTimer); return; }
      if (document.hidden) return;
      const live = typeof nfMarketLive === "function" && nfMarketLive();
      if (Date.now() - pulseAt > (live ? 180000 : 600000)) { await fetchNews(true); drawCard(); }
    }, 60000);
  };

  /* ---------- Charts (SVG, theme colours via CSS classes) ---------- */
  const sp = (v, k = 2) => (v >= 0 ? "+" : "−") + nfNum(Math.abs(v), k);
  function gauge(v, tone) {
    const a = Math.PI * (1 - v / 100), x = 60 + 46 * Math.cos(a), y = 58 - 46 * Math.sin(a);
    return `<svg class="ch-gauge" viewBox="0 0 120 70" role="img" aria-label="Impact ${v} of 100">
      <path d="M14 58 A46 46 0 0 1 106 58" class="g-bg"/><path d="M14 58 A46 46 0 0 1 ${x.toFixed(1)} ${y.toFixed(1)}" class="g-fg ${tone}"/>
      <text x="60" y="54" text-anchor="middle" class="g-v">${v}</text><text x="60" y="67" text-anchor="middle" class="g-l">impact</text></svg>`;
  }
  function lineChart(vals, opts = {}) {
    if (!vals || vals.length < 2) return "";
    const W = 320, H = opts.h || 120, P = 6, mn = Math.min(...vals), mx = Math.max(...vals), r = mx - mn || 1;
    const X = (i) => P + (W - 2 * P) * i / (vals.length - 1), Y = (v) => P + (H - 22 - P) * (mx - v) / r;
    const d = vals.map((v, i) => (i ? "L" : "M") + X(i).toFixed(1) + " " + Y(v).toFixed(1)).join(" ");
    const up = vals[vals.length - 1] >= vals[0], id = "l" + Math.random().toString(36).slice(2, 7);
    const grid = [0.25, 0.5, 0.75].map(f => `<line x1="${P}" x2="${W - P}" y1="${(P + (H - 22 - P) * f).toFixed(1)}" y2="${(P + (H - 22 - P) * f).toFixed(1)}" class="c-grid"/>`).join("");
    return `<svg class="ch-line ${opts.cls || (up ? "up" : "down")}" viewBox="0 0 ${W} ${H}" role="img" aria-label="${esc(opts.label || "Chart")}">
      <defs><linearGradient id="${id}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="currentColor" stop-opacity=".25"/><stop offset="1" stop-color="currentColor" stop-opacity="0"/></linearGradient></defs>${grid}
      <path d="${d} L${X(vals.length - 1).toFixed(1)} ${H - 22} L${P} ${H - 22} Z" fill="url(#${id})"/><path d="${d}" class="c-ln"/>
      <circle cx="${X(vals.length - 1).toFixed(1)}" cy="${Y(vals[vals.length - 1]).toFixed(1)}" r="3.4" class="c-dot"/>
      <text x="${P}" y="${H - 6}" class="c-tx">${esc(opts.left || "")}</text><text x="${W - P}" y="${H - 6}" class="c-tx" text-anchor="end">${esc(opts.right || "")}</text>
      <text x="${W - P}" y="${(Y(mx) + 10).toFixed(1)}" class="c-tx" text-anchor="end">${esc(opts.fmt ? opts.fmt(mx) : nfNum(mx, 2))}</text><text x="${W - P}" y="${(Y(mn) - 3).toFixed(1)}" class="c-tx" text-anchor="end">${esc(opts.fmt ? opts.fmt(mn) : nfNum(mn, 2))}</text></svg>`;
  }
  function bars(rows, opts = {}) { // rows: [label, value, highlight?]
    if (!rows.length) return "";
    const W = 320, rowH = opts.rowH || 22, H = rows.length * rowH + 8, lab = opts.labW || 96, mx = Math.max(...rows.map(r => Math.abs(r[1])), 0.01);
    const mid = opts.signed === false ? lab : lab + (W - lab - 46) / 2, span = opts.signed === false ? W - lab - 46 : (W - lab - 46) / 2;
    return `<svg class="ch-bars" viewBox="0 0 ${W} ${H}" role="img" aria-label="${esc(opts.label || "Bar chart")}">
      ${opts.signed === false ? "" : `<line x1="${mid}" x2="${mid}" y1="2" y2="${H - 4}" class="c-axis"/>`}
      ${rows.map(([l, v, hl], i) => { const y = 4 + i * rowH, w = Math.max(1.5, Math.abs(v) / mx * span), x = v >= 0 ? mid : mid - w;
        return `<text x="${lab - 6}" y="${y + rowH / 2 + 4}" text-anchor="end" class="c-lb${hl ? " hl" : ""}">${esc(l)}</text>
          <rect x="${x.toFixed(1)}" y="${y + 4}" width="${w.toFixed(1)}" height="${rowH - 9}" rx="3" class="c-bar ${v >= 0 ? "up" : "down"}${hl ? " hl" : ""}" style="--d:${i * 40}ms"/>
          <text x="${W - 2}" y="${y + rowH / 2 + 4}" text-anchor="end" class="c-vl ${v >= 0 ? "up" : "down"}">${esc(opts.fmt ? opts.fmt(v) : sp(v))}</text>`; }).join("")}</svg>`;
  }
  function columns(labels, vals, opts = {}) {
    const W = 320, H = (opts.h || 150) + 12, P = 4, PT = 18, base = H - 20, mx = Math.max(...vals.map(Math.abs), 0.01), hasNeg = vals.some(v => v < 0);
    const zero = hasNeg ? PT + (base - PT - 12) / 2 : base, scale = (hasNeg ? (base - PT - 12) / 2 : base - PT) / mx, bw = (W - 2 * P) / vals.length;
    return `<svg class="ch-cols" viewBox="0 0 ${W} ${H}" role="img" aria-label="${esc(opts.label || "Column chart")}">
      <line x1="${P}" x2="${W - P}" y1="${zero}" y2="${zero}" class="c-axis"/>
      ${vals.map((v, i) => { const h = Math.max(1, Math.abs(v) * scale), x = P + i * bw + bw * 0.16, y = v >= 0 ? zero - h : zero, hl = opts.hl === i;
        return `<rect x="${x.toFixed(1)}" y="${y.toFixed(1)}" width="${(bw * 0.68).toFixed(1)}" height="${h.toFixed(1)}" rx="2" class="c-bar ${opts.mono ? "mono" : v >= 0 ? "up" : "down"}${hl ? " hl" : ""}" style="--d:${i * 30}ms"/>
          ${opts.vals ? `<text x="${(x + bw * 0.34).toFixed(1)}" y="${(v >= 0 ? y - 3 : y + h + 9).toFixed(1)}" text-anchor="middle" class="c-vs${hl ? " hl" : ""}">${esc(opts.vals(v))}</text>` : ""}
          <text x="${(x + bw * 0.34).toFixed(1)}" y="${H - 6}" text-anchor="middle" class="c-tx${hl ? " hl" : ""}">${esc(labels[i])}</text>`; }).join("")}</svg>`;
  }
  function hist(rets, today) {
    const bins = [], lo = -3, hi = 3, step = 0.25; for (let x = lo; x < hi; x += step) bins.push([x, 0]);
    rets.forEach(r => { const c = Math.max(lo, Math.min(hi - 0.0001, r)); bins[Math.floor((c - lo) / step)][1]++; });
    const W = 320, H = 140, P = 4, base = H - 22, mx = Math.max(...bins.map(b => b[1]), 1), bw = (W - 2 * P) / bins.length;
    const ti = Math.floor((Math.max(lo, Math.min(hi - 0.0001, today)) - lo) / step);
    return `<svg class="ch-cols" viewBox="0 0 ${W} ${H}" role="img" aria-label="Histogram of daily moves">
      ${bins.map(([x, c], i) => { const h = c / mx * (base - P - 10); return `<rect x="${(P + i * bw + 1).toFixed(1)}" y="${(base - h).toFixed(1)}" width="${(bw - 2).toFixed(1)}" height="${Math.max(0.5, h).toFixed(1)}" rx="1.5" class="c-bar ${i === ti ? "hl today" : x < 0 ? "down soft" : "up soft"}" style="--d:${i * 15}ms"/>`; }).join("")}
      <line x1="${P}" x2="${W - P}" y1="${base}" y2="${base}" class="c-axis"/>
      ${[-3, -2, -1, 0, 1, 2, 3].map(v => `<text x="${(P + (v - lo) / (hi - lo) * (W - 2 * P)).toFixed(1)}" y="${H - 6}" text-anchor="middle" class="c-tx">${v > 0 ? "+" : ""}${v}%</text>`).join("")}
      <text x="${(P + ti * bw + bw / 2).toFixed(1)}" y="${(base - (bins[ti][1] / mx) * (base - P - 10) - 4).toFixed(1)}" text-anchor="middle" class="c-vs hl">today</text></svg>`;
  }
  function donut(parts) { // [label, value, cls]
    const tot = parts.reduce((a, p) => a + p[1], 0) || 1, R = 46, C = 2 * Math.PI * R; let off = 0;
    return `<div class="ch-donut"><svg viewBox="0 0 120 120" role="img" aria-label="News mix"><circle cx="60" cy="60" r="${R}" class="d-bg"/>
      ${parts.map((p, i) => { const len = p[1] / tot * C, s = `<circle cx="60" cy="60" r="${R}" class="d-seg s${i % 6}" stroke-dasharray="${len.toFixed(2)} ${(C - len).toFixed(2)}" stroke-dashoffset="${(-off).toFixed(2)}" transform="rotate(-90 60 60)"/>`; off += len; return s; }).join("")}
      <text x="60" y="58" text-anchor="middle" class="g-v">${tot}</text><text x="60" y="72" text-anchor="middle" class="g-l">headlines</text></svg>
      <ul>${parts.map((p, i) => `<li><i class="s${i % 6}"></i>${esc(p[0])}<b>${Math.round(p[1] / tot * 100)}%</b></li>`).join("")}</ul></div>`;
  }
  // Isometric 3D bars: how strongly each sector usually reacts
  function iso3d(rows, tone) {
    if (!rows.length) return "";
    const W = 330, H = 190, n = rows.length, gap = W / (n + 0.6), bw = Math.min(30, gap * 0.55), dx = bw * 0.55, dy = bw * 0.3, base = H - 40;
    return `<svg class="ch-iso" viewBox="0 0 ${W} ${H}" role="img" aria-label="Typical sector sensitivity">
      <path d="M8 ${base + 4} L${W - 30} ${base + 4} L${W - 30 + dx} ${base + 4 - dy} L${8 + dx} ${base + 4 - dy} Z" class="iso-floor"/>
      ${rows.map(([s, dir, str], i) => { const eff = dir * (tone || 1), h = 18 + str * 34, x = 18 + i * gap, y = base - h, c = eff > 0 ? "up" : eff < 0 ? "down" : "flat";
        return `<g class="iso-b ${c}" style="--d:${i * 70}ms">
          <path d="M${x} ${base} L${x} ${y} L${x + bw} ${y} L${x + bw} ${base} Z" class="f-front"/>
          <path d="M${x + bw} ${base} L${x + bw} ${y} L${x + bw + dx} ${y - dy} L${x + bw + dx} ${base - dy} Z" class="f-side"/>
          <path d="M${x} ${y} L${x + dx} ${y - dy} L${x + bw + dx} ${y - dy} L${x + bw} ${y} Z" class="f-top"/>
          <text x="${x + bw / 2 + dx / 2}" y="${y - dy - 6}" text-anchor="middle" class="c-vs">${eff > 0 ? "▲" : eff < 0 ? "▼" : "•"}${"●".repeat(str)}</text>
          <text x="${x + bw / 2}" y="${base + 20}" text-anchor="middle" class="c-tx">${esc(s)}</text></g>`; }).join("")}</svg>`;
  }

  /* ---------- Live market helpers ---------- */
  const SEC_MATCH = { "Bank": /^(?!.*psu)(?!.*private).*\bbank\b/i, "PSU Bank": /psu/i, "Fin": /fin/i, "IT": /\bit\b/i, "Auto": /auto/i, "Pharma": /pharma/i, "FMCG": /fmcg/i, "Metal": /metal/i, "Realty": /realty/i, "Energy": /energy/i, "Oil & Gas": /oil|energy/i, "Media": /media/i, "Infra": /infra/i };
  function sectorsToday() {
    const out = [];
    const br = typeof nfExt !== "undefined" && nfExt && nfExt.br && nfExt.br.sectors;
    if (br && br.length) br.forEach(s => out.push([s.name, s.pct]));
    else if (typeof mbData !== "undefined" && mbData && mbData.indices) mbData.indices.filter(i => i.price && i.prevClose && i.key !== "NIFTY 50").forEach(i => out.push([String(i.label).replace(/^nifty\s+/i, "").replace(/\s+nifty$/i, ""), (i.price - i.prevClose) / i.prevClose * 100]));
    return out;
  }
  const niftyNow = () => { try { const q = nfData && nfData.nifty; return q && q.price && q.prevClose ? { price: q.price, pct: (q.price - q.prevClose) / q.prevClose * 100 } : null; } catch (e) { return null; } };
  const dailyRets = () => { try { const d = (nfExt && nfExt.br && nfExt.br.daily && nfExt.br.daily.length > (nfData.daily || []).length) ? nfExt.br.daily : nfData.daily; const r = []; for (let i = 1; i < d.length; i++) r.push((d[i][4] - d[i - 1][4]) / d[i - 1][4] * 100); return r; } catch (e) { return []; } };

  /* ---------- Deep-dive sheet ---------- */
  function newsBody(n) {
    const th = TH[n.k], tl = toneLbl(n.tone), imp = impact(n), seen = new Set(), mt = (s) => markTerms(s, seen);
    const pro = typeof isPro !== "function" || isPro();
    const nn = niftyNow(), secs = sectorsToday(), I = window.INSIGHTS || {};
    const related = (pulse ? pulse.all : []).filter(x => x.k === n.k && x.title !== n.title).slice(0, 6);
    const mix = (() => { const m = new Map(); (pulse ? pulse.all : []).forEach(x => m.set(x.k, (m.get(x.k) || 0) + 1)); return [...m.entries()].sort((a, b) => b[1] - a[1]).slice(0, 6).map(([k, c]) => [TH[k].name, c]); })();
    const S = (title, body, cls = "") => body ? `<section class="nd-sec ${cls}"><p class="nd-h">${title}</p>${body}</section>` : "";

    // live reaction
    const secKeys = th.sectors.map(s => s[0]);
    const secRows = secs.map(([l, v]) => [l, v, secKeys.some(k => SEC_MATCH[k] && SEC_MATCH[k].test(l))]).sort((a, b) => b[1] - a[1]).slice(0, 12);
    const intra = (typeof nfIntra !== "undefined" && nfIntra) ? nfIntra.map(c => c[4]) : null;
    const g = typeof gtData !== "undefined" && gtData && th.asset ? gtData[th.asset] : null;
    const assetFmt = th.asset === "us10y" ? (v) => nfNum(v, 2) + "%" : th.asset === "usdinr" ? (v) => "₹" + nfNum(v, 2) : (v) => "$" + nfNum(v, 2);
    const assetName = { us10y: "US 10-year yield", usdinr: "USD/INR", brent: "Brent crude" }[th.asset];

    // theme data chart from Mandali Insights
    let dataChart = "";
    if (th.data === "repo" && I.repo) { const r = I.repo; dataChart = S("The repo rate over the years", lineChart(r.rate, { cls: "gold", left: r.dates[0], right: r.dates[r.dates.length - 1], fmt: v => nfNum(v, 2) + "%", label: "Repo rate history", h: 130 }) + `<p class="nd-cap">Now ${nfNum(r.rate[r.rate.length - 1], 2)}%. Source: ${esc(r.source)}.</p>`); }
    if (th.data === "cpi" && I.cpi) { const c = I.cpi; dataChart = S("CPI inflation by year (RBI target 4%)", columns(c.years.map(y => "'" + y.slice(2)), c.rate, { mono: true, vals: v => nfNum(v, 1), label: "CPI by year", hl: c.rate.length - 1 }) + `<p class="nd-cap">Latest: ${c.latest.map(([m, v]) => `${esc(m)} ${v}%`).join(" · ")}.</p>`); }
    if (th.data === "flows" && I.flows) { const f = I.flows; dataChart = S("FII vs DII, 2026 (₹ crore)", bars(f.months.flatMap((m, i) => [[m + " FII", f.fii[i]], [m + " DII", f.dii[i]]]), { fmt: v => (v >= 0 ? "+" : "−") + nfNum(Math.abs(v) / 1000, 0) + "k", label: "FII and DII flows", rowH: 17, labW: 70 }) + `<p class="nd-cap">${esc(f.note)}</p>`); }
    if (th.data === "budget" && I.budget) { const b = I.budget; dataChart = S("Nifty on Budget day", columns(b.years.map(y => "'" + y.slice(2)), b.ret, { vals: v => sp(v, 1), label: "Budget day returns" })); }
    if (th.data === "gdp" && I.gdp) dataChart = S("Latest growth", `<div class="nd-big"><b>${esc(I.gdp.latest)}</b><span>${esc(I.gdp.label)}<br>${esc(I.gdp.prev)}</span></div>`);

    // seasonality
    const sea = I.seasonality, mi = istNow().getMonth();
    const seaHtml = sea ? columns(sea.months.map(m => m[0]), sea.avg, { hl: mi, vals: v => nfNum(v, 1), label: "Nifty monthly seasonality" }) + `<p class="nd-cap">${esc(sea.months[mi])} has averaged ${sp(sea.avg[mi])}% (median ${sp(sea.median[mi])}%) and closed higher ${sea.upPct[mi]}% of the time. ${esc(sea.note)}</p>` : "";
    // daily move histogram
    const rets = dailyRets(); let histHtml = "";
    if (rets.length > 60 && nn) { const pr = rets.filter(r => Math.abs(r) < Math.abs(nn.pct)).length / rets.length * 100;
      histHtml = hist(rets.slice(-500), nn.pct) + `<p class="nd-cap">Today's ${sp(nn.pct)}% is bigger than ${Math.round(pr)}% of Nifty's daily moves over the last ${Math.round(rets.length / 250 * 10) / 10} years. ${pr > 85 ? "This is an unusually big day: news is clearly moving the market." : pr < 40 ? "A small move so far: the market isn't reacting strongly yet." : "A fairly normal-sized move."}</p>`; }
    // history
    const histRows = th.hist.filter(h => h[2] != null);
    const precedent = th.hist.length ? `${histRows.length >= 2 ? bars(histRows.map(h => [h[0], h[2]]), { label: "Nifty reaction on similar days", labW: 92 }) : ""}
      <ul class="nd-tl">${th.hist.map(([d, e, p, note]) => `<li><span class="nd-d">${esc(d)}</span><div><strong>${esc(e)}</strong>${p != null ? ` <em class="${p >= 0 ? "up" : "down"}">Nifty ${sp(p)}%</em>` : ""}<p>${mt(note)}</p></div></li>`).join("")}</ul>` : "";
    const upc = (typeof upcomingEvents === "function" ? upcomingEvents(8) : []).filter(([, , l]) => th.re.test(l) || (n.k === "fed" && /Fed|FOMC|US/i.test(l)) || (n.k === "inflation" && /CPI|inflation/i.test(l)) || (n.k === "rbi" && /RBI|policy/i.test(l))).slice(0, 3);

    const top = `<div class="nd-hero">
        <div class="nd-hl"><h3>${esc(n.title)}</h3>${n.link ? `<a href="${esc(n.link)}" target="_blank" rel="noopener" class="nd-src">Read the full story on ${esc(n.source || "the publisher")} ↗</a>` : ""}</div>
        <div class="nd-g">${gauge(imp, tl[1])}<span class="np-tone ${tl[1]}">${tl[0]} for Nifty</span></div></div>`;
    const why = S("Why it matters for the market", `<p>${mt(th.why)}</p>`);
    const deep = [
      S("The market right now", `${nn ? `<div class="nd-now"><div><span>Nifty 50</span><b>${nfNum(nn.price, 2)}</b><em class="${nn.pct >= 0 ? "up" : "down"}">${sp(nn.pct)}%</em></div>${intra && intra.length > 5 ? `<div class="nd-spark">${lineChart(intra, { h: 70, left: "9:15", right: "now", label: "Nifty today" })}</div>` : ""}</div>` : ""}
        ${secRows.length ? `<p class="nd-cap" style="margin-top:10px">Sector moves today. Sectors this news usually hits are highlighted.</p>${bars(secRows.map(r => [r[0], r[1], r[2]]), { label: "Sector moves today", labW: 110 })}` : ""}`),
      g ? S(`${assetName}: the number behind this story`, lineChart(g.spark, { cls: n.tone >= 0 ? "gold" : "down", left: "3 months ago", right: "today", fmt: assetFmt, label: assetName, h: 130 }) + `<p class="nd-cap">Now ${assetFmt(g.price)}, ${g.chg >= 0 ? "up" : "down"} ${th.asset === "us10y" ? nfNum(Math.abs(g.chg) * 100, 1) + " basis points" : nfNum(Math.abs(g.pct), 2) + "%"} today.</p>`) : "",
      th.sectors.length ? S("Who feels it most", iso3d(th.sectors, n.tone || 1) + `<p class="nd-cap">${n.tone < 0 ? "For this negative story" : "For this positive story"}: ▲ usually helped, ▼ usually hurt. More dots = a stronger typical reaction. Based on how these sectors have historically reacted to this kind of news.</p>`) : "",
      S("When this happened before", precedent),
      dataChart,
      S(`Seasonality: how ${sea ? esc(sea.months[mi]) : "this month"} usually goes`, seaHtml),
      S("How big is today's move?", histHtml),
      S("What could neutralise this", th.neut.length ? `<ul class="nd-ul">${th.neut.map(x => `<li>${mt(x)}</li>`).join("")}</ul>` : ""),
      S("Recent developments on this story", related.length ? `<ul class="nd-dev">${related.map(r => `<li><a href="${esc(r.link || "#")}" target="_blank" rel="noopener"><strong>${esc(r.title)}</strong><span>${esc(r.source || "")}${r.published ? " · " + ago(r.published) : ""}</span></a></li>`).join("")}</ul>` : `<p class="nd-cap">No other headlines on this theme in the last day and a half.</p>`),
      S("What to watch next", `<ul class="nd-ul">${th.watch.map(x => `<li>${mt(x)}</li>`).join("")}${upc.map(([d, , l]) => `<li><b>${esc(shortDay(new Date(d + "T00:00:00")))}</b>: ${esc(l)}</li>`).join("")}</ul>`),
      mix.length > 1 ? S("What the market is talking about today", donut(mix)) : ""
    ].join("");
    return top + why + (pro ? deep : `<div style="margin-top:14px">${Lock.wrap(deep, "News deep-dive", { title: "Subscribe for the full deep-dive", sub: "Live reaction, sector impact, history, seasonality and what to watch next" })}</div>`) +
      `<p class="muted small" style="margin:16px 0 0">${t("Tap underlined words for their meaning.")} Theme, tone and impact are worked out automatically from the headline and live data. For education only, not a trade call.</p>`;
  }
  window.openNews = (n) => {
    if (!n) return;
    const th = TH[n.k], sh = openSheet(th.ic + " " + th.name, "", { sub: `${esc(n.source || "")}${n.published ? " · " + ago(n.published) : ""}` });
    sh.body.innerHTML = newsBody(n); sh.body.scrollTop = 0;
  };
  window._npRank = rank; window._npTH = TH;
})();
