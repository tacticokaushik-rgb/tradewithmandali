/* Mandali media: attach chart screenshots / photos to doubts, questions, journal entries and replies.
   Images are compressed on the phone, stored privately, and opened in a full-screen pinch-zoom viewer. */
(function () {
  const BUCKET = "doubt-images", MAX = 3;
  const urlCache = new Map(); // path -> {u, exp}
  const shrink = (file, max = 1600) => new Promise((res) => {
    const img = new Image(), url = URL.createObjectURL(file);
    img.onload = () => {
      const s = Math.min(1, max / Math.max(img.width, img.height)), c = document.createElement("canvas");
      c.width = Math.round(img.width * s); c.height = Math.round(img.height * s);
      const g = c.getContext("2d"); g.fillStyle = "#fff"; g.fillRect(0, 0, c.width, c.height); g.drawImage(img, 0, 0, c.width, c.height);
      URL.revokeObjectURL(url); c.toBlob(b => res(b || file), "image/jpeg", 0.85);
    };
    img.onerror = () => { URL.revokeObjectURL(url); res(null); };
    img.src = url;
  });

  /* ---------- Picker ---------- */
  const picker = (label = "Add chart / photo") => `<div class="md-pick" data-mp>
      <div class="md-thumbs"></div>
      <label class="md-add"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="5" width="18" height="14" rx="2"/><circle cx="9" cy="11" r="2"/><path d="M21 17l-5-5-7 7"/></svg>${label}<input type="file" accept="image/*" multiple hidden></label>
      <span class="md-hint">Up to ${MAX} images${/Android|iPhone|iPad/i.test(navigator.userAgent) ? "" : " · or paste a screenshot (Ctrl+V)"}</span>
    </div>`;
  function bind(root) {
    $$("[data-mp]", root).forEach(el => {
      if (el._bound) return; el._bound = true; el._files = [];
      const inp = el.querySelector("input"), box = el.querySelector(".md-thumbs");
      const draw = () => {
        box.innerHTML = el._files.map((f, i) => `<span class="md-th"><img src="${f._u}" alt="Attached image ${i + 1}"><button type="button" data-rm="${i}" aria-label="Remove image ${i + 1}">✕</button></span>`).join("");
        $$("[data-rm]", box).forEach(b => b.onclick = () => { URL.revokeObjectURL(el._files[+b.dataset.rm]._u); el._files.splice(+b.dataset.rm, 1); draw(); });
        el.querySelector(".md-add").classList.toggle("hidden", el._files.length >= MAX);
      };
      const add = (list) => {
        for (const f of list) { if (!/^image\//.test(f.type)) continue; if (el._files.length >= MAX) { toast(`Up to ${MAX} images`); break; } f._u = URL.createObjectURL(f); el._files.push(f); }
        draw();
      };
      inp.onchange = () => { add([...inp.files]); inp.value = ""; };
      const form = el.closest("form") || el.parentElement;
      form.addEventListener("paste", (e) => { const fs = [...(e.clipboardData?.files || [])].filter(f => /^image\//.test(f.type)); if (fs.length) { e.preventDefault(); add(fs); } });
      el._reset = () => { el._files.forEach(f => URL.revokeObjectURL(f._u)); el._files = []; draw(); };
    });
  }
  /* Upload the picked images. scope: "class" (visible to batch) or "private" (owner + Mandali). owner: whose folder. */
  async function upload(el, scope, owner) {
    if (!el || !el._files || !el._files.length) return [];
    const uid = owner || (await sb.auth.getSession()).data.session?.user?.id;
    const out = [];
    for (let i = 0; i < el._files.length; i++) {
      const blob = await shrink(el._files[i]); if (!blob) continue;
      const path = `${scope}/${uid}/${Date.now()}-${i}.jpg`;
      const r = await sb.storage.from(BUCKET).upload(path, blob, { contentType: "image/jpeg" });
      if (r.error) throw new Error(/bucket|not found/i.test(r.error.message) ? "Image uploads aren't set up yet (run update-media.sql)." : r.error.message);
      out.push(path);
    }
    return out;
  }

  /* ---------- Display ---------- */
  const html = (paths) => !paths || !paths.length ? "" : `<div class="md-grid n${Math.min(paths.length, 3)}">${paths.map((p, i) => `<button type="button" class="md-img" data-mimg="${esc(p)}" aria-label="Open image ${i + 1}"><img alt="" loading="lazy"></button>`).join("")}</div>`;
  async function hydrate(root) {
    const els = $$("[data-mimg]", root || document); if (!els.length) return;
    const need = [...new Set(els.map(e => e.dataset.mimg))].filter(p => { const c = urlCache.get(p); return !c || c.exp < Date.now(); });
    if (need.length) {
      const r = await sb.storage.from(BUCKET).createSignedUrls(need, 6 * 3600);
      (r.data || []).forEach(x => { if (x.signedUrl) urlCache.set(x.path, { u: x.signedUrl, exp: Date.now() + 5.5 * 3600e3 }); });
    }
    els.forEach(e => {
      const c = urlCache.get(e.dataset.mimg), im = e.querySelector("img");
      if (c && im && im.src !== c.u) im.src = c.u; else if (!c) e.classList.add("md-broken");
      e.onclick = () => { const grid = e.closest(".md-grid"), all = $$("[data-mimg]", grid).map(x => urlCache.get(x.dataset.mimg)?.u).filter(Boolean); view(all, all.indexOf(c?.u)); };
    });
  }

  /* ---------- Full-screen viewer: pinch / double-tap zoom, swipe between images ---------- */
  function view(urls, start = 0) {
    if (!urls.length) return;
    let i = Math.max(0, start), sc = 1, tx = 0, ty = 0;
    const el = document.createElement("div"); el.className = "md-view"; el.setAttribute("role", "dialog"); el.setAttribute("aria-label", "Image viewer");
    el.innerHTML = `<div class="md-stage"><img alt="Attached image"></div>
      <div class="md-bar"><span class="md-count"></span><span style="flex:1"></span><a class="md-btn" target="_blank" rel="noopener" download aria-label="Open original">↗</a><button class="md-btn" data-x aria-label="Close">✕</button></div>
      ${urls.length > 1 ? `<button class="md-nav prev" aria-label="Previous image">‹</button><button class="md-nav next" aria-label="Next image">›</button>` : ""}`;
    document.body.appendChild(el);
    const img = el.querySelector("img"), stage = el.querySelector(".md-stage");
    const apply = () => { img.style.transform = `translate(${tx}px, ${ty}px) scale(${sc})`; };
    const show = () => { sc = 1; tx = ty = 0; apply(); img.src = urls[i]; el.querySelector(".md-count").textContent = urls.length > 1 ? `${i + 1} / ${urls.length}` : ""; el.querySelector("a.md-btn").href = urls[i]; };
    const close = () => { if (el.dataset.closing) return; el.dataset.closing = "1"; el.classList.remove("on"); setTimeout(() => el.remove(), 180); };
    el._close = close;
    const step = (d) => { if (urls.length < 2) return; i = (i + d + urls.length) % urls.length; show(); };
    el.querySelector("[data-x]").onclick = close;
    const pv = el.querySelector(".prev"), nx = el.querySelector(".next"); if (pv) pv.onclick = () => step(-1); if (nx) nx.onclick = () => step(1);
    const onKey = (e) => { if (!el.isConnected) return document.removeEventListener("keydown", onKey); if (e.key === "ArrowRight") step(1); if (e.key === "ArrowLeft") step(-1); if (e.key === "Escape") history.back(); };
    document.addEventListener("keydown", onKey);
    // gestures
    const pts = new Map(); let start0 = null, lastTap = 0, swipeX = null;
    stage.addEventListener("pointerdown", (e) => { stage.setPointerCapture(e.pointerId); pts.set(e.pointerId, { x: e.clientX, y: e.clientY });
      if (pts.size === 2) { const [a, b] = [...pts.values()]; start0 = { d: Math.hypot(a.x - b.x, a.y - b.y), sc }; }
      else { swipeX = { x: e.clientX, y: e.clientY, tx, ty }; } });
    stage.addEventListener("pointermove", (e) => { if (!pts.has(e.pointerId)) return; pts.set(e.pointerId, { x: e.clientX, y: e.clientY });
      if (pts.size === 2 && start0) { const [a, b] = [...pts.values()]; sc = Math.min(5, Math.max(1, start0.sc * Math.hypot(a.x - b.x, a.y - b.y) / start0.d)); apply(); }
      else if (pts.size === 1 && swipeX && sc > 1) { tx = swipeX.tx + e.clientX - swipeX.x; ty = swipeX.ty + e.clientY - swipeX.y; apply(); } });
    const up = (e) => {
      if (pts.size === 1 && swipeX) {
        const dx = e.clientX - swipeX.x, dy = e.clientY - swipeX.y;
        if (sc === 1 && Math.abs(dx) > 60 && Math.abs(dx) > Math.abs(dy)) step(dx < 0 ? 1 : -1);
        else if (sc === 1 && dy > 110 && Math.abs(dy) > Math.abs(dx)) history.back();
        else if (Math.abs(dx) < 8 && Math.abs(dy) < 8) { const now = Date.now(); if (now - lastTap < 300) { sc = sc > 1 ? 1 : 2.5; tx = ty = 0; apply(); } lastTap = now; }
      }
      pts.delete(e.pointerId); if (pts.size < 2) start0 = null; if (!pts.size) { swipeX = null; if (sc === 1) { tx = ty = 0; apply(); } }
    };
    stage.addEventListener("pointerup", up); stage.addEventListener("pointercancel", up);
    show(); requestAnimationFrame(() => el.classList.add("on"));
  }

  window.Media = { picker, bind, upload, html, hydrate, view };

  /* ---------- Quick replies (admin): one tap fills a saved reply ---------- */
  const QDEF = ["Good analysis 👍 Keep journalling daily.", "Where was your stop-loss? Always write it before entry.", "Mark your levels on the chart and share it, then we'll discuss.",
    "Right idea, wrong timing. Wait for the candle close next time.", "We'll cover this in today's class. Please join.", "Size down until you're consistent. Protect capital first."];
  const qGet = () => { try { const v = JSON.parse(localStorage.getItem("m_quick") || "null"); return Array.isArray(v) ? v : QDEF; } catch (e) { return QDEF; } };
  const qSet = (v) => { try { localStorage.setItem("m_quick", JSON.stringify(v)); } catch (e) {} };
  window.QuickReplies = {
    html: () => `<div class="qr-row" data-qr>${qGet().map((q, i) => `<button type="button" class="qr" data-q="${i}" title="Long-press to remove">${esc(q.length > 38 ? q.slice(0, 36) + "…" : q)}</button>`).join("")}<button type="button" class="qr qr-add" data-qadd title="Save what you've typed as a quick reply">＋ Save</button></div>`,
    bind(root) {
      $$("[data-qr]", root).forEach(row => {
        const field = () => row.parentElement.querySelector("textarea, input[name=body], input[name=reply], [data-reptext]");
        const redraw = () => { const n = document.createElement("div"); n.innerHTML = QuickReplies.html(); row.replaceWith(n.firstChild); QuickReplies.bind(root); };
        $$("[data-q]", row).forEach(b => {
          b.onclick = () => { const f = field(); if (!f) return; const q = qGet()[+b.dataset.q]; f.value = f.value.trim() ? f.value.trim() + " " + q : q; f.focus(); };
          let t; b.addEventListener("pointerdown", () => { t = setTimeout(() => { if (confirm("Remove this quick reply?")) { const v = qGet(); v.splice(+b.dataset.q, 1); qSet(v); redraw(); } }, 650); });
          ["pointerup", "pointerleave", "pointercancel"].forEach(ev => b.addEventListener(ev, () => clearTimeout(t)));
          b.addEventListener("contextmenu", (e) => e.preventDefault());
        });
        row.querySelector("[data-qadd]").onclick = () => { const f = field(), v = f && f.value.trim(); if (!v) return toast("Type a reply first, then tap Save"); const all = qGet(); if (!all.includes(v)) { all.unshift(v); qSet(all.slice(0, 12)); } toast("Saved as a quick reply"); redraw(); };
      });
    }
  };
})();
