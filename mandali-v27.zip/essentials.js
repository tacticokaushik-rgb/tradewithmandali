/* Mandali Essentials deep-dives: tap an expiry, a market timing, Muhurat or an index to learn more. */
(function () {
  const D = (s) => new Date(s + "T00:00:00");
  const dd = (d) => d.toLocaleDateString("en-IN", { weekday: "short", day: "numeric", month: "short" });
  const isHol = (s) => (MKT.holidays || []).some(h => h[0] === s);
  const holName = (s) => ((MKT.holidays || []).find(h => h[0] === s) || [])[1];
  const li = (h, d) => `<li><strong>${h}</strong>${d ? `<br><span class="muted small">${d}</span>` : ""}</li>`;
  const sec = (t) => `<p class="sh-sec">${t}</p>`;
  const tips = (arr) => `<ul class="ess-tips">${arr.map(([h, d]) => li(h, d)).join("")}</ul>`;

  /* ---------- Expiry deep-dive ---------- */
  const META = {
    "nifty": { title: "Nifty weekly expiry", who: "Nifty 50 weekly options (NSE)", lot: 65 },
    "nifty-monthly": { title: "Monthly expiry (NSE)", who: "Nifty, Bank Nifty, Fin Nifty, Midcap Select, Nifty Next 50 and all stock F&O", lot: 65 },
    "sensex": { title: "Sensex weekly expiry", who: "Sensex weekly options (BSE)", lot: 20 },
    "sensex-monthly": { title: "Monthly expiry (BSE)", who: "Sensex and Bankex monthly contracts (BSE)", lot: 20 }
  };
  function windowEvents(fromS, toS, selfKey) {
    const out = [];
    (MKT.events || []).forEach(([d, l]) => out.push([d, "🇮🇳", l, /RBI|Budget|GDP|CPI/.test(l) ? "H" : "M", ""]));
    (MKT.watch || []).forEach(x => out.push(x));
    (MKT.holidays || []).forEach(([d, l]) => out.push([d, "🏖️", "Market holiday: " + l, "M", "No trading. Option premiums still lose a day of time value."]));
    if (MKT.muhurat) out.push([MKT.muhurat[0], "🪔", "Diwali Muhurat trading (one-hour session)", "M", "Symbolic session; thin volumes."]);
    upcomingExpiries(90).forEach(x => { const s = ymd(x.date); if (s !== selfKey) out.push([s, "⏳", x.label + " expiry", x.kind.includes("monthly") ? "H" : "M", ""]); });
    return out.filter(e => e[0] >= fromS && e[0] <= toS).sort((a, b) => a[0].localeCompare(b[0]) || (a[3] === "H" ? -1 : 1));
  }
  function countDays(fromD, toD) {
    let trading = 0, off = 0;
    for (let d = addDays(fromD, 1); d <= toD; d = addDays(d, 1)) { const s = ymd(d), w = d.getDay(); if (w === 0 || w === 6 || isHol(s)) off++; else trading++; }
    return { trading, off, cal: Math.round((toD - addDays(fromD, 0)) / 864e5) };
  }
  window.openExpirySheet = (kind, dateS) => {
    const m = META[kind] || META.nifty, exp = D(dateS), now = istNow(), todayS = ymd(now);
    const info = upcomingExpiries(90).find(x => ymd(x.date) === dateS && x.kind === kind);
    const c = countDays(addDays(now, 0), exp), isToday = dateS === todayS;
    const ev = windowEvents(todayS, dateS, dateS);
    const big = ev.filter(e => e[3] === "H" && e[1] !== "⏳");
    const monthly = kind.includes("monthly"), bse = kind.startsWith("sensex");
    const FULL = `
      <div class="ess-hero">
        <div><span class="ess-k">EXPIRES</span><strong>${dd(exp)}, 3:30 PM</strong>${info && info.orig ? `<span class="ess-note">Moved from ${dd(info.orig)} (${esc(holName(ymd(info.orig)) || "holiday")})</span>` : ""}</div>
        <div class="ess-stats"><span><b>${isToday ? "Today" : c.trading}</b>${isToday ? "" : " trading day" + (c.trading === 1 ? "" : "s")}</span><span><b>${c.cal}</b> calendar day${c.cal === 1 ? "" : "s"}</span><span><b>${c.off}</b> non-trading</span></div>
        <p class="muted small" style="margin:6px 0 0">Covers: ${esc(m.who)}.</p>
      </div>
      ${c.off && !isToday ? `<p class="ess-call">⏱️ ${c.off} weekend/holiday day${c.off === 1 ? "" : "s"} fall before this expiry. Option prices lose time value over these days too, which helps sellers and hurts buyers holding through them.</p>` : ""}
      <!--LOCK-->${big.length ? `<p class="ess-call warn">⚠️ ${big.length} high-impact event${big.length === 1 ? "" : "s"} before this expiry: ${big.map(e => esc(e[2].replace(/\s*\(.*\)$/, ""))).join(", ")}. Expect bigger moves and costlier premiums around ${big.length === 1 ? "it" : "them"}.</p>` : !isToday ? `<p class="ess-call">✅ No major scheduled event before this expiry. Ranges often hold better, but global news can still surprise.</p>` : ""}

      ${sec(isToday ? "Today" : "What's happening before this expiry")}
      ${ev.length ? `<ol class="ess-tl">${ev.map(e => `<li class="${e[3] === "H" ? "hi" : ""}"><span class="ess-d">${dd(D(e[0]))}</span><span class="ess-e"><span>${e[1]} ${esc(e[2])}${e[3] === "H" ? ` <em class="ess-tag">High impact</em>` : ""}</span>${e[4] ? `<small>${esc(e[4])}</small>` : ""}</span></li>`).join("")}<li class="end"><span class="ess-d">${dd(exp)}</span><span class="ess-e"><span>🎯 <strong>This expiry, 3:30 PM</strong></span></span></li></ol>` : `<p class="sh-empty">No scheduled events in between.</p>`}

      ${sec("What to watch into this expiry")}
      ${tips([
        ["Max Call OI and Max Put OI for this expiry", "The strikes with the most open contracts usually act as the range option writers are defending. Track whether these walls shift up or down each day: a rising put wall means support is moving higher."],
        ["PCR of this expiry, not the overall market", "A rising put-call ratio while price rises shows put writers are confident. A falling PCR into resistance shows call writers taking control."],
        ["ATM straddle price = the market's expected move", `Add the ATM call and put premiums. If the straddle is ₹180, the market is pricing roughly a ±180-point move till expiry. A move beyond it surprises option sellers.`],
        ["India VIX and implied volatility", "Rising VIX makes premiums costlier and ranges wider. Falling VIX before an event can mean the market is complacent."],
        ["Time decay speeds up near expiry", "Most time value melts in the last two or three sessions. Buyers need a quick move; sellers earn faster but face gamma risk."],
        ["GIFT Nifty and global cues overnight", "Gaps can jump straight past OI walls. Check GIFT Nifty and US futures before 9:00 AM."]
      ])}
      ${monthly ? sec("Monthly expiry specials") + tips(bse ? [
        ["Sensex and Bankex monthly together", "BSE's monthly series of Sensex and Bankex expire together on the last Thursday."],
        ["Lower liquidity than NSE", "Spreads can widen in far strikes. Use limit orders."],
        ["Rollover into the next month", "Futures traders shift positions to next month's contract in the last week; watch the rollover cost."]
      ] : [
        ["Everything expires together", "Nifty monthly, Bank Nifty, Fin Nifty, Midcap Select, Nifty Next 50 and all stock F&O expire the same day. Volumes and volatility are usually higher."],
        ["Rollover percentage", "The share of futures positions carried into next month. High rollover with rising prices means longs are staying; compare it with the 3-month average."],
        ["Rollover cost", "Next month's futures premium over this month's. A higher cost means longs are paying up to stay, a bullish sign; a discount shows shorts are rolling."],
        ["FII positioning", "NSE's daily participant-wise OI shows the FII long-short ratio in index futures. Extreme shorts often lead to sharp short-covering rallies."],
        ["Bank Nifty has only monthly options", "Since November 2024, Bank Nifty has no weekly options, so all its open interest builds up in this one monthly series. The big strike levels matter more."],
        ["Stock F&O is physically settled", "In-the-money stock options and stock futures held into expiry turn into delivery of shares. Brokers raise margins in expiry week, so many traders exit early, which can cause swings in F&O stocks."],
        ["New lot sizes start with new series", "When exchanges revise lot sizes, the change usually applies from a new monthly series. Check the lot before trading the next month."]
      ]) : ""}
      ${bse && !monthly ? sec("About Sensex expiry") + tips([
        ["A second expiry day each week", "Since September 2025, Nifty expires on Tuesday and Sensex on Thursday, so traders get two expiry days a week on two exchanges."],
        ["Different index, similar mood", "Sensex has 30 stocks, Nifty 50; they move closely but heavyweights like HDFC Bank, Reliance and ICICI Bank weigh differently."],
        ["Lot size 20", "One lot is 20 × the Sensex level, roughly ₹15 to 17 lakh of exposure. Liquidity in far strikes is thinner than in Nifty."]
      ]) : ""}
      ${sec("Expiry-day playbook")}
      ${tips([
        ["9:15 to 9:45 AM: let the range form", "Open interest shifts fast at the open. The first 15 to 30 minutes often set the day's battle lines."],
        ["Midday: time value melts", "Out-of-the-money options lose value quickly; at-the-money options react most to every move (highest gamma)."],
        ["After 1:30 to 2:00 PM: gamma moves", "A small move in the index can double or wipe out ATM premiums in minutes. This is where 'hero-zero' trades come from; size small."],
        ["Exit ITM options yourself before 3:30 PM", "If a long in-the-money option is left to expire, it's exercised and STT is charged on its intrinsic value, which can be much more than selling it. Square off before the close."],
        ["Settlement uses the closing index value", "Index options settle in cash at the index's official close, which is calculated from the last 30 minutes of trading, not the 3:29 PM tick."],
        ["Don't rely on broker auto square-off", "Brokers usually close leftover intraday positions around 3:15 to 3:25 PM at market price, often with a fee. Plan your exit."]
      ])}
      <p class="muted small" style="margin:14px 0 0">Dates marked "usually" or "expected" can change; holiday rules from NSE's 2026 circular. Education only, not a trade recommendation.</p>`;
    const cut = FULL.indexOf("<!--LOCK-->");
    const sh = openSheet(m.title, isPro() ? FULL : FULL.slice(0, cut) + `<p class="sh-sec">What's happening before this expiry</p>` + Lock.wrap(FULL.slice(cut), "Expiry deep-dives",
        { title: `${ev.length} event${ev.length === 1 ? "" : "s"} before this expiry`, sub: "See what's coming, what to watch and the expiry-day playbook" }),
      { sub: isToday ? "Expires today" : `${c.cal} day${c.cal === 1 ? "" : "s"} to go` });
    return sh;
  };

  /* ---------- Market timings ---------- */
  const TIMING = {
    preopen: ["Pre-open session · 9:00 to 9:15 AM", "A 15-minute auction that finds a fair opening price", () => `
      ${sec("Why it exists")}<p>Before the pre-open, the market opened directly into continuous trading, and the first few minutes were chaotic: a few large orders could swing prices sharply. The pre-open is a <strong>call auction</strong>: everyone places orders first, then the exchange finds the single price at which the most shares can trade. That becomes the day's open.</p>
      ${sec("How it works in the cash market (NSE)")}
      <ol class="ess-tl">
        <li><span class="ess-d">9:00–9:05</span><span class="ess-e"><span>Place, modify or cancel orders</span><small>Both limit and market orders.</small></span></li>
        <li><span class="ess-d">9:05–9:10</span><span class="ess-e"><span>Limit orders only</span><small>This window closes at a random moment in its last two minutes, so nobody can game the final second.</small></span></li>
        <li><span class="ess-d">9:10–9:12</span><span class="ess-e"><span>Matching</span><small>The equilibrium price is found and trades are confirmed.</small></span></li>
        <li><span class="ess-d">9:12–9:15</span><span class="ess-e"><span>Buffer</span><small>A short gap before normal trading.</small></span></li>
        <li class="end"><span class="ess-d">9:15</span><span class="ess-e"><span><strong>Continuous trading starts</strong></span></span></li>
      </ol>
      ${sec("History")}
      ${tips([
        ["2010: introduced in the cash market", "SEBI introduced the pre-open call auction in 2010, starting with the Nifty and Sensex stocks, to curb volatile openings. It was later extended to more stocks, and IPOs and relisted stocks use a special pre-open on their first day."],
        ["8 December 2025: pre-open comes to F&O", "NSE started a pre-open session for current-month index futures and stock futures (and next-month futures in the last five days before expiry), with orders from 9:00 to 9:08 AM and matching by 9:12. Options still start directly at 9:15."]
      ])}
      ${sec("How traders use it")}
      ${tips([
        ["Read the gap early", "The indicative equilibrium price shows where a stock or Nifty future will open. Combine it with GIFT Nifty to judge a gap-up or gap-down."],
        ["Don't chase the first candle", "Big pre-open gaps often see some pullback in the first 15 minutes. Wait for the opening range."]
      ])}`],
    normal: ["Normal market · 9:15 AM to 3:30 PM", "Monday to Friday, except exchange holidays", () => `
      ${sec("A day in the Indian market")}
      <ol class="ess-tl">
        <li><span class="ess-d">9:00</span><span class="ess-e"><span>Pre-open auction</span></span></li>
        <li class="hi"><span class="ess-d">9:15</span><span class="ess-e"><span>Market opens</span><small>Usually the most volatile hour of the day.</small></span></li>
        <li><span class="ess-d">11:30–1:30</span><span class="ess-e"><span>Midday lull</span><small>Volumes often thin out; fake breakouts are common.</small></span></li>
        <li><span class="ess-d">1:30</span><span class="ess-e"><span>Europe opens</span><small>Global cues can bring fresh direction.</small></span></li>
        <li class="hi"><span class="ess-d">3:00–3:30</span><span class="ess-e"><span>Closing price window</span><small>NSE's closing price is the weighted average of the last 30 minutes, so institutions are active here.</small></span></li>
        <li><span class="ess-d">3:30</span><span class="ess-e"><span>Market closes</span></span></li>
        <li class="end"><span class="ess-d">3:40–4:00</span><span class="ess-e"><span>Post-close session (cash)</span><small>Shares can be traded only at the official closing price.</small></span></li>
      </ol>
      ${sec("How we got here")}
      ${tips([
        ["Before 1994: trading ring", "Brokers traded face to face in the BSE trading ring with open outcry, for only a few hours a day."],
        ["November 1994: NSE goes electronic", "NSE launched nationwide screen-based equity trading, so anyone with a terminal anywhere in India could trade at the same price. BSE moved to screen trading (BOLT) soon after."],
        ["2000 to 2001: derivatives arrive", "Nifty futures launched in June 2000, India's first equity derivative. Index options followed in June 2001, then stock options and stock futures later that year."],
        ["2009–2010: earlier open, pre-open added", "Around 2009–2010 the exchanges moved the open earlier, to 9:00 AM, to align with Asian markets. Once the pre-open auction was added in 2010, continuous trading settled at 9:15 AM, where it has stayed."],
        ["Longer hours have been discussed", "Proposals to extend F&O trading into the evening have been debated, but as of this update index F&O still closes at 3:30 PM."]
      ])}
      ${sec("Good to know")}
      ${tips([
        ["Settlement is T+1", "Shares bought today reach your demat account the next trading day. India moved fully to T+1 in January 2023, among the first large markets to do so."],
        ["Price bands and circuits", "Individual stocks have daily price bands. Market-wide circuit breakers at 10%, 15% and 20% moves in Nifty or Sensex halt all trading for a while."]
      ])}`],
    expiry: ["Expiry · 3:30 PM", "How expiry days evolved in India", () => `
      ${sec("The basics")}<p>Index options and futures expire at <strong>3:30 PM</strong> on expiry day and settle in cash at the index's official closing value. If the expiry day is a trading holiday, the contract expires on the <strong>previous trading day</strong>. Today, <strong>NSE contracts expire on Tuesday</strong> (Nifty weekly, and the last Tuesday for monthlies), and <strong>BSE contracts on Thursday</strong>.</p>
      ${sec("History of expiry days")}
      <ol class="ess-tl">
        <li><span class="ess-d">2000–2015</span><span class="ess-e"><span>Monthly only, last Thursday</span><small>For 15 years, F&O had one expiry a month.</small></span></li>
        <li><span class="ess-d">2016</span><span class="ess-e"><span>Bank Nifty weekly options launch</span><small>India's first weekly options; they quickly became hugely popular.</small></span></li>
        <li><span class="ess-d">2019</span><span class="ess-e"><span>Nifty weekly options launch</span></span></li>
        <li><span class="ess-d">2021–2023</span><span class="ess-e"><span>An expiry almost every day</span><small>Fin Nifty and Midcap Select weeklies, and BSE's relaunched Sensex and Bankex weeklies in May 2023, spread expiries across the week.</small></span></li>
        <li class="hi"><span class="ess-d">20 Nov 2024</span><span class="ess-e"><span>SEBI tightens index F&amp;O</span><small>Only one weekly index per exchange (Nifty on NSE, Sensex on BSE), so Bank Nifty and Fin Nifty weeklies stopped. Lot sizes were raised so each contract is worth about ₹15 lakh or more, and extra margin applies on short options on expiry day.</small></span></li>
        <li><span class="ess-d">Jan 2025</span><span class="ess-e"><span>BSE moves Sensex to Tuesday</span></span></li>
        <li class="hi end"><span class="ess-d">1 Sep 2025</span><span class="ess-e"><span>NSE → Tuesday, BSE → Thursday</span><small>SEBI fixed weekly expiries to Tuesdays and Thursdays, one day per exchange.</small></span></li>
      </ol>
      ${sec("Why SEBI stepped in")}<p>SEBI studies found that about 9 out of 10 individual F&amp;O traders lost money, with expiry-day option buying a big part of it. The 2024 rules aimed to cut speculative expiry trading by making contracts bigger and limiting the number of weekly expiries.</p>
      ${sec("Expiry-day tips")}
      ${tips([
        ["Square off ITM options yourself", "Exercised in-the-money options attract STT on intrinsic value."],
        ["Gamma is highest in the last two hours", "Small index moves cause big premium swings; size down."]
      ])}`],
    muhurat: ["Muhurat trading", "The one-hour Diwali session", () => `
      <div class="ess-hero"><div><span class="ess-k">THIS YEAR</span><strong>${dd(D(MKT.muhurat[0]))}</strong><span class="ess-note">Timings are announced by NSE and BSE a few weeks before. The next day, Tue 10 Nov, is a market holiday (Diwali Balipratipada).</span></div></div>
      ${sec("What it is")}<p>Muhurat means an auspicious time. On Diwali, the exchanges open for a special session of about <strong>one hour</strong> to mark the start of the new Samvat, the Hindu accounting year. Many traditional business families and investors buy a small amount of stock as a token of good luck for the year ahead.</p>
      ${sec("History")}
      ${tips([
        ["1957: BSE begins the tradition", "Muhurat trading at BSE dates back to 1957, rooted in the custom of opening new account books (chopda pujan) on Diwali."],
        ["1992: NSE joins in", "NSE has held a Muhurat session every Diwali since 1992."],
        ["Evening, and sometimes afternoon", "For years the session was held in the evening, for example 6:00 to 7:00 PM in 2024. In 2025 (21 October) it was held in the afternoon, 1:45 to 2:45 PM."]
      ])}
      ${sec("How the session runs")}
      ${tips([
        ["Same structure as a normal day, compressed", "A short block-deal window, a 15-minute pre-open, about one hour of normal trading, then a closing session. Equity, F&O, currency and commodities all trade."],
        ["Trades are real", "Anything you buy or sell creates real settlement obligations. Intraday positions are squared off at the end of the session."]
      ])}
      ${sec("What we usually see")}
      ${tips([
        ["Thin volumes, small moves", "Most participants stay away, so the range is usually small and spreads can be wider."],
        ["A mild positive bias", "Nifty has ended the Muhurat session higher in most recent years, but the moves are tiny. It's a celebration, not a trading edge."],
        ["Don't take big positions", "Low liquidity can give bad fills; and the next day is often a holiday, so you carry the risk for longer."]
      ])}`]
  };
  const lockFrom = (html, nth, feat, opts) => {
    if (isPro()) return html;
    let i = -1; for (let n = 0; n < nth; n++) { i = html.indexOf('<p class="sh-sec">', i + 1); if (i < 0) return html; }
    return html.slice(0, i) + Lock.wrap(html.slice(i), feat, opts);
  };
  window.openTimingSheet = (k) => { const x = TIMING[k]; if (!x) return; openSheet(x[0], lockFrom(x[2](), k === "muhurat" ? 2 : 2, "Market history and tips", { title: "Read the full story", sub: "History, how it works and what traders should know" }), { sub: x[1] }); };

  /* ---------- Contracts: lot size history ---------- */
  const LOTS = {
    "Nifty 50": { launch: "Futures June 2000 (India's first equity derivative); options June 2001; weekly options 2019.", hist: [["At launch, 2000", "200", "When Nifty traded around 1,500"], ["Until Apr 2024", "50", ""], ["26 Apr 2024", "25", "Halved as Nifty crossed 22,000"], ["20 Nov 2024", "75", "SEBI's ₹15 lakh minimum contract value"], ["Jan 2026 series", "65", "Announced Oct 2025; old contracts kept 75 until 30 Dec 2025"]], weekly: "Every Tuesday (since Sep 2025; Thursday before that)", ex: 25000 },
    "Bank Nifty": { launch: "F&O launched in 2005; India's first weekly options in 2016, discontinued in Nov 2024.", hist: [["Until Jun 2023", "25", ""], ["Jul 2023 expiry", "15", ""], ["20 Nov 2024", "30", "SEBI's ₹15 lakh minimum"], ["Jul 2025 expiry", "35", "Revised up as the index rose"], ["Jan 2026 series", "30", "Revised down"]], weekly: "None since Nov 2024 (monthly only, last Tuesday)", ex: 56000 },
    "Fin Nifty": { launch: "F&O launched in January 2021 with Tuesday weekly options; weeklies stopped in Nov 2024.", hist: [["Until Apr 2024", "40", ""], ["26 Apr 2024", "25", ""], ["20 Nov 2024", "65", "SEBI's ₹15 lakh minimum"], ["Jan 2026 series", "60", ""]], weekly: "None since Nov 2024", ex: 26000 },
    "Midcap Select": { launch: "Nifty Midcap Select F&O launched in 2022; weeklies stopped in Nov 2024.", hist: [["Until Apr 2024", "75", ""], ["26 Apr 2024", "50", ""], ["20 Nov 2024", "120", "SEBI's ₹15 lakh minimum"], ["Jul 2025 expiry", "140", ""], ["Jan 2026 series", "120", ""]], weekly: "None since Nov 2024", ex: 13000 },
    "Nifty Next 50": { launch: "Monthly contracts only; a smaller, less liquid market.", hist: [["Until Nov 2024", "10", ""], ["20 Nov 2024", "25", "SEBI's ₹15 lakh minimum"], ["Since then", "25", "Unchanged in the 2025 revisions"]], weekly: "None", ex: 68000 },
    "Sensex": { launch: "BSE relaunched Sensex weekly options in May 2023 (Friday expiry); moved to Tuesday in Jan 2025 and to Thursday from Sep 2025.", hist: [["Until Nov 2024", "10", ""], ["20 Nov 2024", "20", "SEBI's ₹15 lakh minimum"]], weekly: "Every Thursday (since Sep 2025)", ex: 82000 }
  };
  window.openContractSheet = (name) => {
    const c = (MKT.contracts || []).find(x => x.name === name), L = LOTS[name]; if (!c || !L) return;
    const RX = { "Nifty 50": /^nifty( 50)?$/i, "Bank Nifty": /bank/i, "Fin Nifty": /fin/i, "Midcap Select": /mid.*sel/i, "Nifty Next 50": /next ?50/i, "Sensex": /sensex/i };
    let lvl = null, live = false;
    try {
      const idx = (typeof mbData !== "undefined" && mbData && mbData.indices) || [];
      const hit = idx.find(i => RX[name].test(i.label || "") || RX[name].test(i.key || ""));
      if (hit && hit.price) { lvl = hit.price; live = true; }
      else if (name === "Nifty 50" && typeof nfData !== "undefined" && nfData?.nifty?.price) { lvl = nfData.nifty.price; live = true; }
    } catch (e) {}
    if (!lvl) lvl = L.ex;
    const val = (c.lot * lvl / 1e5).toFixed(2).replace(/\.?0+$/, "");
    const LH = `
      <div class="ess-hero"><div><span class="ess-k">LOT SIZE NOW</span><strong>${c.lot} units</strong><span class="ess-note">${live ? `At today's level of ${Math.round(lvl).toLocaleString("en-IN")}` : `For example, at ${Math.round(lvl).toLocaleString("en-IN")}`}, one lot ≈ <b>₹${val} lakh</b> of exposure (lot × index level).</span></div>
        <div class="ess-stats"><span>Weekly: <b>${esc(L.weekly)}</b></span><span>Monthly: <b>${esc(c.monthly)}</b></span></div></div>
      ${sec("Lot size over the years")}
      <ol class="ess-tl">${L.hist.map((h, i) => `<li class="${i === L.hist.length - 1 ? "hi end" : ""}"><span class="ess-d">${esc(h[0])}</span><span class="ess-e"><span><strong>${esc(h[1])}</strong> units${i ? (() => { const p = +L.hist[i - 1][1], n = +h[1]; return p && n !== p ? ` <em class="ess-tag ${n > p ? "up" : "down"}">${n > p ? "▲" : "▼"} from ${p}</em>` : ""; })() : ""}</span>${h[2] ? `<small>${esc(h[2])}</small>` : ""}</span></li>`).join("")}</ol>
      ${sec("Background")}<p>${esc(L.launch)}</p>
      ${sec("Why lot sizes keep changing")}
      ${tips([
        ["A rupee value, not a fixed number", "Since 20 November 2024, SEBI wants each index contract to be worth about ₹15 lakh or more when introduced. As the index rises or falls, the exchanges revise the lot size so the contract value stays in that range."],
        ["Reviewed twice a year", "NSE and BSE review lot sizes periodically. The new size normally applies to newly listed contracts, while existing weekly and monthly contracts keep the old size until they expire."],
        ["Why it matters to you", "A bigger lot means more money per point: with 65 Nifty units, a 100-point move is ₹6,500 per lot. Recalculate your position size and stop-loss whenever the lot changes."]
      ])}
      <p class="muted small" style="margin:14px 0 0">Always confirm the current lot size with your broker before trading. Updated ${esc(MKT.asOf)}.</p>`;
    openSheet(name, lockFrom(LH, 1, "Lot-size history", { title: `${name} lot-size history`, sub: "Every change since launch and why lot sizes keep changing" }),
      { sub: c.ex + " · " + (c.weekly === "None" ? "monthly contracts" : "weekly and monthly contracts") });
  };

  /* Taps anywhere in the app (Home and Markets → Essentials) */
  document.addEventListener("click", (e) => {
    const x = e.target.closest("[data-exp], [data-timing], [data-contract]"); if (!x) return;
    if (x.dataset.exp) { const [k, d] = x.dataset.exp.split("|"); openExpirySheet(k, d); }
    else if (x.dataset.timing) openTimingSheet(x.dataset.timing);
    else if (x.dataset.contract) openContractSheet(x.dataset.contract);
  });
  document.addEventListener("keydown", (e) => { if ((e.key === "Enter" || e.key === " ") && e.target.matches && e.target.matches("[data-contract]")) { e.preventDefault(); e.target.click(); } });
})();
